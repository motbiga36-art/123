// EdgeBot Background Service Worker
// Handles reconnection, message relay, and tab management

const ENGINE_URL = "http://127.0.0.1:8765";
let keepAliveInterval = null;

// Keep service worker alive
function startKeepAlive() {
  if (keepAliveInterval) clearInterval(keepAliveInterval);
  keepAliveInterval = setInterval(async () => {
    try {
      await fetch(`${ENGINE_URL}/status`);
    } catch (e) {
      // Engine not running - that's ok, content script handles this
    }
  }, 20000);
}

// Relay messages between content script and popup if needed
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "ENGINE_STATUS") {
    // Forward status to popup
    chrome.runtime.sendMessage(message).catch(() => {});
  }
  return true;
});

// On install/startup
chrome.runtime.onInstalled.addListener(() => {
  console.log("EdgeBot Extension v1.0 installed");
  startKeepAlive();
});

// On browser start
chrome.runtime.onStartup.addListener(() => {
  console.log("EdgeBot Extension waking up");
  startKeepAlive();
});

// Initial keep-alive
startKeepAlive();