const ENGINE_URL = "http://127.0.0.1:8765";

let logHistory = [];

function addLog(msg, type="info") {
    const ts = new Date().toLocaleTimeString();
    logHistory.unshift(`[${ts}] ${msg}`);
    if (logHistory.length > 20) logHistory.pop();
    const container = document.getElementById('log-container');
    if (container) {
        container.innerHTML = logHistory.map(m => `<div class="log-entry">${m}</div>`).join('');
    }
}

function getStatusIcon(status) {
    switch (status) {
        case 'warming_up': return '🔥';
        case 'ready':      return '✅';
        case 'trading':    return '⚡';
        default:           return '●';
    }
}

function formatStatusLabel(status) {
    switch (status) {
        case 'warming_up':   return 'Warming Up';
        case 'ready':        return 'Ready to Trade';
        case 'trading':      return 'Trading Active';
        case 'disconnected': return 'Disconnected';
        default:             return status;
    }
}

function updateUI(data) {
    const banner = document.getElementById('status-banner');
    const pulse = document.getElementById('status-pulse');
    const statusText = document.getElementById('status-text');
    const warmupSection = document.getElementById('warmup-section');
    const warmupBar = document.getElementById('warmup-bar');
    const warmupPct = document.getElementById('warmup-pct');
    const warmupDetail = document.getElementById('warmup-detail');

    // ── Determine status ──
    let botStatus = data.bot_status || 'warming_up';
    if (!data.status || data.status !== 'running') {
        botStatus = 'disconnected';
    }

    // ── Update banner ──
    banner.className = `status-banner ${botStatus}`;
    pulse.className = `status-pulse ${botStatus}`;
    statusText.textContent = `${getStatusIcon(botStatus)} ${formatStatusLabel(botStatus)}`;

    // ── Warmup progress ──
    const required = data.warmup_required || 220;
    const avgCandles = data.warmup_avg || 0;
    const pct = Math.min(Math.round((avgCandles / required) * 100), 100);

    if (botStatus === 'warming_up') {
        warmupSection.className = 'warmup-section visible';
        warmupBar.style.width = pct + '%';
        warmupPct.textContent = pct + '%';
        warmupDetail.textContent = `${avgCandles} / ${required} candles avg`;
    } else {
        warmupSection.className = 'warmup-section'; // hidden
    }

    // ── Current asset ──
    const assetEl = document.getElementById('current-asset');
    if (assetEl) {
        assetEl.textContent = data.current_asset || '---';
    }
    const sessionEl = document.getElementById('session-tag');
    if (sessionEl) {
        sessionEl.textContent = data.session || '---';
    }

    // ── Balance ──
    const bal = Number(data.balance).toLocaleString(undefined, {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
    document.getElementById('balance').textContent = '$' + bal;
    document.getElementById('stake').textContent = '$' + Number(data.stake).toFixed(2);
    document.getElementById('active-trades').textContent = data.active_trades || 0;
    document.getElementById('signals').textContent = data.total_signals_today || 0;
    document.getElementById('last-action').textContent = data.last_action || '---';
    document.getElementById('last-trade').textContent = data.last_trade || '---';
    document.getElementById('consecutive-losses').textContent = data.consecutive_losses || 0;

    // Session break
    const sbEl = document.getElementById('session-break');
    if (data.session_break) {
        sbEl.textContent = 'Yes ⏸';
        sbEl.className = 'value yellow';
    } else {
        sbEl.textContent = 'No';
        sbEl.className = 'value green';
    }
}

async function fetchStatus() {
    try {
        const response = await fetch(`${ENGINE_URL}/status`);
        const data = await response.json();
        updateUI(data);
    } catch (error) {
        // Show disconnected state
        const banner = document.getElementById('status-banner');
        const pulse = document.getElementById('status-pulse');
        const statusText = document.getElementById('status-text');
        if (banner) banner.className = 'status-banner disconnected';
        if (pulse) pulse.className = 'status-pulse disconnected';
        if (statusText) statusText.textContent = '● Disconnected';

        // Hide warmup section when disconnected
        const ws = document.getElementById('warmup-section');
        if (ws) ws.className = 'warmup-section';

        addLog('Engine disconnected', 'error');
    }
}

async function setBalance() {
    const input = document.getElementById('balance-input');
    const val = input.value.trim().replace(/[^0-9.]/g, '');
    if (!val || parseFloat(val) <= 0) {
        addLog('Enter a valid balance amount', 'error');
        return;
    }
    try {
        const response = await fetch(`${ENGINE_URL}/set_balance`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ balance: parseFloat(val) })
        });
        const result = await response.json();
        if (result.status === "ok") {
            addLog(`Balance set to $${result.balance}`);
            fetchStatus();
        } else {
            addLog(`Error: ${result.message}`, 'error');
        }
    } catch (e) {
        addLog('Engine not available', 'error');
    }
}

// Set balance on Enter key
document.addEventListener('DOMContentLoaded', () => {
    const input = document.getElementById('balance-input');
    const btn = document.getElementById('set-balance-btn');
    const refreshBtn = document.getElementById('refresh-btn');

    if (btn) btn.addEventListener('click', setBalance);
    if (input) {
        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') setBalance();
        });
    }
    if (refreshBtn) {
        refreshBtn.addEventListener('click', fetchStatus);
    }

    addLog('Popup opened, connecting to engine...');
    fetchStatus();
});

// Auto-refresh every 3 seconds (faster for warmup progress visibility)
setInterval(fetchStatus, 3000);