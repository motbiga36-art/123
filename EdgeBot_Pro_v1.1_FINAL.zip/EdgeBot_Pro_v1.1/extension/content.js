const ENGINE_URL = "http://127.0.0.1:8765";
console.log("EdgeBot: v11 - STEALTH MODE (jitter, mouse events, human typing)");

let candleBuffer = {};
let currentAsset = "";
let favoritesList = [];
let assetCycleIndex = 0;
let lastSwitchTime = 0;
let isExecutingTrade = false;
let historyLoaded = false;

// ── STEALTH HELPERS ──

/** Sleep with jitter: adds random variance to appear human */
function sleep(base, jitter = 0.3) {
    const variance = base * jitter;
    const actual = base - variance + Math.random() * variance * 2;
    return new Promise(r => setTimeout(r, actual));
}

/** Jitter a fixed interval value — returns a new interval to use with setInterval */
function jitterInterval(base, pct = 0.15) {
    return base - base * pct + Math.random() * base * pct * 2;
}

/** Simulate realistic human mouse events on an element before clicking */
async function humanClick(el) {
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const x = rect.left + rect.width * (0.2 + Math.random() * 0.6);
    const y = rect.top + rect.height * (0.2 + Math.random() * 0.6);

    el.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true, clientX: x, clientY: y }));
    await sleep(30 + Math.random() * 70);
    el.dispatchEvent(new MouseEvent('mousemove', { bubbles: true, clientX: x, clientY: y }));
    await sleep(10 + Math.random() * 40);
    el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, clientX: x, clientY: y, button: 0 }));
    await sleep(20 + Math.random() * 50);
    el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, clientX: x, clientY: y, button: 0 }));
    await sleep(5 + Math.random() * 15);
    el.click();
}

/** Type text with human-like randomized delays between characters */
async function humanType(input, text) {
    if (!input) return;
    input.focus();
    input.value = "";
    input.dispatchEvent(new Event('focus', { bubbles: true }));
    await sleep(120, 0.5);
    for (let ch of text) {
        input.value += ch;
        input.dispatchEvent(new Event('input', { bubbles: true }));
        // Random per-character delay: 40-180ms (faster at start, slower later to simulate fatigue)
        const fatigue = 1 + (Math.random() * 0.5);
        await sleep(40 * fatigue, 0.6);
    }
    input.dispatchEvent(new Event('change', { bubbles: true }));
    await sleep(80, 0.5);
    input.blur();
}

/** Shuffle asset cycle slightly — vary index to avoid perfect rotation */
function shuffleCycleIndex(targets) {
    if (targets.length <= 1) return 0;
    // Mostly increment by 1, but occasionally skip or go back
    const rand = Math.random();
    let next;
    if (rand < 0.7) {
        // Normal increment
        next = assetCycleIndex + 1;
    } else if (rand < 0.85) {
        // Skip one
        next = assetCycleIndex + 2;
    } else {
        // Go back one
        next = assetCycleIndex;
    }
    return next % targets.length;
}

// ── SELECTORS ──
const SELECTORS = {
    balance: ".balance-value, .user-balance, .balance-info__value, .balance, [class*=balance]",
    price: ".current-price, .price, .val.value",
    assetLabel: ".current-symbol, [class*=symbol], [class*=pair]",
    assetTrigger: ".current-symbol, [class*=symbol], .assets-block__current, [class*=asset-select]",
    favoritesList: ".alist-favorites",
    favoriteAsset: ".alist-favorites .alist__label",
    assetSearch: "input[placeholder*=search], input[placeholder*=поиск], .asset-search input",
    assetItems: ".alist__item .alist__label",
    amountInput: ".block--bet-amount input, .value__val input",
};

// ── HELPERS ──
function sleepOld(ms) { return new Promise(r => setTimeout(r, ms)); }

function getBalance() {
    let el = document.querySelector(SELECTORS.balance);
    if (el) {
        let t = (el.innerText || el.textContent || "").replace(/[^0-9.]/g, "");
        if (t && parseFloat(t) > 0) return t;
    }
    return "0";
}

function getPrice() {
    let el = document.querySelector(SELECTORS.price);
    if (el) {
        let p = parseFloat(el.innerText.replace(/[^0-9.]/g, ""));
        if (!isNaN(p) && p > 0) return p;
    }
    return 0;
}

function getAsset() {
    let el = document.querySelector(SELECTORS.assetLabel);
    return el ? (el.innerText || "").replace(/[^A-Za-z\/]/g, "") : "unknown";
}

function updateCandles(asset, price) {
    if (!candleBuffer[asset]) candleBuffer[asset] = [];
    const now = Date.now();
    const timeframe = 60 * 1000;
    const candleTime = Math.floor(now / timeframe) * timeframe;
    const buf = candleBuffer[asset];

    if (buf.length === 0 || buf[buf.length - 1].t !== candleTime) {
        buf.push({ t: candleTime, o: price, h: price, l: price, c: price, v: 1 });
        if (buf.length > 500) buf.shift();
    } else {
        let c = buf[buf.length - 1];
        c.h = Math.max(c.h, price);
        c.l = Math.min(c.l, price);
        c.c = price;
        c.v = (c.v || 0) + 1;
    }
}

async function loadHistoryFromEngine() {
    try {
        const response = await fetch(`${ENGINE_URL}/history`);
        const data = await response.json();
        if (data.status === "ok" && data.candles) {
            let loaded = 0;
            for (const [asset, candles] of Object.entries(data.candles)) {
                if (candles && candles.length > 0) {
                    candleBuffer[asset] = candles;
                    loaded += candles.length;
                }
            }
            console.log(`EdgeBot: Loaded ${loaded} history candles from engine`);
            historyLoaded = true;
        }
    } catch (e) {
        console.log("EdgeBot: No history available yet (first run)");
        historyLoaded = false;
    }
}

function readFavorites() {
    try {
        let labels = document.querySelectorAll(SELECTORS.favoriteAsset);
        if (labels && labels.length > 0) {
            let assets = [];
            labels.forEach(el => {
                let name = (el.innerText || el.textContent || "").replace(/[^A-Za-z\/]/g, "");
                if (name && name.includes('/')) assets.push(name);
            });
            if (assets.length > 0) {
                favoritesList = assets;
                console.log(`EdgeBot: Favorites: ${favoritesList.join(', ')}`);
                return true;
            }
        }
    } catch(e) {}
    return false;
}

async function openAssetDropdown() {
    let trigger = document.querySelector(SELECTORS.assetTrigger);
    if (trigger) {
        await humanClick(trigger);
        await sleep(400, 0.4); // jittered wait for dropdown to open
        return true;
    }
    return false;
}

async function closeAssetDropdown() {
    let wrap = document.querySelector(".drop-down-modal-wrap, .assets-block__col-nav");
    if (wrap) {
        await humanClick(wrap);
        await sleep(200, 0.3);
    }
}

async function switchToAsset(targetAsset) {
    if (!targetAsset || targetAsset === currentAsset || isExecutingTrade) return;
    
    // Rate limit with jitter (1500-3000ms)
    const now = Date.now();
    const minInterval = 1500 + Math.random() * 1500;
    if (now - lastSwitchTime < minInterval) return;
    lastSwitchTime = now;
    
    console.log(`EdgeBot: Switching to ${targetAsset}...`);

    let opened = await openAssetDropdown();
    if (!opened) return;

    // Try favorites list first (looks natural — user clicks favorites)
    let items = document.querySelectorAll(SELECTORS.favoriteAsset);
    for (let item of items) {
        try {
            let text = (item.innerText || item.textContent || "").replace(/[^A-Za-z\/]/g, "");
            if (text.toUpperCase() === targetAsset.toUpperCase()) {
                await humanClick(item);
                await sleep(400, 0.5);
                currentAsset = targetAsset;
                console.log(`EdgeBot: Switched to ${targetAsset} (favorites)`);
                return;
            }
        } catch(e) {}
    }

    // Try full asset list
    items = document.querySelectorAll(SELECTORS.assetItems);
    let found = false;
    
    for (let item of items) {
        try {
            let text = (item.innerText || item.textContent || "").replace(/[^A-Za-z\/]/g, "");
            if (text.toUpperCase() === targetAsset.toUpperCase()) {
                await humanClick(item);
                await sleep(400, 0.5);
                currentAsset = targetAsset;
                console.log(`EdgeBot: Switched to ${targetAsset}`);
                found = true;
                break;
            }
        } catch(e) {}
    }

    if (!found) {
        // Use search with human-like typing
        let search = document.querySelector(SELECTORS.assetSearch);
        if (search) {
            await humanType(search, targetAsset);
            await sleep(400, 0.4);
            items = document.querySelectorAll(SELECTORS.assetItems);
            for (let item of items) {
                let text = (item.innerText || "").replace(/[^A-Za-z\/]/g, "");
                if (text.toUpperCase() === targetAsset.toUpperCase()) {
                    await humanClick(item);
                    await sleep(400, 0.5);
                    currentAsset = targetAsset;
                    console.log(`EdgeBot: Switched to ${targetAsset} (search)`);
                    found = true;
                    break;
                }
            }
        }
    }

    if (!found) {
        await closeAssetDropdown();
        console.log(`EdgeBot: Could not find ${targetAsset}`);
    }
}

function nativeSetValue(input, value) {
    if (!input) return;
    let nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    nativeSetter.call(input, value.toFixed(2));
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    input.blur();
}

async function executeTrade(trade) {
    if (isExecutingTrade) return;
    isExecutingTrade = true;
    console.log("EdgeBot: EXECUTING TRADE", trade);

    let inp = document.querySelector(SELECTORS.amountInput);
    if (inp && trade.stake) {
        await humanClick(inp);
        await sleep(200, 0.4);
        nativeSetValue(inp, trade.stake);
    }

    // Random pause before clicking trade button (looks like hesitation)
    await sleep(500, 0.5);
    let btn = document.querySelector(trade.action === "buy" ? ".btn-call" : ".btn-put");
    if (btn) {
        await humanClick(btn);
        console.log("EdgeBot: TRADE EXECUTED!");
        let expiryMs = (trade.expiry || 60) * 1000 + 2000 + Math.random() * 1000;
        setTimeout(async () => {
            let bal = getBalance();
            try {
                await fetch(`${ENGINE_URL}/trade_result`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ type: trade.action, status: "completed", result: "pending", balance: bal })
                });
            } catch(e) {}
            isExecutingTrade = false;
        }, expiryMs);
    } else {
        console.error("EdgeBot: Trade button not found");
        isExecutingTrade = false;
    }
}

async function syncWithEngine() {
    const balance = getBalance();
    const asset = getAsset();
    const price = getPrice();

    if (price > 0) updateCandles(asset, price);
    readFavorites();

    let targets = favoritesList.length > 0 ? favoritesList : [asset];

    // Randomized cycle: shuffle index occasionally to avoid perfect rotation
    assetCycleIndex = shuffleCycleIndex(targets);
    let targetAsset = targets[assetCycleIndex];

    if (targetAsset !== asset && !isExecutingTrade) {
        await switchToAsset(targetAsset);
        return;
    }

    const payload = {
        balance: balance,
        asset: asset,
        candles: candleBuffer[asset] || [],
        timestamp: new Date().toISOString()
    };

    try {
        const response = await fetch(`${ENGINE_URL}/data`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });
        const result = await response.json();

        if (result.action && result.action !== "wait") {
            if (!isExecutingTrade) {
                executeTrade(result);
            }
        } else if (result.switch_target) {
            await switchToAsset(result.switch_target);
            if (result.switch_target !== asset) {
                assetCycleIndex = (assetCycleIndex + 1) % targets.length;
            }
        } else {
            // Jittered pause before next cycle
            await sleep(150, 0.5);
            if (!isExecutingTrade) {
                assetCycleIndex = (assetCycleIndex + 1) % targets.length;
            }
        }
    } catch (e) {
        console.error("EdgeBot: Sync error", e);
    }
}

// ── START ──
setTimeout(async () => {
    console.log("EdgeBot: Starting in STEALTH MODE...");
    
    // Initial jitter (appear as random page load timing)
    await sleep(1800, 0.3);
    
    // Load history from engine
    await loadHistoryFromEngine();
    
    // Random pause before reading favorites
    await sleep(800, 0.4);
    let got = readFavorites();
    if (got) {
        console.log(`EdgeBot: Trading ${favoritesList.length} assets from favorites`);
    } else {
        console.log("EdgeBot: No favorites found. Add assets to favorites!");
    }

    // Initial data ping with jitter
    const balance = getBalance();
    const asset = getAsset();
    if (asset && candleBuffer[asset] && candleBuffer[asset].length > 0) {
        await sleep(400, 0.5);
        try {
            await fetch(`${ENGINE_URL}/data`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    balance: balance,
                    asset: asset,
                    candles: candleBuffer[asset],
                    timestamp: new Date().toISOString()
                })
            });
        } catch(e) {}
    }
    
    // Start trading loop with jittered interval (3000-4000ms)
    const baseInterval = 3500;
    setInterval(() => {
        const jittered = jitterInterval(baseInterval, 0.15);
        setTimeout(syncWithEngine, jittered);
    }, baseInterval);
    
    console.log("EdgeBot: Stealth trading loop active");
}, 1000);