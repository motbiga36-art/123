"""
CandleStore — persistent SQLite-backed candle storage for EdgeBot Systems.

Eliminates the 3.6-hour warmup problem by persisting candles to disk.
On restart the extension can fetch all previously stored candles via /history
and the engine resumes from where it left off.

Design:
  - One table per asset (dynamic), each with a unique constraint on timestamp
    so we never duplicate candles.
  - In-memory cache is the hot path for signal analysis;
    SQLite is the source of truth for restart survival.
  - Every /data POST persists candles to both SQLite and in-memory state.
"""

import logging
import os
import sqlite3

logger = logging.getLogger("TradingEngine.CandleStore")


class CandleStore:
    """Persistent candle storage with in-memory cache."""

    def __init__(self, data_dir=None):
        if data_dir is None:
            engine_dir = os.path.dirname(os.path.abspath(__file__))
            data_dir = os.environ.get("EDGEBOT_DATA_DIR", os.path.dirname(engine_dir))
        self.data_dir = data_dir
        self.db_path = os.path.join(data_dir, "candles.db")
        self.cache = {}  # asset -> [candle dicts sorted by t]
        self._conn = None
        self._open()

    def _open(self):
        os.makedirs(self.data_dir, exist_ok=True)
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        logger.info(f"CandleStore: Opened {self.db_path}")

    @staticmethod
    def _table_name(asset):
        """Return a safe table name for an asset symbol."""
        safe = asset.replace("/", "_").replace("-", "_").replace(" ", "_")
        return f"c_{safe}"

    @staticmethod
    def _asset_from_table(table):
        """Reverse _table_name: 'c_EUR_USD' -> 'EUR/USD'"""
        parts = table[2:].split("_", 1)
        return f"{parts[0]}/{parts[1]}" if len(parts) == 2 else parts[0]

    def _ensure_table(self, asset):
        table = self._table_name(asset)
        self._conn.execute(f"""
            CREATE TABLE IF NOT EXISTS [{table}] (
                t INTEGER PRIMARY KEY,
                o REAL NOT NULL,
                h REAL NOT NULL,
                l REAL NOT NULL,
                c REAL NOT NULL,
                v REAL DEFAULT 0
            )
        """)
        self._conn.commit()

    def store_candles(self, asset, candles):
        """Store a batch of candles for an asset. Merges by timestamp."""
        if not candles:
            return

        self._ensure_table(asset)
        table = self._table_name(asset)

        # Build timestamp -> candle dict for in-memory dedup
        existing = {c["t"]: c for c in self.cache.get(asset, [])}

        inserted = 0
        for c in candles:
            t = int(c.get("t", 0))
            o = float(c.get("o", 0))
            h = float(c.get("h", 0))
            l = float(c.get("l", 0))
            cl = float(c.get("c", 0))
            v = float(c.get("v", 0))

            self._conn.execute(f"""
                INSERT OR REPLACE INTO [{table}] (t, o, h, l, c, v)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (t, o, h, l, cl, v))

            # Always update the cache (insert or replace)
            was_new = t not in existing
            existing[t] = {"t": t, "o": o, "h": h, "l": l, "c": cl, "v": v}
            if was_new:
                inserted += 1

        self._conn.commit()

        # Update cache sorted by timestamp
        self.cache[asset] = sorted(existing.values(), key=lambda x: x["t"])

        if inserted > 0:
            logger.debug(f"CandleStore: {asset} -> stored {inserted} new candles (total: {len(self.cache[asset])})")

    def load_candles(self, asset):
        """Load all stored candles for an asset from SQLite."""
        table = self._table_name(asset)
        try:
            cursor = self._conn.execute(f"SELECT t, o, h, l, c, v FROM [{table}] ORDER BY t ASC")
            rows = cursor.fetchall()
            candles = [{"t": r[0], "o": r[1], "h": r[2], "l": r[3], "c": r[4], "v": r[5]} for r in rows]
            self.cache[asset] = candles
            logger.info(f"CandleStore: Loaded {len(candles)} candles for {asset}")
            return candles
        except sqlite3.OperationalError:
            self.cache[asset] = []
            return []

    def get_candles(self, asset):
        """Get candles from cache, falling back to SQLite."""
        if asset in self.cache and self.cache[asset]:
            return self.cache[asset]
        return self.load_candles(asset)

    def get_all_assets(self):
        """Discover all assets with tables in the database."""
        cursor = self._conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'c\\_%' ESCAPE '\\'"
        )
        assets = []
        for (table,) in cursor.fetchall():
            asset = self._asset_from_table(table)
            # Ensure it's cached
            if asset not in self.cache or not self.cache.get(asset):
                self.load_candles(asset)
            assets.append(asset)
        return assets

    def get_all_candles(self):
        """Get dict of all assets -> [candles]."""
        result = dict(self.cache)
        # Check for any assets in DB not yet in cache
        for asset in self.get_all_assets():
            if asset not in result:
                result[asset] = self.load_candles(asset)
        return result

    def get_counts(self):
        """Return dict of asset -> candle count."""
        return {a: len(c) for a, c in self.get_all_candles().items()}

    def close(self):
        """Close the database connection."""
        if self._conn is not None:
            self._conn.close()
            self._conn = None
            logger.info("CandleStore: Closed")
