import pandas as pd
import numpy as np
import logging
from datetime import datetime

logger = logging.getLogger("TradingEngine.Strategy")

class ApexPrimeUHF:
    """Apex Prime UHF v2.1 — Binary Options Strategy for Pocket Option
    Pure pandas/numpy — no pandas-ta dependency.
    """

    def __init__(self):
        self.name = "Apex Prime UHF v2.1"

        # ── Asset Matrix ──
        self.ALL_FOREX = ["EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "USD/CAD", "NZD/USD"]
        self.CRYPTO = ["BTC/USD", "ETH/USD", "LTC/USD", "XRP/USD", "SOL/USD"]
        self.ALL_INDICES = ["S&P500", "NASDAQ", "Dow Jones", "FTSE100"]
        self.ALL_COMMODITIES = ["XAU/USD", "XAG/USD", "USOIL"]
        self.ALL_ASSETS = self.ALL_FOREX + self.CRYPTO + self.ALL_INDICES + self.ALL_COMMODITIES

        # ── Per-asset config ──
        self.ASSET_CFG = {
            "EUR/USD":  {"expiry": 60, "rsi_p": 7, "rsi_ob": 70, "rsi_os": 30, "min_atr": 0.0012, "max_h": 3, "sessions": ["LONDON", "OVERLAP", "US"]},
            "GBP/USD":  {"expiry": 60, "rsi_p": 7, "rsi_ob": 70, "rsi_os": 30, "min_atr": 0.0015, "max_h": 3, "sessions": ["LONDON", "OVERLAP", "US"]},
            "USD/JPY":  {"expiry": 60, "rsi_p": 7, "rsi_ob": 70, "rsi_os": 30, "min_atr": 0.0010, "max_h": 3, "sessions": ["ASIA", "LONDON", "OVERLAP", "US"]},
            "AUD/USD":  {"expiry": 60, "rsi_p": 7, "rsi_ob": 70, "rsi_os": 30, "min_atr": 0.0012, "max_h": 3, "sessions": ["ASIA", "LONDON", "OVERLAP"]},
            "USD/CAD":  {"expiry": 60, "rsi_p": 7, "rsi_ob": 70, "rsi_os": 30, "min_atr": 0.0012, "max_h": 3, "sessions": ["LONDON", "OVERLAP", "US"]},
            "NZD/USD":  {"expiry": 60, "rsi_p": 7, "rsi_ob": 70, "rsi_os": 30, "min_atr": 0.0010, "max_h": 3, "sessions": ["ASIA", "LONDON", "OVERLAP"]},
            "BTC/USD":  {"expiry": 120, "rsi_p": 5, "rsi_ob": 75, "rsi_os": 25, "min_atr": 0.0015, "max_h": 4, "sessions": ["ASIA", "LONDON", "OVERLAP", "US"]},
            "ETH/USD":  {"expiry": 120, "rsi_p": 5, "rsi_ob": 75, "rsi_os": 25, "min_atr": 0.0020, "max_h": 4, "sessions": ["ASIA", "LONDON", "OVERLAP", "US"]},
            "LTC/USD":  {"expiry": 120, "rsi_p": 5, "rsi_ob": 75, "rsi_os": 25, "min_atr": 0.0030, "max_h": 4, "sessions": ["ASIA", "LONDON", "OVERLAP", "US"]},
            "XRP/USD":  {"expiry": 120, "rsi_p": 5, "rsi_ob": 75, "rsi_os": 25, "min_atr": 0.0025, "max_h": 4, "sessions": ["ASIA", "LONDON", "OVERLAP", "US"]},
            "SOL/USD":  {"expiry": 120, "rsi_p": 5, "rsi_ob": 75, "rsi_os": 25, "min_atr": 0.0030, "max_h": 4, "sessions": ["ASIA", "LONDON", "OVERLAP", "US"]},
            "S&P500":   {"expiry": 300, "rsi_p": 9, "rsi_ob": 70, "rsi_os": 30, "min_atr": 5.0,   "max_h": 2, "sessions": ["OVERLAP", "US"]},
            "NASDAQ":   {"expiry": 300, "rsi_p": 9, "rsi_ob": 70, "rsi_os": 30, "min_atr": 15.0,  "max_h": 2, "sessions": ["OVERLAP", "US"]},
            "Dow Jones": {"expiry": 300, "rsi_p": 9, "rsi_ob": 70, "rsi_os": 30, "min_atr": 40.0,  "max_h": 2, "sessions": ["OVERLAP", "US"]},
            "FTSE100":  {"expiry": 300, "rsi_p": 9, "rsi_ob": 70, "rsi_os": 30, "min_atr": 20.0,  "max_h": 2, "sessions": ["LONDON", "OVERLAP"]},
            "XAU/USD":  {"expiry": 300, "rsi_p": 9, "rsi_ob": 70, "rsi_os": 30, "min_atr": 5.0,   "max_h": 2, "sessions": ["LONDON", "OVERLAP", "US"]},
            "XAG/USD":  {"expiry": 300, "rsi_p": 9, "rsi_ob": 70, "rsi_os": 30, "min_atr": 0.15,  "max_h": 2, "sessions": ["LONDON", "OVERLAP", "US"]},
            "USOIL":    {"expiry": 300, "rsi_p": 9, "rsi_ob": 70, "rsi_os": 30, "min_atr": 0.30,  "max_h": 2, "sessions": ["LONDON", "OVERLAP", "US"]},
        }

    # ── Manual indicator calculations (pure numpy/pandas, no pandas-ta) ──

    def _ema(self, series, period):
        return series.ewm(span=period, adjust=False).mean()

    def _sma(self, series, period):
        return series.rolling(window=period).mean()

    def _rsi(self, series, period=14):
        delta = series.diff()
        gain = delta.where(delta > 0, 0.0)
        loss = (-delta).where(delta < 0, 0.0)
        avg_gain = gain.rolling(window=period, min_periods=period).mean()
        avg_loss = loss.rolling(window=period, min_periods=period).mean()
        for i in range(period, len(avg_gain)):
            avg_gain.iloc[i] = (avg_gain.iloc[i-1] * (period - 1) + gain.iloc[i]) / period
            avg_loss.iloc[i] = (avg_loss.iloc[i-1] * (period - 1) + loss.iloc[i]) / period
        rs = avg_gain / avg_loss.replace(0, np.nan)
        return 100 - (100 / (1 + rs))

    def _bbands(self, series, period=20, std_dev=2):
        sma = self._sma(series, period)
        std = series.rolling(window=period).std(ddof=0)
        return sma + std_dev * std, sma, sma - std_dev * std

    def _stoch(self, high, low, close, kp=5, dp=3, smooth=3):
        low_min = low.rolling(window=kp).min()
        high_max = high.rolling(window=kp).max()
        k = 100 * (close - low_min) / (high_max - low_min).replace(0, np.nan)
        k = k.rolling(window=smooth).mean()
        d = k.rolling(window=dp).mean()
        return k, d

    def _atr(self, high, low, close, period=14):
        hl = high - low
        hc = (high - close.shift()).abs()
        lc = (low - close.shift()).abs()
        tr = pd.concat([hl, hc, lc], axis=1).max(axis=1)
        return tr.rolling(window=period).mean()

    def get_session(self):
        hour = datetime.utcnow().hour
        if 0 <= hour < 8: return "ASIA"
        elif 8 <= hour < 13: return "LONDON"
        elif 13 <= hour < 16: return "OVERLAP"
        elif 16 <= hour < 21: return "US"
        else: return "ASIA"

    def is_asset_allowed(self, asset_id, session):
        if asset_id not in self.ASSET_CFG:
            return False
        return session in self.ASSET_CFG[asset_id]["sessions"]

    def check_signal(self, asset_id, df):
        """
        df: DataFrame with columns [timestamp/t, open/o, high/h, low/l, close/c, volume/v]
        Returns: {"action": "buy"/"sell"/"wait", "reason": "...", "expiry": N}
        """
        if asset_id not in self.ASSET_CFG:
            return {"action": "wait", "reason": "Unknown asset"}

        # Normalize columns
        ren = {'o': 'open', 'h': 'high', 'l': 'low', 'c': 'close', 'v': 'volume', 't': 'timestamp'}
        df = df.rename(columns={k: v for k, v in ren.items() if k in df.columns})

        if len(df) < 220:
            return {"action": "wait", "reason": f"Insufficient data ({len(df)})"}

        cfg = self.ASSET_CFG[asset_id]
        close = pd.to_numeric(df['close'], errors='coerce')
        high = pd.to_numeric(df['high'], errors='coerce')
        low = pd.to_numeric(df['low'], errors='coerce')
        vol = pd.to_numeric(df['volume'], errors='coerce') if 'volume' in df.columns else pd.Series(1.0, index=close.index)

        # ── Calculate indicators ──
        ema7 = self._ema(close, 7)
        ema14 = self._ema(close, 14)
        ema50 = self._ema(close, 50)
        ema200 = self._ema(close, 200)
        bb_u, bb_m, bb_l = self._bbands(close, 20, 2)
        rsi = self._rsi(close, cfg["rsi_p"])
        sk, sd = self._stoch(high, low, close, 5, 3, 3)
        atr = self._atr(high, low, close, 14)
        vsma20 = self._sma(vol, 20)

        # Current values
        c = {
            'close': close.iloc[-1], 'open': df['open'].iloc[-1],
            'high': high.iloc[-1], 'low': low.iloc[-1],
            'vol': vol.iloc[-1], 'ema7': ema7.iloc[-1],
            'ema14': ema14.iloc[-1], 'ema50': ema50.iloc[-1],
            'ema200': ema200.iloc[-1], 'bb_m': bb_m.iloc[-1],
            'bb_u': bb_u.iloc[-1], 'bb_l': bb_l.iloc[-1],
            'rsi': rsi.iloc[-1], 'sk': sk.iloc[-1], 'sd': sd.iloc[-1],
            'atr': atr.iloc[-1], 'vsma': vsma20.iloc[-1],
        }
        p_close = close.iloc[-2]
        p_open = df['open'].iloc[-2]
        p_ema7 = ema7.iloc[-2]
        p_sk = sk.iloc[-2]
        p_sd = sd.iloc[-2]
        p_rsi = rsi.iloc[-2]

        if any(pd.isna(v) for v in c.values()):
            return {"action": "wait", "reason": "NaN indicators"}

        # ── PRE-FILTERS ──
        if c['atr'] < cfg["min_atr"]:
            return {"action": "wait", "reason": f"Low ATR"}

        bb_w = c['bb_u'] - c['bb_l']
        if bb_w < c['bb_m'] * 0.001:
            return {"action": "wait", "reason": "BB squeeze"}

        # ══════════════════════════════════════════════════════
        # FINAL v2.1: Wick Filter — body * 2 (was body * 3)
        # ══════════════════════════════════════════════════════
        body = abs(c['close'] - c['open'])
        wick = max(c['high'] - max(c['close'], c['open']), min(c['close'], c['open']) - c['low'])
        if body > 0 and wick > body * 2:
            return {"action": "wait", "reason": "Long wick"}

        # ══════════════════════════════════════════════════════
        # FINAL v2.1: Volume Filter — 1.2x SMA(20) confirmation
        # ══════════════════════════════════════════════════════
        if c['vol'] < c['vsma'] * 1.2:
            return {"action": "wait", "reason": "Low volume"}

        # ── TREND ──
        is_crypto = asset_id in self.CRYPTO
        trend_ema = c['ema200'] if is_crypto else c['ema50']
        trend_up = c['close'] > trend_ema
        trend_dn = c['close'] < trend_ema

        # ── CALL ──
        if trend_up:
            if c['ema7'] > c['ema14'] and c['close'] > c['ema50']:
                if c['close'] > c['bb_m']:
                    # FINAL v2.1: sk < 70 (was < 80)
                    if c['sk'] > c['sd'] and c['sk'] < 70:
                        if c['rsi'] > 50 and c['rsi'] < cfg["rsi_ob"]:
                            if p_close > p_ema7 and c['close'] > c['open']:
                                return {"action": "buy", "reason": "CALL", "expiry": cfg["expiry"]}

        # ── PUT ──
        if trend_dn:
            if c['ema7'] < c['ema14'] and c['close'] < c['ema50']:
                if c['close'] < c['bb_m']:
                    # FINAL v2.1: sk > 30 (was > 20)
                    if c['sk'] < c['sd'] and c['sk'] > 30:
                        if c['rsi'] < 50 and c['rsi'] > cfg["rsi_os"]:
                            if p_close < p_ema7 and c['close'] < c['open']:
                                return {"action": "sell", "reason": "PUT", "expiry": cfg["expiry"]}

        return {"action": "wait", "reason": "No entry"}