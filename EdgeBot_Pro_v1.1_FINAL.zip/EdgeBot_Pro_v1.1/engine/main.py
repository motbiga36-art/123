import uvicorn
from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
import logging
import os
import json
from datetime import datetime, time, timedelta
import random
from collections import defaultdict
import pandas as pd

from logger import setup_logger, TradeLogger
from strategy import ApexPrimeUHF
from risk_manager import RiskManager
from candle_store import CandleStore

# ── Environment-aware paths ──
ENGINE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.environ.get("EDGEBOT_DATA_DIR", os.path.dirname(ENGINE_DIR))  # default: EdgeBot root
LOG_DIR = os.path.join(DATA_DIR, "logs")
REPORT_DIR = os.path.join(DATA_DIR, "reports")
os.makedirs(LOG_DIR, exist_ok=True)
os.makedirs(REPORT_DIR, exist_ok=True)

# ── Initialize persistent candle store ──
candle_store = CandleStore(data_dir=DATA_DIR)

# ── Config loading (multiple fallback paths) ──
config_paths = [
    os.path.join(ENGINE_DIR, "config.json"),       # engine/config.json
    os.path.join(DATA_DIR, "config.json"),           # EdgeBot root / config.json
    os.environ.get("EDGEBOT_CONFIG"),                # Full path via env var
]
config = {
    "initial_balance": 50000.0,
    "stake_pct": 0.01,
    "loss_multiplier": 1.22,
    "win_multiplier": 0.9,
    "daily_stop_loss": 0.50,
    "max_concurrent": 1,
    "night_mode_start": "00:00",
    "night_mode_end": "00:00",
    "session_break_interval": 7200,
}
for p in config_paths:
    if p and os.path.exists(p):
        with open(p, "r") as f:
            config.update(json.load(f))
        print(f"[EdgeBot] Loaded config from: {p}")
        break

# ── Logging setup ──
log_file = os.path.join(LOG_DIR, "engine.log")
logger = setup_logger("TradingEngine", log_file)
trade_logger = TradeLogger(csv_path=os.path.join(LOG_DIR, "trades.csv"))

app = FastAPI(title="EdgeBot Trading Engine")

# CORS — allow extension to call engine
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

strategy = ApexPrimeUHF()
risk_manager = RiskManager(config)

# ── Load persisted candles from disk ──
stored_candles = candle_store.get_all_candles()
logger.info(f"CandleStore: Loaded {sum(len(v) for v in stored_candles.values())} candles across {len(stored_candles)} assets from disk")

state = {
    "candles": stored_candles,
    "last_signal_per_asset": {},
    "signals_last_hour": defaultdict(list),
    "session_start": datetime.now(),
    "last_action": "",
    "last_trade_result": "",
    "awaiting_trade_result": False,
    "current_asset": "",
    "daily_check_done": False,
    "last_date": datetime.now().date(),
}

def get_session():
    return strategy.get_session()

def check_session_break():
    elapsed = (datetime.now() - state["session_start"]).total_seconds()
    interval = config.get("session_break_interval", 7200)
    if elapsed > interval:
        if elapsed < interval + 1200:
            return True
        else:
            state["session_start"] = datetime.now()
    return False

def count_signals_last_hour(asset):
    cutoff = datetime.now() - timedelta(hours=1)
    count = sum(1 for t in state["signals_last_hour"].get(asset, []) if t > cutoff)
    return count

@app.get("/")
async def root():
    return await get_status()

@app.get("/status")
async def get_status():
    # Compute warmup progress per asset
    warmup_progress = {}
    for asset, candles in state["candles"].items():
        warmup_progress[asset] = len(candles)
    
    # Determine overall bot status
    required_candles = 220
    total_candles = sum(len(v) for v in state["candles"].values())
    total_assets = max(len(state["candles"]), 1)
    avg_candles = total_candles / total_assets if total_assets > 0 else 0
    
    is_warming_up = avg_candles < required_candles
    is_trading = state.get("awaiting_trade_result", False) or risk_manager.active_trades > 0
    
    if is_trading:
        bot_status = "trading"
    elif is_warming_up:
        bot_status = "warming_up"
    else:
        bot_status = "ready"
    
    return {
        "status": "running",
        "bot_status": bot_status,
        "balance": risk_manager.balance,
        "stake": risk_manager.get_stake(),
        "can_trade": risk_manager.can_trade(),
        "session": get_session(),
        "active_trades": risk_manager.active_trades,
        "total_signals_today": risk_manager.total_signals_today,
        "last_action": state["last_action"],
        "last_trade": state["last_trade_result"],
        "consecutive_losses": risk_manager.consecutive_losses,
        "session_break": check_session_break(),
        "current_asset": state["current_asset"],
        "warmup_progress": warmup_progress,
        "warmup_required": required_candles,
        "warmup_avg": round(avg_candles, 1),
    }

@app.post("/data")
async def receive_data(request: Request):
    data = await request.json()
    asset = data.get("asset", "unknown")
    balance = data.get("balance", "0")
    
    state["current_asset"] = asset

    # ── Update Balance ──
    try:
        val = float(str(balance).replace("$", "").replace(",", ""))
        if val > 0:
            old = risk_manager.balance
            risk_manager.update_balance(val)
            # IMPORTANT: reset day_start_balance to real balance on first update
            # so -50% stop-loss is calculated from REAL balance, not config
            if abs(risk_manager.day_start_balance - val) > risk_manager.day_start_balance * 0.5:
                risk_manager.day_start_balance = val
                risk_manager.start_balance = val
                risk_manager.current_stake = max(val * config.get("stake_pct", 0.01), 1.0)
                logger.info(f"Balance initialized: ${val:.2f}, day_start set to ${val:.2f}")
            elif abs(val - old) > 0.01:
                logger.info(f"Balance: ${old:.2f} -> ${val:.2f}")
    except: pass

    # ── New day check ──
    today = datetime.now().date()
    if state["last_date"] != today:
        risk_manager.new_trading_day()
        state["last_date"] = today
        state["signals_last_hour"] = defaultdict(list)
        logger.info("New trading day started")
        state["daily_check_done"] = False

    # ── Update Candles (persisted to SQLite) ──
    if "candles" in data and isinstance(data["candles"], list) and len(data["candles"]) > 0:
        candle_store.store_candles(asset, data["candles"])
        # Always sync in-memory state from the store (guarantees dedup + ordering)
        state["candles"][asset] = candle_store.get_candles(asset)

    # ── Check Restrictions ──
    if check_session_break():
        return {"action": "wait", "reason": "Session break"}

    if not risk_manager.can_trade():
        reason = "Stop-loss" if risk_manager.is_stop_loss_hit() else "Risk limit"
        return {"action": "wait", "reason": reason}

    if state["awaiting_trade_result"]:
        return {"action": "wait", "reason": "Awaiting result"}

    # ── Session filter ──
    session = get_session()
    if not strategy.is_asset_allowed(asset, session):
        return {"action": "wait", "reason": f"Not in {session} session"}

    # ── Analyze ──
    if asset not in state["candles"] or len(state["candles"][asset]) < 220:
        return {"action": "wait", "reason": f"Collecting data ({len(state['candles'].get(asset, []))}/220)"}

    df = pd.DataFrame(state["candles"][asset])
    signal = strategy.check_signal(asset, df)

    if signal["action"] != "wait":
        # Check hourly limit
        hourly = count_signals_last_hour(asset)
        max_hourly = strategy.ASSET_CFG.get(asset, {}).get("max_per_hour", 3)
        if hourly >= max_hourly:
            return {"action": "wait", "reason": "Hourly limit"}

        # Check cooldown (5 min per asset)
        last_sig = state["last_signal_per_asset"].get(asset)
        if last_sig and (datetime.now() - last_sig).total_seconds() < 300:
            return {"action": "wait", "reason": "Cooldown 5m"}

        # EXECUTE
        stake = risk_manager.get_stake()
        state["awaiting_trade_result"] = True
        state["last_signal_per_asset"][asset] = datetime.now()
        state["signals_last_hour"][asset].append(datetime.now())
        state["last_action"] = f"{signal['action'].upper()} ${stake} {asset}"

        risk_manager.increment_trades()
        trade_logger.log_trade(asset, signal['action'].upper(), stake,
                               signal['expiry'], signal['reason'], risk_manager.balance)
        logger.info(f"SIGNAL: {signal['action'].upper()} | {asset} | ${stake} | {signal['reason']}")

        return {"action": signal["action"], "stake": stake, "expiry": signal["expiry"], "asset": asset}

    return {"action": "wait", "reason": signal["reason"]}

@app.post("/trade_result")
async def trade_result(request: Request):
    data = await request.json()
    state["awaiting_trade_result"] = False
    risk_manager.decrement_trades()

    if "result" in data:
        res = data["result"].lower()
        nb = data.get("balance", risk_manager.balance)
        if nb and float(nb) > 0:
            risk_manager.update_balance(float(nb))
        risk_manager.on_trade_result(res)
        trade_logger.update_last_trade(res, risk_manager.balance)
        state["last_trade_result"] = res.upper()
        logger.info(f"TRADE: {res.upper()} | Balance: ${risk_manager.balance:.2f}")

    return {"status": "ok"}

@app.post("/set_balance")
async def set_balance(request: Request):
    data = await request.json()
    try:
        val = float(data.get("balance", 0))
        if val > 0:
            risk_manager.update_balance(val)
            risk_manager.start_balance = val
            risk_manager.day_start_balance = val
            risk_manager.current_stake = max(val * config.get("stake_pct", 0.01), 1.0)
            logger.info(f"Manual balance: ${val:.2f}")
            return {"status": "ok", "balance": val}
    except: pass
    return {"status": "error"}

@app.get("/history")
async def get_history(asset: str = None):
    """Return all stored candle data so the extension can skip warmup after a refresh.
    
    If `asset` query param is provided, return candles for that specific asset only
    (useful for assets with '/' in the name that are hard to path-encode).
    """
    if asset:
        return await get_asset_history(asset)
    
    # Sync with persistent store first
    all_candles = candle_store.get_all_candles()
    state["candles"] = all_candles
    return {
        "status": "ok",
        "candles": all_candles,
        "assets": list(all_candles.keys()),
        "counts": candle_store.get_counts(),
    }

@app.get("/history/{asset}")
async def get_asset_history(asset: str):
    """Return candle data for a specific asset from persistent store."""
    candles = candle_store.get_candles(asset)
    # Sync back to in-memory state
    state["candles"][asset] = candles
    return {
        "status": "ok",
        "asset": asset,
        "candles": candles,
        "count": len(candles),
    }

if __name__ == "__main__":
    host = os.environ.get("EDGEBOT_HOST", "0.0.0.0")
    port = int(os.environ.get("EDGEBOT_PORT", "8765"))
    print(f"[EdgeBot] Apex Prime UHF v2.1 — Favorites mode")
    print(f"[EdgeBot] Logs: {log_file}")
    print(f"[EdgeBot] Host: {host}:{port}")
    print(f"[EdgeBot] Max concurrent: {risk_manager.max_concurrent_trades}")
    print(f"[EdgeBot] Stop-loss: {risk_manager.daily_stop_loss_pct*100}%")
    uvicorn.run(app, host=host, port=port)