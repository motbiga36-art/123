@echo off
title EdgeBot v1.5 - STEALTH + Yahoo Finance
color 0A
echo ============================================
echo   EdgeBot v1.5
echo   Apex Prime UHF v2.1 + Risk Management
echo   Yahoo Finance + Live WebSocket
echo ============================================
echo.

if not exist "%~dp0engine\venv\" (
    echo [ERROR] Run install.bat first
    pause
    exit /b 1
)

echo Starting STEALTH ENGINE...
echo Strategy: Apex Prime UHF v2.1 (14 pairs)
echo Risk: 1 trade, -50%% stop-loss, 3%% Cycle MM
echo History: Yahoo Finance (500 M1 candles) + live WS
echo Behavior: 60-80s per pair (stealth human mode)
echo.
echo Address: http://127.0.0.1:8765
echo Status:  http://127.0.0.1:8765/status
echo Press Ctrl+C to stop
echo.
echo IMPORTANT:
echo  1. Chrome with EdgeBot extension must be open
echo  2. Go to https://pocketoption.com (DEMO)
echo  3. Add your 14 pairs to FAVORITES
echo  4. Bot is FULLY STEALTH — no console logs
echo  5. No backtest CSV — only real yfinance + WS data
echo.

cd /d "%~dp0engine"
call venv\Scripts\activate.bat
python main.py

pause