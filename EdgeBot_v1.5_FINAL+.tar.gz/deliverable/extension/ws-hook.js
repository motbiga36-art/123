/**
 * EdgeBot v1.3 — WebSocket Hook (injected into page context)
 * This file runs IN the page context, not the content script context.
 * It intercepts WebSocket messages from Pocket Option and forwards them to content.js via postMessage.
 */
(function() {
    'use strict';
    // Only run once
    if (window.__edgebot_ws_hooked) return;
    window.__edgebot_ws_hooked = true;

    var edgeWsList = [];

    // Hook WebSocket constructor to capture messages
    var OrigWS = window.WebSocket;
    window.WebSocket = function(url, protocols) {
        var ws = protocols ? new OrigWS(url, protocols) : new OrigWS(url);
        edgeWsList.push(ws);

        ws.addEventListener('message', function(e) {
            try {
                var d = JSON.parse(e.data);
                // Forward ALL parsed messages — content script filters what matters
                window.postMessage({ source: 'edgebot-ws', data: d, url: url }, '*');
            } catch(e) {}
        });

        return ws;
    };
    window.WebSocket.prototype = OrigWS.prototype;
    window.WebSocket.CONNECTING = 0;
    window.WebSocket.OPEN = 1;
    window.WebSocket.CLOSING = 2;
    window.WebSocket.CLOSED = 3;
})();