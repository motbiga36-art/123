/**
 * EdgeBot v1.3 — STEALTH EDITION
 * 
 * KEY STEALTH FEATURES:
 *  - ZERO console.log calls (completely silent)
 *  - Timing jitter (2.5-5s loop instead of fixed 3s)
 *  - Randomised delays with human-like variance
 *  - ws-hook.js injected via chrome.runtime.getURL (CSP-compliant)
 *  - Works with only the 14 user-defined pairs
 */

// ── Config ──
const ENGINE_URL = "http://127.0.0.1:8765";

// ── State ──
let candleBuffer = {};
let currentAsset = "";
let favoritesList = [];
let isExecutingTrade = false;
let isSyncing = false;
let balanceDetected = false;
let assetStayStart = Date.now();
let assetCycleDone = false;
let tradeEndTime = 0;
let restAfterTrade = false;
let historyLoaded = false;
let minStay = 0;
let maxStay = 0;
let loopCounter = 0;

// ── DOM Selectors (strengthened, no [class*=...] broad matches) ──
const SEL = {
    // ⬅ FIX: PO uses js-balance-demo with data-hd-show attribute
    balance: ".js-balance-demo, .balance-value, .user-balance, .balance-info__value, [class*=balance]",
    price:   ".current-price, .price, .trading-panel__current-price",
    assetLabel:     ".current-symbol, .trading-panel__symbol",
    assetTrigger:   ".current-symbol, .assets-block__current",
    alistFavorites: ".alist-favorites",
    favoriteLabel:  ".alist-favorites .alist__label",
    favoritePayout: ".alist-favorites .alist__payout",
    alistAllLabels: ".alist__item .alist__label",
    assetSearch:    "input[placeholder*=search i]",
    amountInput:    ".block--bet-amount input, .value__val input",
    btnCall:        ".btn-call, [data-action=call]",
    btnPut:         ".btn-put, [data-action=put]",
};

// ── Helpers (silent) ──
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function qs(s, ctx) { return (ctx || document).querySelector(s); }
function qsa(s, ctx) { return (ctx || document).querySelectorAll(s); }
function rand(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }

// ── Timing jitter: vary loop interval for natural pattern ──
function nextLoopDelay() {
    // 2.5-5s instead of fixed 3s — less predictable
    return rand(2500, 5000);
}

// ── WebSocket interceptor injection ──
(function injectWSInterceptor() {
    if (document.getElementById('edgebot-ws-hook')) return;
    const s = document.createElement('script');
    s.id = 'edgebot-ws-hook';
    s.src = chrome.runtime.getURL('ws-hook.js');
    document.documentElement.appendChild(s);
    setTimeout(() => { try { s.remove(); } catch(e) {} }, 100);
})();

// ── WebSocket message listener ──
window.addEventListener('message', function (event) {
    if (event.data && event.data.source === 'edgebot-ws') {
        processWSMessage(event.data.data);
    }
});

// ── processWSMessage — parse OHLC candles from WS feed ──
function processWSMessage(data) {
    if (!data || typeof data !== 'object') return;

    let candles = null;
    if (data.name === 'candle' && data.msg && Array.isArray(data.msg.candles)) {
        candles = data.msg.candles;
    } else if (data.name === 'history' && data.msg && Array.isArray(data.msg.candles)) {
        candles = data.msg.candles;
    } else if (Array.isArray(data.candles)) {
        candles = data.candles;
    } else if (data.type === 'candle' && Array.isArray(data.data)) {
        candles = data.data;
    } else if (data.msg && typeof data.msg === 'object') {
        for (const key of ['candles', 'data', 'history', 'ohlc']) {
            if (Array.isArray(data.msg[key]) && data.msg[key].length > 0) {
                const first = data.msg[key][0];
                if (typeof first === 'object' && (first.o !== undefined || first.close !== undefined || first.c !== undefined || first[1] !== undefined)) {
                    candles = data.msg[key];
                    break;
                }
            }
        }
    }

    if (!candles || !Array.isArray(candles) || candles.length === 0) return;

    // ⬅ FIX: accept candles for ANY asset from WS (don't filter by currentAsset)
    let assetKey = data.msg?.asset || data.symbol || currentAsset;
    if (!assetKey || assetKey === 'unknown') assetKey = currentAsset;
    if (!assetKey || assetKey === 'unknown') {
        // Still don't know the asset — try to extract from first candle's data context
        return;
    }

    if (!candleBuffer[assetKey]) candleBuffer[assetKey] = [];

    for (const raw of candles) {
        let t, o, h, l, c, v;
        if (typeof raw === 'object') {
            t = raw.t || raw.time || raw.timestamp || raw.time_period_start;
            o = raw.o || raw.open;
            h = raw.h || raw.high;
            l = raw.l || raw.low;
            c = raw.c || raw.close;
            v = raw.v || raw.volume || raw.vol || 1;
        } else if (Array.isArray(raw)) {
            t = raw[0];
            o = raw[1];
            h = raw[2];
            l = raw[3];
            c = raw[4];
            v = raw[5] || 1;
        } else {
            continue;
        }

        if (typeof t === 'string') t = new Date(t).getTime();
        if (t && t < 1e12) t *= 1000;
        if (!t || o === undefined || h === undefined || l === undefined || c === undefined) continue;
        if (isNaN(o) || isNaN(h) || isNaN(l) || isNaN(c)) continue;

        const candleTime = Math.floor(t / 60000) * 60000;
        const existingIdx = candleBuffer[assetKey].findIndex(x => x.t === candleTime);
        if (existingIdx >= 0) {
            const ex = candleBuffer[assetKey][existingIdx];
            ex.h = Math.max(ex.h, h);
            ex.l = Math.min(ex.l, l);
            ex.c = c;
            ex.v = (ex.v || 0) + (v || 1);
        } else {
            candleBuffer[assetKey].push({ t: candleTime, o, h, l, c, v: v || 1 });
        }
    }

    candleBuffer[assetKey].sort((a, b) => a.t - b.t);
    if (candleBuffer[assetKey].length > 1000) {
        candleBuffer[assetKey] = candleBuffer[assetKey].slice(-1000);
    }
}

// ── 1-min candle builder from price tick (fallback) ──
function updateCandles(asset, price) {
    if (!asset || asset === 'unknown' || !price || price <= 0) return;
    if (!candleBuffer[asset]) candleBuffer[asset] = [];
    const now = Date.now();
    const candleTime = Math.floor(now / 60000) * 60000;
    const buf = candleBuffer[asset];
    if (buf.length === 0 || buf[buf.length - 1].t !== candleTime) {
        buf.push({ t: candleTime, o: price, h: price, l: price, c: price, v: 1 });
        if (buf.length > 1000) buf.shift();
    } else {
        const c = buf[buf.length - 1];
        c.h = Math.max(c.h, price);
        c.l = Math.min(c.l, price);
        c.c = price;
        c.v = (c.v || 0) + 1;
    }
}

// ── DOM readers ──
function getBalance() {
    let el = qs(SEL.balance);
    if (el) {
        let t = (el.innerText || el.textContent || "").replace(/[^0-9.]/g, "");
        if (t && parseFloat(t) > 0) return t;
    }
    return "0";
}

function getPrice() {
    let el = qs(SEL.price);
    if (el) {
        let p = parseFloat(el.innerText.replace(/[^0-9.]/g, ""));
        if (!isNaN(p) && p > 0) return p;
    }
    return 0;
}

function getAsset() {
    let el = qs(SEL.assetLabel);
    if (!el) return "unknown";
    let text = (el.innerText || el.textContent || "").replace(/[^A-Za-z0-9\/\-\.]/g, "");
    if (/^[A-Z]{3}[A-Z]{3}$/.test(text)) {
        text = text.slice(0, 3) + '/' + text.slice(3);
    }
    return text || "unknown";
}

function parsePayout(text) {
    let n = parseFloat(text.replace(/[^0-9.]/g, ""));
    return isNaN(n) ? 0 : n;
}

function readFavorites() {
    try {
        let items = qsa(SEL.favoriteLabel);
        let payouts = qsa(SEL.favoritePayout);
        if (items && items.length > 0) {
            let assets = [];
            for (let i = 0; i < items.length; i++) {
                let name = (items[i].innerText || "").replace(/[^A-Za-z\/]/g, "");
                let payout = payouts[i] ? parsePayout(payouts[i].innerText) : 0;
                if (name && name.includes('/')) {
                    assets.push({ name, payout, allowed: payout >= 70 });
                }
            }
            if (assets.length > 0) {
                favoritesList = assets;
                return true;
            }
        }
    } catch (e) { /* silent */ }
    return false;
}

function getNextTarget() {
    let allowed = favoritesList.filter(a => a.allowed);
    if (allowed.length === 0) return null;
    let idx = 0;
    if (currentAsset) {
        let curIdx = allowed.findIndex(a => a.name === currentAsset);
        if (curIdx >= 0) idx = (curIdx + 1) % allowed.length;
    }
    return allowed[idx];
}

// ⬅ FIX: 60-80 seconds per pair — enough for a full M1 candle to form + human-like behavior
function computeStayBounds() {
    minStay = rand(60000, 70000);   // 60-70s minimum stay
    maxStay = rand(70000, 80000);   // 70-80s maximum stay
}

// ── switchToAsset ──
async function switchToAsset(targetName) {
    if (!targetName || targetName === currentAsset || isExecutingTrade) return false;

    let trigger = qs(SEL.assetTrigger)
        || document.querySelector('.current-symbol')
        || document.querySelector('.trading-panel__header .symbol');
    if (!trigger) return false;

    trigger.click();
    await sleep(rand(600, 1200));

    let labels = qsa(SEL.alistAllLabels)
        || document.querySelectorAll('.alist__item .alist__label');
    let found = false;

    for (let label of labels) {
        try {
            let text = (label.innerText || label.textContent || "").replace(/[^A-Za-z0-9\/\-\.]/g, "");
            if (/^[A-Z]{3}[A-Z]{3}$/.test(text)) {
                text = text.slice(0, 3) + '/' + text.slice(3);
            }
            if (text.toUpperCase() === targetName.toUpperCase()) {
                label.click();
                await sleep(rand(800, 1500));
                currentAsset = targetName;
                assetStayStart = Date.now();
                assetCycleDone = false;
                computeStayBounds();
                found = true;
                break;
            }
        } catch (e) { /* skip */ }
    }

    if (!found) {
        let search = qs(SEL.assetSearch)
            || document.querySelector('input[placeholder*="search" i]');
        if (search) {
            search.value = "";
            search.dispatchEvent(new Event('input', { bubbles: true }));
            await sleep(200);
            for (let ch of targetName) {
                search.value += ch;
                search.dispatchEvent(new Event('input', { bubbles: true }));
                await sleep(rand(40, 100));
            }
            await sleep(rand(500, 1000));
            labels = qsa(SEL.alistAllLabels)
                || document.querySelectorAll('.alist__item .alist__label');
            for (let label of labels) {
                let text = (label.innerText || label.textContent || "").replace(/[^A-Za-z0-9\/\-\.]/g, "");
                if (/^[A-Z]{3}[A-Z]{3}$/.test(text)) text = text.slice(0, 3) + '/' + text.slice(3);
                if (text.toUpperCase() === targetName.toUpperCase()) {
                    label.click();
                    await sleep(rand(800, 1500));
                    currentAsset = targetName;
                    assetStayStart = Date.now();
                    assetCycleDone = false;
                    computeStayBounds();
                    found = true;
                    break;
                }
            }
        }
    }

    if (found) {
        let wrap = document.querySelector(".drop-down-modal-wrap, .modal-overlay");
        if (wrap) { wrap.click(); await sleep(rand(200, 400)); }
    }

    return found;
}

// ── nativeSetValue — React-friendly input setter ──
function nativeSetValue(input, value) {
    if (!input) return;
    let setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    setter.call(input, value);
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
}

// ── setExpiry ──
async function setExpiry(minutes) {
    let tfMap = { 1: "M1", 3: "M3", 5: "M5", 30: "M30", 60: "H1", 240: "H4" };
    let timeField = document.querySelector(".block--expiration-inputs .value__val, .block--expiration-inputs input");
    if (!timeField) return false;
    timeField.click();
    await sleep(rand(500, 900));

    if (tfMap[minutes]) {
        let items = document.querySelectorAll(".dops__timeframes-item");
        for (let item of items) {
            let text = (item.innerText || "").trim().toUpperCase();
            if (text === tfMap[minutes]) {
                item.click();
                await sleep(400);
                return true;
            }
        }
    }

    let rows = document.querySelectorAll(".trading-panel-modal__in .rw");
    if (rows.length >= 2) {
        let minRow = rows[1];
        let currentMin = parseInt(minRow.querySelector("input")?.value || "0");
        let diff = minutes - currentMin;
        if (diff > 0) {
            let plusBtn = minRow.querySelector(".btn-plus");
            if (plusBtn) {
                for (let i = 0; i < diff; i++) { plusBtn.click(); await sleep(rand(60, 120)); }
            }
        } else if (diff < 0) {
            let minusBtn = minRow.querySelector(".btn-minus");
            if (minusBtn) {
                for (let i = 0; i < Math.abs(diff); i++) { minusBtn.click(); await sleep(rand(60, 120)); }
            }
        }
        await sleep(300);
        let wrap = document.querySelector(".drop-down-modal-wrap, .modal-overlay");
        if (wrap) wrap.click();
        await sleep(200);
        return true;
    }

    let wrap = document.querySelector(".drop-down-modal-wrap, .modal-overlay");
    if (wrap) wrap.click();
    return false;
}

// ── executeTrade ──
async function executeTrade(trade) {
    if (isExecutingTrade) return;
    isExecutingTrade = true;
    restAfterTrade = false;

    // Set amount
    let inp = qs(SEL.amountInput);
    if (inp && trade.stake) {
        inp.click();
        await sleep(rand(200, 500));
        nativeSetValue(inp, trade.stake.toFixed(2));
    }

    // Set expiry
    if (trade.expiry) {
        await setExpiry(trade.expiry);
    }

    // HUMAN DELAY 500-2000ms
    await sleep(rand(500, 2000));

    // Click
    let btn = qs(trade.action === "buy" ? SEL.btnCall : SEL.btnPut);
    if (btn) {
        btn.click();

        let waitMs = Math.min((trade.expiry || 1) * 60 * 1000 + 5000, 180000);
        tradeEndTime = Date.now() + waitMs;
        setTimeout(() => {
            isExecutingTrade = false;
            restAfterTrade = true;
            tradeEndTime = Date.now() + rand(120000, 300000);
            setTimeout(() => {
                restAfterTrade = false;
                computeStayBounds();
            }, rand(120000, 300000));
        }, waitMs);
    } else {
        isExecutingTrade = false;
    }
}

// ── syncWithEngine ──
async function syncWithEngine() {
    if (isSyncing) return;
    isSyncing = true;

    try {
        const balance = getBalance();
        const asset = getAsset();
        const price = getPrice();

        if (price > 0) updateCandles(asset, price);

        if (!balanceDetected && parseFloat(balance) > 0) {
            balanceDetected = true;
        }

        if (asset && asset !== currentAsset && asset !== "unknown") {
            currentAsset = asset;
            assetStayStart = Date.now();
            assetCycleDone = false;
            computeStayBounds();
        }

        if (!historyLoaded) {
            try {
                let r = await fetch(`${ENGINE_URL}/history`);
                let data = await r.json();
                if (data.candles) {
                    for (let sym in data.candles) {
                        if (!candleBuffer[sym] || candleBuffer[sym].length === 0) {
                            candleBuffer[sym] = data.candles[sym];
                        }
                    }
                    historyLoaded = true;
                }
            } catch (e) { /* engine not ready yet */ }
        }

        readFavorites();

        if (isExecutingTrade || restAfterTrade) {
            try {
                await fetch(`${ENGINE_URL}/data`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ balance, asset, candles: candleBuffer[asset] || [], timestamp: new Date().toISOString() })
                });
            } catch (e) { /* ignore */ }
            return;
        }

        if (favoritesList.length === 0) {
            try {
                let r = await fetch(`${ENGINE_URL}/data`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ balance, asset, timestamp: new Date().toISOString() })
                });
                let result = await r.json();
                if (result.action && result.action !== "wait") {
                    await executeTrade(result);
                }
            } catch (e) { /* ignore */ }
            return;
        }

        let stayed = Date.now() - (assetStayStart || 0);

        if (stayed < minStay) {
            try {
                await fetch(`${ENGINE_URL}/data`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ balance, asset, candles: candleBuffer[asset] || [], timestamp: new Date().toISOString() })
                });
            } catch (e) { /* ignore */ }
            return;
        }

        if (!assetCycleDone) {
            assetCycleDone = true;
            try {
                let r = await fetch(`${ENGINE_URL}/data`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ balance, asset, candles: candleBuffer[asset] || [], timestamp: new Date().toISOString() })
                });
                let result = await r.json();
                if (result.action && result.action !== "wait") {
                    await executeTrade(result);
                    return;
                }
            } catch (e) { /* ignore */ }
        }

        if (stayed >= maxStay) {
            let target = getNextTarget();
            if (target && target.name !== currentAsset) {
                await switchToAsset(target.name);
            }
        }
    } finally {
        isSyncing = false;
    }
}

// ⬅ STEALTH: jittered loop instead of fixed interval
async function mainLoop() {
    loopCounter++;
    await syncWithEngine();
    setTimeout(mainLoop, nextLoopDelay());
}

// ── Start (completely silent) ──
setTimeout(async () => {
    await sleep(3000);
    readFavorites();
    computeStayBounds();
    // First delay: random 1-3s instead of fixed 1s
    setTimeout(mainLoop, rand(1000, 3000));
}, 3000);