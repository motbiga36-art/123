@echo off
chcp 1251 > nul
title EdgeBot v1.5 FINAL - Installer
color 0A

set "LOG=%~dp0install_log.txt"
echo %date% %time% - EdgeBot Installer started > "%LOG%"

echo ============================================
echo    EdgeBot v1.5 FINAL - Installer
echo    STEALTH + Yahoo Finance
echo ============================================
echo.

:: ====== Step 1: Check Python ======
echo [1/5] Checking Python...
python --version 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found!
    echo.
    echo Download Python 3.11 from https://www.python.org/downloads/
    echo IMPORTANT: Check "Add Python to PATH" during installation
    echo.
    pause
    exit /b 1
)
echo.

:: ====== Step 2: Create venv ======
echo [2/5] Creating virtual environment...
cd /d "%~dp0engine"
if exist "venv" (
    echo [OK] Virtual environment already exists
) else (
    python -m venv venv
    if errorlevel 1 (
        echo [ERROR] Failed to create virtual environment!
        pause
        exit /b 1
    )
    echo [OK] Virtual environment created
)
echo.

:: ====== Step 3: Install packages (with yfinance!) ======
echo [3/5] Installing packages...
echo.
call venv\Scripts\activate.bat
if errorlevel 1 (
    echo [ERROR] Cannot activate virtual environment!
    pause
    exit /b 1
)
echo Virtual environment activated successfully
echo.
echo Installing packages (this may take 3-5 minutes)...
echo.

set FAILED=0

echo --- Installing fastapi ---
pip install fastapi
if errorlevel 1 set FAILED=1

echo --- Installing uvicorn ---
pip install uvicorn
if errorlevel 1 set FAILED=1

echo --- Installing pandas ---
pip install pandas
if errorlevel 1 set FAILED=1

echo --- Installing numpy ---
pip install numpy
if errorlevel 1 set FAILED=1

echo --- Installing yfinance ---
pip install yfinance
if errorlevel 1 set FAILED=1

echo.
if %FAILED%==1 (
    echo [WARNING] Some packages failed. Check output above.
) else (
    echo [OK] All packages installed successfully
)
echo.

:: Verify installation (IMPORTANT: yfinance included!)
echo Verifying installation...
python -c "import uvicorn; import fastapi; import pandas; import numpy; import yfinance; print('[OK] All 5 packages verified!')" 2>&1
if errorlevel 1 (
    echo.
    echo [ERROR] Package verification failed.
    echo Check the error above and try again.
    pause
    exit /b 1
)
echo.

:: ====== Step 4: Check config ======
echo [4/5] Checking configuration...
cd /d "%~dp0"
if exist "config.json" (
    echo [OK] config.json found
) else (
    echo Creating config.json...
    python -c "import json; json.dump({'initial_balance':50000.0,'stake_pct':0.01,'loss_multiplier':1.22,'win_multiplier':0.9,'daily_stop_loss':0.50,'max_concurrent':1,'night_mode_start':'00:00','night_mode_end':'00:00','session_break_interval':7200}, open('config.json','w'), indent=4)"
    echo [OK] config.json created
)
echo.

:: ====== Step 5: Chrome Extension ======
echo [5/5] Chrome Extension setup...
cd /d "%~dp0"
echo.
echo ============================================
echo  CHROME EXTENSION SETUP
echo ============================================
echo.
echo  1. Open Google Chrome
echo  2. Go to: chrome://extensions/
echo  3. Enable "Developer mode" (top right)
echo  4. If EdgeBot already exists — click REMOVE
echo  5. Click "Load unpacked"
echo  6. Select folder: %~dp0extension
echo.
echo  The EdgeBot icon will appear in Chrome toolbar.
echo.
echo ============================================
echo  INSTALLATION COMPLETE!
echo ============================================
echo.
echo  TO START TRADING:
echo  1. Double-click start.bat
echo  2. Open https://pocketoption.com in Chrome
echo  3. Switch to DEMO account
echo  4. Bot fetches 500 M1 candles from Yahoo Finance
echo     and starts analyzing immediately!
echo.
echo  TO STOP: Press Ctrl+C in the engine window
echo  TO MONITOR: Open http://127.0.0.1:8765/status
echo.

set /p RUN_NOW=Start engine now? (Y/N):
if /I "%RUN_NOW%"=="Y" (
    echo.
    echo Starting engine...
    echo Open Chrome with extension and Pocket Option
    echo Press Ctrl+C to stop
    echo.
    cd /d "%~dp0engine"
    call venv\Scripts\activate.bat
    python main.py
    pause
) else (
    echo.
    echo OK. Run start.bat when ready.
    pause
)