@echo off
title EdgeBot Systems v1.0 - TEST MODE
color 0A
echo ============================================
echo   EdgeBot Systems v1.0 - TEST MODE
echo   Checking: balance, expiry, amount,
echo   favorites switching, payout filter
echo ============================================
echo.

if not exist "%~dp0engine\venv\" (
    echo [ERROR] Run install.bat first
    pause
    exit /b 1
)

echo Starting TEST ENGINE...
echo Address: http://127.0.0.1:8765
echo Press Ctrl+C to stop
echo.
echo IMPORTANT:
echo  1. Chrome with EdgeBot extension must be open
echo  2. Go to https://pocketoption.com (DEMO)
echo  3. Add pairs to FAVORITES on PO
echo.

cd /d "%~dp0engine"
call venv\Scripts\activate.bat
python main_test.py

pause