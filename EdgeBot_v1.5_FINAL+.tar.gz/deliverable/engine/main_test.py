import uvicorn
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
import logging
import os
import json
from datetime import datetime
import random

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_DIR = os.path.join(BASE_DIR, "logs")
os.makedirs(LOG_DIR, exist_ok=True)

logger = logging.getLogger("EdgeBot")
logger.setLevel(logging.INFO)
fh = logging.FileHandler(os.path.join(LOG_DIR, "test.log"))
fh.setFormatter(logging.Formatter('%(asctime)s - %(message)s'))
logger.addHandler(fh)
logger.addHandler(logging.StreamHandler())

app = FastAPI(title="EdgeBot TEST MODE")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

balance = 0.0
test_count = 0

@app.get("/")
async def root():
    return {"status": "TEST_MODE", "balance": balance, "tests_done": test_count}

@app.get("/status")
async def status():
    return {"status": "TEST_MODE", "balance": balance, "tests_done": test_count}

@app.post("/data")
async def receive_data(request: Request):
    global balance, test_count
    data = await request.json()
    asset = data.get("asset", "unknown")
    
    # Update balance
    try:
        b = float(str(data.get("balance", "0")).replace("$", "").replace(",", ""))
        if b > 0:
            if balance == 0: logger.info(f"BALANCE: ${b:.2f}")
            balance = b
    except: pass
    
    # ALWAYS return a trade signal (test mode)
    test_count += 1
    direction = random.choice(["buy", "sell"])
    expiry = random.randint(3, 10)
    stake = round(balance * 0.01, 2) if balance > 0 else 10.0
    
    logger.info(f"#{test_count} | {asset} | {direction.upper()} | ${stake} | {expiry}min")
    
    return {
        "action": direction,
        "stake": stake,
        "expiry": expiry,
        "asset": asset,
        "test_mode": True
    }

@app.post("/set_balance")
async def set_balance(request: Request):
    global balance
    data = await request.json()
    try:
        val = float(data.get("balance", 0))
        if val > 0:
            balance = val
            logger.info(f"MANUAL BALANCE: ${val:.2f}")
            return {"status": "ok", "balance": val}
    except: pass
    return {"status": "error"}

if __name__ == "__main__":
    print("=" * 50)
    print("  EDGEBOT — ТЕСТОВЫЙ РЕЖИМ")
    print("  Всегда отвечает сигналом buy/sell")
    print("=" * 50)
    print(f"  Server: http://127.0.0.1:8765")
    print(f"  Logs: {os.path.join(LOG_DIR, 'test.log')}")
    print("=" * 50)
    uvicorn.run(app, host="127.0.0.1", port=8765)