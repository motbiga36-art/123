import uvicorn
from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
import logging
import os
import json
from datetime import datetime, time, timedelta
import random
from collections import defaultdict
import pandas as pd
import asyncio
from contextlib import asynccontextmanager

from logger import setup_logger, TradeLogger
from strategy import ApexPrimeUHF
from risk_manager import RiskManager

# ── Yahoo Finance symbol mapping (PO pair → yfinance ticker) ──
YF_SYMBOLS = {
    "AUD/CAD": "AUDCAD=X",
    "AUD/JPY": "AUDJPY=X",
    "CAD/CHF": "CADCHF=X",
    "CHF/JPY": "CHFJPY=X",
    "EUR/CAD": "EURCAD=X",
    "EUR/GBP": "EURGBP=X",
    "EUR/JPY": "EURJPY=X",
    "GBP/AUD": "GBPAUD=X",
    "GBP/CAD": "GBPCAD=X",
    "GBP/CHF": "GBPCHF=X",
    "GBP/USD": "GBPUSD=X",
    "USD/CAD": "USDCAD=X",
    "USD/JPY": "USDJPY=X",
    "EUR/CHF": "EURCHF=X",
}

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_DIR = os.path.join(BASE_DIR, "logs")
REPORT_DIR = os.path.join(BASE_DIR, "reports")
os.makedirs(LOG_DIR, exist_ok=True)
os.makedirs(REPORT_DIR, exist_ok=True)

config_paths = [
    os.path.join(BASE_DIR, "config.json"),
    os.path.join(os.path.dirname(BASE_DIR), "config.json"),
]
config = {
    "initial_balance": 50000.0,
    "stake_pct": 0.01,
    "loss_multiplier": 1.22,
    "win_multiplier": 0.9,
    "daily_stop_loss": 0.50,
    "max_concurrent": 1,
    "night_mode_start": "00:00",
    "night_mode_end": "00:00",
    "session_break_interval": 7200,
}
for p in config_paths:
    if os.path.exists(p):
        with open(p, "r") as f:
            config.update(json.load(f))
        print(f"[EdgeBot] Loaded config from: {p}")
        break

log_file = os.path.join(LOG_DIR, "engine.log")
logger = setup_logger("TradingEngine", log_file)
trade_logger = TradeLogger(csv_path=os.path.join(LOG_DIR, "trades.csv"))

# ── Lifespan (modern replacement for @app.on_event) ──
@asynccontextmanager
async def lifespan(application):
    # STARTUP
    yf_data = fetch_yfinance_history()
    if yf_data:
        for pair, candles in yf_data.items():
            if pair not in state["candles"] or len(state["candles"].get(pair, [])) < len(candles):
                state["candles"][pair] = candles
                state["candles_changed"] = True
        n_pairs_ready = sum(1 for v in state["candles"].values() if len(v) >= 220)
        print(f"[EdgeBot] {n_pairs_ready}/14 pairs have 220+ candles — ready to trade!")
    else:
        print("[EdgeBot] No Yahoo Finance data. Candles will accumulate from WS only.")

    save_task = asyncio.create_task(auto_save_loop())
    print(f"[EdgeBot] Candle persistence: {CANDLES_FILE}")
    print(f"[EdgeBot] Live + Yahoo Finance candles (stealth, server-side)")
    
    yield  # ← app runs here
    
    # SHUTDOWN
    save_task.cancel()
    save_candles(state["candles"])
    print("[EdgeBot] Candles saved on shutdown")

app = FastAPI(title="EdgeBot Trading Engine", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

strategy = ApexPrimeUHF()
risk_manager = RiskManager(config)

# ── Candle persistence ──
CANDLES_FILE = os.path.join(LOG_DIR, "candles.json")

def load_candles():
    """Load saved candles from disk (survives restarts)"""
    if os.path.exists(CANDLES_FILE):
        try:
            with open(CANDLES_FILE, "r") as f:
                data = json.load(f)
            print(f"[EdgeBot] Loaded {sum(len(v) for v in data.values())} candles from {CANDLES_FILE}")
            return data
        except Exception as e:
            print(f"[EdgeBot] Failed to load candles: {e}")
    return {}

def save_candles(candles):
    """Save candles to disk atomically"""
    try:
        tmp = CANDLES_FILE + ".tmp"
        with open(tmp, "w") as f:
            json.dump(candles, f)
        os.replace(tmp, CANDLES_FILE)
    except Exception as e:
        logger.error(f"Failed to save candles: {e}")

state = {
    "candles": load_candles(),  # ⬅ Load from disk on startup
    "last_signal_per_asset": {},
    "signals_last_hour": defaultdict(list),
    "session_start": datetime.now(),
    "last_action": "",
    "last_trade_result": "",
    "awaiting_trade_result": False,
    "current_asset": "",
    "daily_check_done": False,
    "last_date": datetime.now().date(),
    "candles_changed": False,     # ⬅ flag: need to save?
}

def get_session():
    return strategy.get_session()

def check_session_break():
    elapsed = (datetime.now() - state["session_start"]).total_seconds()
    interval = config.get("session_break_interval", 7200)
    if elapsed > interval:
        if elapsed < interval + 1200:
            return True
        else:
            state["session_start"] = datetime.now()
    return False

def count_signals_last_hour(asset):
    cutoff = datetime.now() - timedelta(hours=1)
    count = sum(1 for t in state["signals_last_hour"].get(asset, []) if t > cutoff)
    return count

# ⬅ FIX: Auto-save candles every 60 seconds to disk
async def auto_save_loop():
    while True:
        await asyncio.sleep(60)
        if state.get("candles_changed"):
            save_candles(state["candles"])
            state["candles_changed"] = False

# ⬅ NEW: Fetch 500 M1 candles from Yahoo Finance for all 14 pairs
def fetch_yfinance_history():
    """Download 500 M1 candles for all 14 pairs via yfinance. Pure server-side, 100% stealth."""
    try:
        import yfinance as yf
    except ImportError:
        print("[EdgeBot] yfinance not installed. Run: pip install yfinance")
        print("[EdgeBot] Falling back to live-only mode (candles will accumulate slowly)")
        return {}

    print("[EdgeBot] Fetching history from Yahoo Finance...")
    history = {}
    total = len(YF_SYMBOLS)
    for i, (pair, ticker) in enumerate(YF_SYMBOLS.items(), 1):
        try:
            df = yf.download(ticker, period="5d", interval="1m", progress=False, auto_adjust=True)
            if df is None or df.empty:
                print(f"[EdgeBot]   [{i}/{total}] {pair} ({ticker}): no data")
                continue

            # Flatten MultiIndex columns if needed
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = df.columns.get_level_values(0)

            candles = []
            for idx, row in df.iterrows():
                ts = int(idx.timestamp() * 1000)
                o = float(row['Open'])
                h = float(row['High'])
                l = float(row['Low'])
                c = float(row['Close'])
                v = float(row.get('Volume', 1))
                # Round to minute boundary
                candle_time = (ts // 60000) * 60000
                candles.append({'t': candle_time, 'o': o, 'h': h, 'l': l, 'c': c, 'v': v})

            # Sort, dedup by timestamp, cap at 500
            candles.sort(key=lambda x: x['t'])
            seen = set()
            unique = []
            for c in candles:
                if c['t'] not in seen:
                    seen.add(c['t'])
                    unique.append(c)
            if len(unique) > 500:
                unique = unique[-500:]

            history[pair] = unique
            print(f"[EdgeBot]   [{i}/{total}] {pair} ({ticker}): {len(unique)} M1 candles")
        except Exception as e:
            print(f"[EdgeBot]   [{i}/{total}] {pair} ({ticker}): error — {e}")

    print(f"[EdgeBot] Yahoo Finance loaded: {len(history)}/{total} pairs")
    return history

@app.get("/history")
async def get_history():
    """Return ONLY real-time candles collected from WebSocket (no CSV)"""
    return {"candles": state["candles"]}

@app.get("/")
async def root():
    return await get_status()

@app.get("/status")
async def get_status():
    # Count candles per asset for status display
    candle_counts = {k: len(v) for k, v in state["candles"].items()}
    return {
        "status": "running",
        "balance": risk_manager.balance,
        "stake": risk_manager.get_stake(),
        "can_trade": risk_manager.can_trade(),
        "session": get_session(),
        "active_trades": risk_manager.active_trades,
        "total_signals_today": risk_manager.total_signals_today,
        "last_action": state["last_action"],
        "last_trade": state["last_trade_result"],
        "consecutive_losses": risk_manager.consecutive_losses,
        "session_break": check_session_break(),
        "current_asset": state["current_asset"],
        "candle_counts": candle_counts,
        "total_candles": sum(candle_counts.values()),
    }

@app.post("/data")
async def receive_data(request: Request):
    data = await request.json()
    asset = data.get("asset", "unknown")
    balance = data.get("balance", "0")
    
    state["current_asset"] = asset

    # ── Update Balance ──
    try:
        val = float(str(balance).replace("$", "").replace(",", ""))
        if val > 0:
            old = risk_manager.balance
            risk_manager.update_balance(val)
            if abs(risk_manager.day_start_balance - val) > risk_manager.day_start_balance * 0.5:
                risk_manager.day_start_balance = val
                risk_manager.start_balance = val
                risk_manager.current_stake = max(val * config.get("stake_pct", 0.01), 1.0)
                logger.info(f"Balance initialized: ${val:.2f}, day_start set to ${val:.2f}")
            elif abs(val - old) > 0.01:
                logger.info(f"Balance: ${old:.2f} -> ${val:.2f}")
    except: pass

    # ── New day check ──
    today = datetime.now().date()
    if state["last_date"] != today:
        risk_manager.new_trading_day()
        state["last_date"] = today
        state["signals_last_hour"] = defaultdict(list)
        logger.info("New trading day started")
        state["daily_check_done"] = False

    # ── Update Candles (from live WS data only — no CSV) ──
    if "candles" in data and isinstance(data["candles"], list) and len(data["candles"]) > 0:
        incoming = data["candles"]
        if asset not in state["candles"]:
            state["candles"][asset] = incoming
            state["candles_changed"] = True
        else:
            # Merge new candles into existing buffer
            existing = state["candles"][asset]
            existing_map = {c["t"]: c for c in existing}
            changed = False
            for c in incoming:
                t = c["t"]
                if t in existing_map:
                    # Update existing (new data may refine OHLC)
                    old = existing_map[t]
                    if old.get("h", 0) < c.get("h", 0) or old.get("l", 999999) > c.get("l", 0) or old.get("c") != c.get("c"):
                        existing_map[t] = c
                        changed = True
                else:
                    existing_map[t] = c
                    changed = True
            if changed:
                state["candles"][asset] = sorted(existing_map.values(), key=lambda x: x["t"])
                if len(state["candles"][asset]) > 1000:
                    state["candles"][asset] = state["candles"][asset][-1000:]
                state["candles_changed"] = True

    # ── Check Restrictions ──
    if check_session_break():
        return {"action": "wait", "reason": "Session break"}

    if not risk_manager.can_trade():
        reason = "Stop-loss" if risk_manager.is_stop_loss_hit() else "Risk limit"
        return {"action": "wait", "reason": reason}

    if state["awaiting_trade_result"]:
        return {"action": "wait", "reason": "Awaiting result"}

    # ── Session filter ──
    session = get_session()
    if not strategy.is_asset_allowed(asset, session):
        return {"action": "wait", "reason": f"Not in {session} session"}

    # ── Analyze ──
    n_candles = len(state["candles"].get(asset, []))
    if n_candles < 220:
        return {"action": "wait", "reason": f"Collecting data ({n_candles}/220)"}

    df = pd.DataFrame(state["candles"][asset])
    signal = strategy.check_signal(asset, df)

    if signal["action"] != "wait":
        # Check hourly limit
        hourly = count_signals_last_hour(asset)
        max_hourly = strategy.ASSET_CFG.get(asset, {}).get("max_per_hour", 3)
        if hourly >= max_hourly:
            return {"action": "wait", "reason": "Hourly limit"}

        # Check cooldown (5 min per asset)
        last_sig = state["last_signal_per_asset"].get(asset)
        if last_sig and (datetime.now() - last_sig).total_seconds() < 300:
            return {"action": "wait", "reason": "Cooldown 5m"}

        # EXECUTE
        stake = risk_manager.get_stake()
        state["awaiting_trade_result"] = True
        state["last_signal_per_asset"][asset] = datetime.now()
        state["signals_last_hour"][asset].append(datetime.now())
        state["last_action"] = f"{signal['action'].upper()} ${stake} {asset}"

        risk_manager.increment_trades()
        trade_logger.log_trade(asset, signal['action'].upper(), stake,
                               signal['expiry'], signal['reason'], risk_manager.balance)
        logger.info(f"SIGNAL: {signal['action'].upper()} | {asset} | ${stake} | {signal['reason']}")

        return {"action": signal["action"], "stake": stake, "expiry": signal["expiry"], "asset": asset}

    return {"action": "wait", "reason": signal["reason"]}

@app.post("/trade_result")
async def trade_result(request: Request):
    data = await request.json()
    state["awaiting_trade_result"] = False
    risk_manager.decrement_trades()

    if "result" in data:
        res = data["result"].lower()
        nb = data.get("balance", risk_manager.balance)
        if nb and float(nb) > 0:
            risk_manager.update_balance(float(nb))
        risk_manager.on_trade_result(res)
        trade_logger.update_last_trade(res, risk_manager.balance)
        state["last_trade_result"] = res.upper()
        logger.info(f"TRADE: {res.upper()} | Balance: ${risk_manager.balance:.2f}")

    return {"status": "ok"}

@app.post("/set_balance")
async def set_balance(request: Request):
    data = await request.json()
    try:
        val = float(data.get("balance", 0))
        if val > 0:
            risk_manager.update_balance(val)
            risk_manager.start_balance = val
            risk_manager.day_start_balance = val
            risk_manager.current_stake = max(val * config.get("stake_pct", 0.01), 1.0)
            logger.info(f"Manual balance: ${val:.2f}")
            return {"status": "ok", "balance": val}
    except: pass
    return {"status": "error"}

if __name__ == "__main__":
    print(f"[EdgeBot] Apex Prime UHF v2.1 — STEALTH + Yahoo Finance")
    print(f"[EdgeBot] Logs: {log_file}")
    print(f"[EdgeBot] Candle persistence: {CANDLES_FILE}")
    print(f"[EdgeBot] Max concurrent: {risk_manager.max_concurrent_trades}")
    print(f"[EdgeBot] Stop-loss: {risk_manager.daily_stop_loss_pct*100}%")
    print(f"[EdgeBot] History: Yahoo Finance (500 M1 candles) + live WebSocket")
    print(f"[EdgeBot] 60-80s per pair — stealth human behavior")
    print(f"[EdgeBot] 100% server-side data fetch — no browser trace")
    uvicorn.run(app, host="127.0.0.1", port=8765)