import uvicorn
from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
import logging
import os
import json
from datetime import datetime, time, timedelta
import random
from collections import defaultdict
import pandas as pd
import asyncio
from contextlib import asynccontextmanager

from logger import setup_logger, TradeLogger
from strategy import ApexPrimeUHF
from risk_manager import RiskManager

# ── Yahoo Finance symbol mapping ──
YF_SYMBOLS = {
    "AUD/CAD": "AUDCAD=X", "AUD/JPY": "AUDJPY=X", "CAD/CHF": "CADCHF=X",
    "CHF/JPY": "CHFJPY=X", "EUR/CAD": "EURCAD=X", "EUR/GBP": "EURGBP=X",
    "EUR/JPY": "EURJPY=X", "GBP/AUD": "GBPAUD=X", "GBP/CAD": "GBPCAD=X",
    "GBP/CHF": "GBPCHF=X", "GBP/USD": "GBPUSD=X", "USD/CAD": "USDCAD=X",
    "USD/JPY": "USDJPY=X", "EUR/CHF": "EURCHF=X",
}

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
LOG_DIR = os.path.join(BASE_DIR, "logs")
REPORT_DIR = os.path.join(BASE_DIR, "reports")
os.makedirs(LOG_DIR, exist_ok=True)
os.makedirs(REPORT_DIR, exist_ok=True)

config_paths = [
    os.path.join(BASE_DIR, "config.json"),
    os.path.join(os.path.dirname(BASE_DIR), "config.json"),
]
config = {
    "initial_balance": 50000.0, "stake_pct": 0.01,
    "loss_multiplier": 1.22, "win_multiplier": 0.9,
    "daily_stop_loss": 0.50, "max_concurrent": 1,
    "night_mode_start": "00:00", "night_mode_end": "00:00",
    "session_break_interval": 7200,
}
for p in config_paths:
    if os.path.exists(p):
        with open(p, "r") as f:
            config.update(json.load(f))
        print(f"[EdgeBot] Loaded config from: {p}")
        break

# ── Timestamped print ──
def ts(msg):
    t = datetime.now().strftime("%H:%M:%S")
    print(f"[{t}] {msg}")

log_file = os.path.join(LOG_DIR, "engine.log")
logger = setup_logger("TradingEngine", log_file)
trade_logger = TradeLogger(csv_path=os.path.join(LOG_DIR, "trades.csv"))

# ── Candle persistence ──
CANDLES_FILE = os.path.join(LOG_DIR, "candles.json")

def load_candles():
    if os.path.exists(CANDLES_FILE):
        try:
            with open(CANDLES_FILE, "r") as f:
                data = json.load(f)
            ts(f"Loaded {sum(len(v) for v in data.values())} candles from cache")
            return data
        except Exception as e:
            ts(f"Failed to load candles: {e}")
    return {}

def save_candles(candles):
    try:
        tmp = CANDLES_FILE + ".tmp"
        with open(tmp, "w") as f:
            json.dump(candles, f)
        os.replace(tmp, CANDLES_FILE)
    except Exception as e:
        logger.error(f"Failed to save candles: {e}")

state = {
    "candles": load_candles(),
    "last_signal_per_asset": {},
    "signals_last_hour": defaultdict(list),
    "session_start": datetime.now(),
    "last_action": "", "last_trade_result": "",
    "awaiting_trade_result": False,
    "current_asset": "",
    "daily_check_done": False,
    "last_date": datetime.now().date(),
    "candles_changed": False,
}

def get_session():
    return strategy.get_session()

def check_session_break():
    elapsed = (datetime.now() - state["session_start"]).total_seconds()
    interval = config.get("session_break_interval", 7200)
    if elapsed > interval:
        if elapsed < interval + 1200:
            return True
        else:
            state["session_start"] = datetime.now()
    return False

def count_signals_last_hour(asset):
    cutoff = datetime.now() - timedelta(hours=1)
    return sum(1 for t in state["signals_last_hour"].get(asset, []) if t > cutoff)

async def auto_save_loop():
    while True:
        await asyncio.sleep(60)
        if state.get("candles_changed"):
            save_candles(state["candles"])
            state["candles_changed"] = False

# ── Yahoo Finance fetch ──
def fetch_yfinance_history():
    try:
        import yfinance as yf
    except ImportError:
        ts("yfinance not installed. Run: pip install yfinance")
        ts("Falling back to live-only mode")
        return {}

    ts("Fetching history from Yahoo Finance...")
    history = {}
    total = len(YF_SYMBOLS)
    for i, (pair, ticker) in enumerate(YF_SYMBOLS.items(), 1):
        try:
            df = yf.download(ticker, period="5d", interval="1m", progress=False, auto_adjust=True)
            if df is None or df.empty:
                ts(f"  [{i}/{total}] {pair}: no data")
                continue
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = df.columns.get_level_values(0)
            candles = []
            for idx, row in df.iterrows():
                ts2 = int(idx.timestamp() * 1000)
                ct = (ts2 // 60000) * 60000
                candles.append({'t': ct, 'o': float(row['Open']), 'h': float(row['High']),
                                'l': float(row['Low']), 'c': float(row['Close']),
                                'v': float(row.get('Volume', 1))})
            candles.sort(key=lambda x: x['t'])
            seen = set()
            unique = []
            for c in candles:
                if c['t'] not in seen:
                    seen.add(c['t'])
                    unique.append(c)
            if len(unique) > 500:
                unique = unique[-500:]
            history[pair] = unique
            ts(f"  [{i}/{total}] {pair}: {len(unique)} M1 candles")
        except Exception as e:
            ts(f"  [{i}/{total}] {pair}: error — {e}")
    ts(f"Yahoo Finance loaded: {len(history)}/{total} pairs")
    return history

# ── Lifespan ──
@asynccontextmanager
async def lifespan(application):
    yf_data = fetch_yfinance_history()
    if yf_data:
        for pair, candles in yf_data.items():
            if pair not in state["candles"] or len(state["candles"].get(pair, [])) < len(candles):
                state["candles"][pair] = candles
                state["candles_changed"] = True
        # Count ready pairs (min_candles = 50 for M1 Turbo)
        ready = sum(1 for v in state["candles"].values() if len(v) >= 50)
        ts(f"{ready}/14 pairs have 50+ candles — ready to trade!")
    else:
        ts("No Yahoo Finance data. Candles from WS only.")
    save_task = asyncio.create_task(auto_save_loop())
    ts(f"Candle persistence: {CANDLES_FILE}")
    yield
    save_task.cancel()
    save_candles(state["candles"])
    ts("Candles saved on shutdown")

strategy = ApexPrimeUHF()
risk_manager = RiskManager(config)

app = FastAPI(title="EdgeBot Trading Engine", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

@app.get("/history")
async def get_history():
    return {"candles": state["candles"]}

@app.get("/")
async def root():
    return await get_status()

@app.get("/status")
async def get_status():
    cc = {k: len(v) for k, v in state["candles"].items()}
    return {
        "status": "running", "balance": risk_manager.balance,
        "stake": risk_manager.get_stake(), "can_trade": risk_manager.can_trade(),
        "session": get_session(), "active_trades": risk_manager.active_trades,
        "total_signals_today": risk_manager.total_signals_today,
        "last_action": state["last_action"], "last_trade": state["last_trade_result"],
        "consecutive_losses": risk_manager.consecutive_losses,
        "session_break": check_session_break(),
        "current_asset": state["current_asset"],
        "candle_counts": cc, "total_candles": sum(cc.values()),
    }

@app.post("/data")
async def receive_data(request: Request):
    data = await request.json()
    asset = data.get("asset", "unknown")
    balance = data.get("balance", "0")
    state["current_asset"] = asset

    # Balance update
    try:
        val = float(str(balance).replace("$", "").replace(",", ""))
        if val > 0:
            old = risk_manager.balance
            risk_manager.update_balance(val)
            if abs(risk_manager.day_start_balance - val) > risk_manager.day_start_balance * 0.5:
                risk_manager.day_start_balance = val
                risk_manager.start_balance = val
                risk_manager.current_stake = max(val * config.get("stake_pct", 0.01), 1.0)
                ts(f"Balance initialized: ${val:.2f}")
            elif abs(val - old) > 0.01:
                ts(f"Balance: ${old:.2f} -> ${val:.2f}")
    except:
        pass

    # New day
    today = datetime.now().date()
    if state["last_date"] != today:
        risk_manager.new_trading_day()
        state["last_date"] = today
        state["signals_last_hour"] = defaultdict(list)
        ts("New trading day started")

    # Candles from WS
    if "candles" in data and isinstance(data["candles"], list) and len(data["candles"]) > 0:
        incoming = data["candles"]
        if asset not in state["candles"]:
            state["candles"][asset] = incoming
            state["candles_changed"] = True
        else:
            existing = state["candles"][asset]
            emap = {c["t"]: c for c in existing}
            changed = False
            for c in incoming:
                t = c["t"]
                if t in emap:
                    old = emap[t]
                    if old.get("h", 0) < c.get("h", 0) or old.get("l", 999999) > c.get("l", 0) or old.get("c") != c.get("c"):
                        emap[t] = c
                        changed = True
                else:
                    emap[t] = c
                    changed = True
            if changed:
                state["candles"][asset] = sorted(emap.values(), key=lambda x: x["t"])
                if len(state["candles"][asset]) > 1000:
                    state["candles"][asset] = state["candles"][asset][-1000:]
                state["candles_changed"] = True

    # Checks
    if check_session_break():
        return {"action": "wait", "reason": "Session break"}
    if not risk_manager.can_trade():
        reason = "Stop-loss" if risk_manager.is_stop_loss_hit() else "Risk limit"
        return {"action": "wait", "reason": reason}
    if state["awaiting_trade_result"]:
        return {"action": "wait", "reason": "Awaiting result"}

    # 24/7 session — all pairs allowed
    session = get_session()
    if not strategy.is_asset_allowed(asset, session):
        return {"action": "wait", "reason": f"Not allowed"}

    # Min candles check
    n_candles = len(state["candles"].get(asset, []))
    cfg = strategy.ASSET_CFG.get(asset, {})
    min_needed = cfg.get("min_candles", 50)
    if n_candles < min_needed:
        if n_candles % 10 == 0:
            ts(f"{asset}: {n_candles}/{min_needed} candles")
        return {"action": "wait", "reason": f"Collecting ({n_candles}/{min_needed})"}

    # Analyze
    df = pd.DataFrame(state["candles"][asset])
    signal = strategy.check_signal(asset, df)

    # ⬅ Log strategy result every few cycles for debugging
    if signal["reason"] == "No entry" or signal["reason"].startswith("Low"):
        # Show only once per ~10 seconds per asset to avoid spam
        if random.random() < 0.2:
            ts(f"{asset}: {signal['reason']}")

    if signal["action"] != "wait":
        # Hourly limit (15/h per pair for M1 Turbo)
        hourly = count_signals_last_hour(asset)
        max_hourly = cfg.get("max_h", 15)
        if hourly >= max_hourly:
            return {"action": "wait", "reason": "Hourly limit"}

        # Cooldown 2 min (M1 — faster than 5 min)
        last_sig = state["last_signal_per_asset"].get(asset)
        if last_sig and (datetime.now() - last_sig).total_seconds() < 120:
            return {"action": "wait", "reason": "Cooldown 2m"}

        # EXECUTE
        stake = risk_manager.get_stake()
        state["awaiting_trade_result"] = True
        state["last_signal_per_asset"][asset] = datetime.now()
        state["signals_last_hour"][asset].append(datetime.now())
        state["last_action"] = f"{signal['action'].upper()} ${stake} {asset}"
        risk_manager.increment_trades()
        trade_logger.log_trade(asset, signal['action'].upper(), stake, signal['expiry'], signal['reason'], risk_manager.balance)
        ts(f"🔥 SIGNAL: {signal['action'].upper()} | {asset} | ${stake} | {signal['reason']}")
        return {"action": signal["action"], "stake": stake, "expiry": signal["expiry"], "asset": asset}

    return {"action": "wait", "reason": signal["reason"]}

@app.post("/trade_result")
async def trade_result(request: Request):
    data = await request.json()
    state["awaiting_trade_result"] = False
    risk_manager.decrement_trades()
    if "result" in data:
        res = data["result"].lower()
        nb = data.get("balance", risk_manager.balance)
        if nb and float(nb) > 0:
            risk_manager.update_balance(float(nb))
        risk_manager.on_trade_result(res)
        trade_logger.update_last_trade(res, risk_manager.balance)
        state["last_trade_result"] = res.upper()
        emoji = "✅ WIN" if res == "win" else "❌ LOSS"
        ts(f"{emoji} | ${risk_manager.balance:.2f} | stake: ${risk_manager.current_stake:.2f}")
    return {"status": "ok"}

@app.post("/set_balance")
async def set_balance(request: Request):
    data = await request.json()
    try:
        val = float(data.get("balance", 0))
        if val > 0:
            risk_manager.update_balance(val)
            risk_manager.start_balance = val
            risk_manager.day_start_balance = val
            risk_manager.current_stake = max(val * config.get("stake_pct", 0.01), 1.0)
            ts(f"Manual balance: ${val:.2f}")
            return {"status": "ok", "balance": val}
    except:
        pass
    return {"status": "error"}

if __name__ == "__main__":
    print("=" * 50)
    print("  EdgeBot M1 TURBO SCALPER")
    print("=" * 50)
    print(f"  Logs: {log_file}")
    print(f"  Server: http://127.0.0.1:8765")
    print(f"  Status: http://127.0.0.1:8765/status")
    print(f"  Pairs: 14  |  Expiry: 1 min  |  Session: 24/7")
    print(f"  Min candles: 50  |  Max signals: 15/h per pair")
    print("=" * 50)
    uvicorn.run(app, host="127.0.0.1", port=8765)