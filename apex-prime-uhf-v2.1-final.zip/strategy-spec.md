# Apex Prime UHF Binary Options Strategy v2.0 (High Precision)

## 1. Strategy Identity
- **Strategy Name:** Apex Prime UHF v2.0
- **Target Win Rate:** ≥ 80%
- **Signal Frequency:** 50-150 high-probability signals per 24h
- **Max Drawdown:** ≤ 15%

---

## 2. Asset Specific Configurations

### 2.1 Asset Matrix
| Asset | Category | Expiry | Prime Session (GMT) | Min ATR(14) | RSI Period | RSI Levels |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **EUR/USD** | Forex | 1 min | 08:00 - 20:00 | 1.5 pips | 7 | 70/30 |
| **GBP/USD** | Forex | 1 min | 08:00 - 16:00 | 2.0 pips | 7 | 70/30 |
| **USD/JPY** | Forex | 1 min | 00:00 - 08:00, 13:00 - 20:00 | 1.5 pips | 7 | 70/30 |
| **AUD/USD** | Forex | 1 min | 00:00 - 08:00 | 1.5 pips | 7 | 70/30 |
| **USD/CAD** | Forex | 1 min | 13:00 - 21:00 | 1.8 pips | 7 | 70/30 |
| **NZD/USD** | Forex | 1 min | 00:00 - 08:00 | 1.5 pips | 7 | 70/30 |
| **BTC/USD** | Crypto | 2 min | 24/7 | $50 | 5 | 75/25 |
| **ETH/USD** | Crypto | 2 min | 24/7 | $5 | 5 | 75/25 |
| **LTC/USD** | Crypto | 2 min | 24/7 | $0.50 | 5 | 75/25 |
| **XRP/USD** | Crypto | 1 min | 24/7 | $0.005 | 5 | 75/25 |
| **SOL/USD** | Crypto | 1 min | 24/7 | $0.20 | 5 | 75/25 |
| **S&P 500** | Index | 5 min | 13:30 - 20:00 | 5 points | 9 | 70/30 |
| **NASDAQ** | Index | 5 min | 13:30 - 20:00 | 15 points | 9 | 70/30 |
| **Dow Jones**| Index | 5 min | 13:30 - 20:00 | 30 points | 9 | 70/30 |
| **FTSE 100** | Index | 5 min | 08:00 - 16:30 | 10 points | 9 | 70/30 |
| **XAU/USD** | Commod | 2 min | 08:00 - 21:00 | $1.00 | 9 | 70/30 |
| **XAG/USD** | Commod | 2 min | 08:00 - 21:00 | $0.05 | 9 | 70/30 |
| **USOIL** | Commod | 5 min | 13:00 - 20:00 | $0.10 | 9 | 70/30 |

---

## 3. Signal Cycle & Volume Management
To reach the target of 50-150 signals per day:
- **Active Monitoring:** 18 assets monitored simultaneously.
- **Signal Density:** Average 0.3 - 0.6 signals per hour per asset.
- **Rotation:** AI scanner switches focus based on session relevance (e.g., shifts from AUD/JPY to EUR/USD at 08:00 GMT).
- **Asset Cooldown:** Maximum 3 signals per asset per hour to prevent over-trading in choppy ranges.

---

## 4. Enhanced Technical Indicators

### 4.1 Multi-Timeframe Trend Filters
- **Global Filter:** EMA 200 (M1). Price must be above for CALLs, below for PUTs.
- **Mid Filter:** EMA 50 (M1). Defines the local trend.
- **Signal Filter:** EMA 7 & EMA 14 cross.

### 4.2 Momentum & Volatility
- **Bollinger Bands (20, 2):** Middle band (SMA 20) acts as a dynamic S/R.
- **Volume SMA(20):** Current Volume must be > 1.2x SMA(20) of volume for entry (ensures breakthrough power).
- **ATR(14):** Must exceed the "Min Volatility" threshold in the Asset Matrix.

---

## 5. Entry Rules

### 5.1 CALL Signal
`IF` [Market_Session == Active] `AND` [ATR(14) > Min_Volatility] `THEN`:
1. **Global Trend:** Price > EMA(200)
2. **Local Trend:** Price > EMA(50) `AND` EMA(7) > EMA(14)
3. **Volume:** Volume > Volume_SMA(20) * 1.2
4. **Timing:** Stochastic %K crosses above %D below 30 `OR` Stochastic is in strong uptrend but < 70.
5. **Confirmation:** RSI > 50 `AND` Close > EMA(7) `AND` Signal Candle is GREEN.

### 5.2 PUT Signal
`IF` [Market_Session == Active] `AND` [ATR(14) > Min_Volatility] `THEN`:
1. **Global Trend:** Price < EMA(200)
2. **Local Trend:** Price < EMA(50) `AND` EMA(7) < EMA(14)
3. **Volume:** Volume > Volume_SMA(20) * 1.2
4. **Timing:** Stochastic %K crosses below %D above 70 `OR` Stochastic is in strong downtrend but > 30.
5. **Confirmation:** RSI < 50 `AND` Close < EMA(7) `AND` Signal Candle is RED.

---

## 6. Market Session Rules

- **Asian Session (00:00 - 08:00 GMT):** Focus on JPY, AUD, NZD and Crypto. EMA 50 filter is MANDATORY (no counter-trend).
- **London Session (08:00 - 16:00 GMT):** High focus on EUR, GBP, XAU.
- **US Session (13:00 - 21:00 GMT):** Focus on Indices and USD pairs. 
- **The Overlap (13:00 - 16:00 GMT):** Maximum signal sensitivity. All filters active. Increased volume SMA threshold to 1.5x.

---

## 7. Machine-Readable Configuration (JSON)

```json
{
  "strategy_version": "2.0",
  "daily_signal_target": [50, 150],
  "global_filters": {
    "ema_trend": 200,
    "volume_multiplier": 1.2,
    "min_payout": 75
  },
  "risk_mgmt": {
    "stake_pct": 1.0,
    "max_concurrent": 3,
    "cooldown_after_trade_mins": 5,
    "max_hourly_per_asset": 3,
    "max_consecutive_loss": 2,
    "daily_stop_loss_pct": 5.0,
    "daily_take_profit_pct": 10.0
  },
  "asset_groups": {
    "forex_low_vol": {
      "assets": ["EUR/USD", "USD/JPY"],
      "rsi": {"period": 7, "levels": [70, 30]}
    },
    "crypto_high_vol": {
      "assets": ["BTC/USD", "ETH/USD", "SOL/USD"],
      "rsi": {"period": 5, "levels": [75, 25]},
      "expiry": "120s"
    },
    "indices_commodities": {
      "assets": ["XAU/USD", "NASDAQ", "USOIL"],
      "rsi": {"period": 9, "levels": [70, 30]},
      "expiry": "300s"
    }
  },
  "session_times_gmt": {
    "asia": ["00:00", "08:00"],
    "london": ["08:00", "16:00"],
    "us": ["13:00", "21:00"],
    "overlap": ["13:00", "16:00"]
  }
}
```

---

## 8. Strategy Execution Pseudocode

```python
def check_signal(asset_id, current_data):
    # 1. LOAD CONFIG
    asset_cfg = get_asset_config(asset_id)
    session = get_current_gmt_session()
    
    # 2. MARKET STATE CHECKS
    if not asset_cfg.is_active_session(session):
        return SKIP("Inactive Session")
    
    if current_data.payout < 75:
        return SKIP("Low Payout")

    # 3. CALCULATE INDICATORS
    ema200 = calculate_ema(current_data.close, 200)
    ema50 = calculate_ema(current_data.close, 50)
    ema7 = calculate_ema(current_data.close, 7)
    ema14 = calculate_ema(current_data.close, 14)
    vol_sma20 = calculate_sma(current_data.volume, 20)
    atr14 = calculate_atr(current_data, 14)
    rsi = calculate_rsi(current_data.close, asset_cfg.rsi_period)
    stoch_k, stoch_d = calculate_stochastic(current_data, 5, 3, 3)

    # 4. PRIMARY FILTERS
    if atr14 < asset_cfg.min_atr:
        return SKIP("Low Volatility (ATR)")
    
    if current_data.volume < (vol_sma20 * 1.2):
        return SKIP("Insufficient Volume")

    # 5. ENTRY LOGIC - CALL
    if current_data.close > ema200: # Bullish Global
        if (ema7 > ema14) and (current_data.close > ema50): # Bullish Local
            if rsi > 50 and rsi < asset_cfg.rsi_overbought:
                if stoch_k > stoch_d and stoch_k < 70:
                    if current_data.last_candle.is_green:
                        return SIGNAL("CALL", expiry=asset_cfg.expiry)

    # 6. ENTRY LOGIC - PUT
    if current_data.close < ema200: # Bearish Global
        if (ema7 < ema14) and (current_data.close < ema50): # Bearish Local
            if rsi < 50 and rsi > asset_cfg.rsi_oversold:
                if stoch_k < stoch_d and stoch_k > 30:
                    if current_data.last_candle.is_red:
                        return SIGNAL("PUT", expiry=asset_cfg.expiry)

    return SKIP("No conditions met")
```
