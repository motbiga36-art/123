#!/usr/bin/env python3
"""
Apex Prime UHF — Binary Options Backtesting Framework v1.1
===========================================================
Validates the trading strategy against historical/simulated market data.
Calculates: Win Rate, Signal Frequency, Max Drawdown, Risk-Adjusted Metrics.

Targets:  >=80% Win Rate | 50-150 signals/day | <=15% Max Drawdown
"""

import json
import math
import os
import random
import statistics
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple, Callable

# ──────────────────────────────────────────────────────────────────────
# 1.  Data Structures
# ──────────────────────────────────────────────────────────────────────

@dataclass
class OHLCV:
    """Single candle (1-minute)."""
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float

@dataclass
class Trade:
    id: int
    asset: str
    direction: str  # "CALL" or "PUT"
    entry_time: datetime
    expiry_time: datetime
    entry_price: float
    exit_price: float = 0.0
    payout: float = 0.0
    result: str = "PENDING"  # WIN / LOSS / PENDING
    stake: float = 0.0

@dataclass
class Signal:
    asset: str
    direction: str
    timestamp: datetime
    expiry_seconds: int
    price: float
    conditions_met: Dict[str, bool]
    filters_passed: bool

# ──────────────────────────────────────────────────────────────────────
# 2.  Technical Indicators
# ──────────────────────────────────────────────────────────────────────

def ema(data: List[float], period: int) -> List[float]:
    """Exponential Moving Average -- returns len(data) values."""
    result = [0.0] * len(data)
    k = 2.0 / (period + 1)
    result[0] = data[0]
    for i in range(1, len(data)):
        result[i] = data[i] * k + result[i-1] * (1 - k)
    return result

def sma(data: List[float], period: int) -> List[float]:
    """Simple Moving Average -- first period-1 values are 0."""
    result = [0.0] * len(data)
    for i in range(period - 1, len(data)):
        result[i] = sum(data[i - period + 1:i + 1]) / period
    return result

def bollinger_bands(data: List[float], period: int = 20,
                    deviation: float = 2.0) -> Tuple[List[float], List[float], List[float]]:
    """Returns (middle, upper, lower) bands."""
    middle = sma(data, period)
    upper = [0.0] * len(data)
    lower = [0.0] * len(data)
    for i in range(period - 1, len(data)):
        segment = data[i - period + 1:i + 1]
        std = statistics.stdev(segment) if len(segment) >= 2 else 0.0
        upper[i] = middle[i] + deviation * std
        lower[i] = middle[i] - deviation * std
    return middle, upper, lower

def rsi(data: List[float], period: int = 7) -> List[float]:
    """Relative Strength Index."""
    result = [50.0] * len(data)
    gains, losses = 0.0, 0.0
    for i in range(1, period + 1):
        diff = data[i] - data[i - 1]
        if diff > 0:
            gains += diff
        else:
            losses += abs(diff)
    avg_gain = gains / period
    avg_loss = losses / period
    if avg_loss == 0:
        result[period] = 100.0
    else:
        rs = avg_gain / avg_loss
        result[period] = 100.0 - 100.0 / (1.0 + rs)
    for i in range(period + 1, len(data)):
        diff = data[i] - data[i - 1]
        if diff > 0:
            avg_gain = (avg_gain * (period - 1) + diff) / period
            avg_loss = (avg_loss * (period - 1)) / period
        else:
            avg_gain = (avg_gain * (period - 1)) / period
            avg_loss = (avg_loss * (period - 1) + abs(diff)) / period
        if avg_loss == 0:
            result[i] = 100.0
        else:
            rs = avg_gain / avg_loss
            result[i] = 100.0 - 100.0 / (1.0 + rs)
    return result

def stochastic(high: List[float], low: List[float], close: List[float],
               k_period: int = 5, d_period: int = 3) -> Tuple[List[float], List[float]]:
    """Stochastic Oscillator %K and %D."""
    k = [50.0] * len(close)
    for i in range(k_period - 1, len(close)):
        hh = max(high[i - k_period + 1:i + 1])
        ll = min(low[i - k_period + 1:i + 1])
        if hh != ll:
            k[i] = (close[i] - ll) / (hh - ll) * 100.0
        else:
            k[i] = 50.0
    d = sma(k, d_period)
    return k, d

# ──────────────────────────────────────────────────────────────────────
# 3.  Market Data Simulation
# ──────────────────────────────────────────────────────────────────────

ASSET_CONFIG = {
    "EUR/USD": {"class": "Forex",     "volatility": 0.0003, "spread": 0.0001, "base_price": 1.0800, "expiry": 60},
    "GBP/USD": {"class": "Forex",     "volatility": 0.0004, "spread": 0.0001, "base_price": 1.2600, "expiry": 60},
    "USD/JPY": {"class": "Forex",     "volatility": 0.0003, "spread": 0.0001, "base_price": 150.50, "expiry": 60},
    "BTC/USD": {"class": "Crypto",    "volatility": 0.0020, "spread": 0.0005, "base_price": 67000,  "expiry": 60},
    "ETH/USD": {"class": "Crypto",    "volatility": 0.0025, "spread": 0.0005, "base_price": 3400,   "expiry": 60},
    "S&P500":  {"class": "Indices",   "volatility": 0.0015, "spread": 0.0002, "base_price": 5200,   "expiry": 120},
    "NASDAQ":  {"class": "Indices",   "volatility": 0.0018, "spread": 0.0002, "base_price": 16500,  "expiry": 120},
    "XAU/USD": {"class": "Commodities","volatility": 0.0010, "spread": 0.0003, "base_price": 2350,   "expiry": 120},
    "USOIL":   {"class": "Commodities","volatility": 0.0015, "spread": 0.0003, "base_price": 78.50,  "expiry": 120},
    "AUD/USD": {"class": "Forex",     "volatility": 0.0003, "spread": 0.0001, "base_price": 0.6600, "expiry": 60},
    "USD/CAD": {"class": "Forex",     "volatility": 0.0003, "spread": 0.0001, "base_price": 1.3600, "expiry": 60},
    "NZD/USD": {"class": "Forex",     "volatility": 0.0003, "spread": 0.0001, "base_price": 0.6000, "expiry": 60},
    "LTC/USD": {"class": "Crypto",    "volatility": 0.0030, "spread": 0.0010, "base_price": 85.00,  "expiry": 60},
    "XRP/USD": {"class": "Crypto",    "volatility": 0.0035, "spread": 0.0010, "base_price": 0.55,   "expiry": 60},
    "SOL/USD": {"class": "Crypto",    "volatility": 0.0035, "spread": 0.0010, "base_price": 145.00, "expiry": 60},
    "Dow Jones":{"class": "Indices",  "volatility": 0.0012, "spread": 0.0002, "base_price": 39000,  "expiry": 120},
    "FTSE100": {"class": "Indices",   "volatility": 0.0010, "spread": 0.0002, "base_price": 7800,   "expiry": 120},
    "XAG/USD": {"class": "Commodities","volatility": 0.0015, "spread": 0.0004, "base_price": 28.00,  "expiry": 120},
}

SESSION_MULTIPLIER = {
    "Asian":   {"Forex": 0.7, "Crypto": 1.3, "Indices": 0.5, "Commodities": 0.6},
    "London":  {"Forex": 1.5, "Crypto": 1.2, "Indices": 1.0, "Commodities": 1.2},
    "US":      {"Forex": 1.3, "Crypto": 1.4, "Indices": 1.6, "Commodities": 1.3},
}

def get_session_hour(dt: datetime) -> str:
    h = dt.hour
    if 22 <= h or h < 7:
        return "Asian"
    elif 7 <= h < 12:
        return "London"
    elif 12 <= h < 16:
        return "London"
    elif 16 <= h < 21:
        return "US"
    else:
        return "Asian"

def generate_ohlcv(asset: str, num_candles: int,
                   start_time: Optional[datetime] = None,
                   trend_strength: float = 0.01,
                   regime: str = "mixed") -> List[OHLCV]:
    config = ASSET_CONFIG[asset]
    base = config["base_price"]
    vol = config["volatility"]
    asset_class = config["class"]

    if start_time is None:
        start_time = datetime(2024, 1, 1, 0, 0, 0)

    candles = []
    price = base
    rng = random.Random(hash(f"{asset}_{num_candles}_{regime}") & 0xFFFFFFFF)

    regime_cycle = ["trending", "ranging", "volatile", "trending",
                    "ranging", "trending", "volatile", "ranging"]
    regime_idx = 0
    regime_len = max(1, num_candles // 8)
    trend_dir = 1 if rng.random() > 0.5 else -1

    for i in range(num_candles):
        ts = start_time + timedelta(minutes=i)
        session = get_session_hour(ts)
        session_mult = SESSION_MULTIPLIER.get(session, {}).get(asset_class, 1.0)

        if regime == "mixed":
            current_regime = regime_cycle[min(regime_idx, len(regime_cycle) - 1)]
            if i > 0 and i % regime_len == 0:
                regime_idx += 1
                if regime_idx >= len(regime_cycle):
                    regime_idx = rng.randint(0, len(regime_cycle) - 1)
        else:
            current_regime = regime

        if current_regime == "trending":
            if rng.random() < 0.002:
                trend_dir *= -1
            drift = trend_dir * trend_strength * vol * 3
            noise_scale = 0.6
        elif current_regime == "ranging":
            drift = -0.0001 * (price - base) / base * vol * 50
            noise_scale = 0.3
        elif current_regime == "volatile":
            drift = rng.gauss(0, vol * 2)
            noise_scale = 1.5
        else:
            drift = 0.0
            noise_scale = 1.0

        raw_return = drift + rng.gauss(0, vol * session_mult * noise_scale)
        close_change = price * raw_return
        intra_vol = abs(close_change) * (0.5 + rng.random())

        o = price
        c = price + close_change
        h = max(o, c) + intra_vol * rng.random()
        l = min(o, c) - intra_vol * rng.random()
        v = max(100, rng.gauss(1000, 200) * session_mult)

        candles.append(OHLCV(timestamp=ts, open=o, high=h, low=l, close=c, volume=v))
        price = c

    return candles

# ──────────────────────────────────────────────────────────────────────
# 4.  Strategy Engine
# ──────────────────────────────────────────────────────────────────────

class ApexPrimeUHFEngine:
    """Implements the full Apex Prime UHF strategy rules."""

    def __init__(self, asset: str, initial_balance: float = 10000.0,
                 stake_pct: float = 0.01):
        self.asset = asset
        self.config = ASSET_CONFIG[asset]
        self.balance = initial_balance
        self.initial_balance = initial_balance
        self.stake_pct = stake_pct

        self.candles: List[OHLCV] = []
        self.active_trades: Dict[int, Trade] = {}
        self.closed_trades: List[Trade] = []
        self.trade_counter = 0

        self.daily_profit = 0.0
        self.daily_loss = 0.0
        self.daily_trades = 0
        self.current_day = None
        self.consecutive_losses = 0
        self.consecutive_loss_asset = {}
        self.last_trade_time_asset = {}
        self.hourly_signal_count = {}
        self.halted_until: Optional[datetime] = None
        self.stopped_for_day = False

        self.news_events: List[datetime] = []
        self.equity_curve: List[Tuple[datetime, float]] = []

    def add_candle(self, candle: OHLCV) -> None:
        self.candles.append(candle)

        if self.current_day is None:
            self.current_day = candle.timestamp.date()
        elif candle.timestamp.date() != self.current_day:
            self.current_day = candle.timestamp.date()
            self.daily_profit = 0.0
            self.daily_loss = 0.0
            self.daily_trades = 0
            self.stopped_for_day = False
            self.hourly_signal_count = {}
            self.consecutive_losses = 0
            self.consecutive_loss_asset = {}

        if self.halted_until and candle.timestamp >= self.halted_until:
            self.halted_until = None

        self._check_expiries(candle.timestamp)

        equity = self.balance + sum(
            t.stake for t in self.active_trades.values()
        )
        self.equity_curve.append((candle.timestamp, equity))

    def _check_expiries(self, now: datetime) -> None:
        expired_ids = []
        for tid, trade in self.active_trades.items():
            if now >= trade.expiry_time:
                exit_candle = self._find_candle_at(trade.expiry_time)
                if exit_candle:
                    trade.exit_price = exit_candle.close
                    if trade.direction == "CALL":
                        won = exit_candle.close > trade.entry_price
                    else:
                        won = exit_candle.close < trade.entry_price

                    if won:
                        trade.result = "WIN"
                        payout_mult = 0.80
                        trade.payout = trade.stake * (1 + payout_mult)
                        self.balance += trade.payout
                        self.daily_profit += trade.payout - trade.stake
                        self.consecutive_losses = 0
                        self.consecutive_loss_asset[trade.asset] = 0
                    else:
                        trade.result = "LOSS"
                        trade.payout = 0
                        self.balance -= trade.stake
                        self.daily_loss += trade.stake
                        self.consecutive_losses += 1
                        self.consecutive_loss_asset[trade.asset] = \
                            self.consecutive_loss_asset.get(trade.asset, 0) + 1

                expired_ids.append(tid)

        for tid in expired_ids:
            trade = self.active_trades.pop(tid)
            self.closed_trades.append(trade)

    def _find_candle_at(self, timestamp: datetime) -> Optional[OHLCV]:
        for c in reversed(self.candles):
            if c.timestamp <= timestamp:
                return c
        return self.candles[-1] if self.candles else None

    def _get_prices(self) -> List[float]:
        return [c.close for c in self.candles]

    def _get_highs(self) -> List[float]:
        return [c.high for c in self.candles]

    def _get_lows(self) -> List[float]:
        return [c.low for c in self.candles]

    def _get_candle_color(self, idx: int) -> str:
        if idx < 0 or idx >= len(self.candles):
            return "GREEN"
        c = self.candles[idx]
        return "GREEN" if c.close >= c.open else "RED"

    def _get_wick_size(self, idx: int) -> float:
        if idx < 0 or idx >= len(self.candles):
            return 0.0
        c = self.candles[idx]
        body = abs(c.close - c.open)
        upper_wick = c.high - max(c.close, c.open)
        lower_wick = min(c.close, c.open) - c.low
        max_wick = max(upper_wick, lower_wick)
        if body == 0:
            return 0.0
        return max_wick / body

    def _is_news_event(self, timestamp: datetime) -> bool:
        for event_time in self.news_events:
            diff_min = abs((timestamp - event_time).total_seconds() / 60)
            if diff_min <= 15:
                return True
        return False

    def _check_filters(self, candle_idx: int,
                       timestamp: datetime) -> Tuple[bool, str]:
        if self._is_news_event(timestamp):
            return False, "FILTER1_NEWS"

        if self._get_wick_size(candle_idx) > 2.0:
            return False, "FILTER2_WICK"

        if len(self.candles) < 50:
            return True, "OK"

        prices = self._get_prices()
        _, upper, lower = bollinger_bands(prices, 20, 2.0)
        bb_width = upper[-1] - lower[-1]
        avg_spread = self.config["spread"] * self.config["base_price"]
        if bb_width < avg_spread * 5:
            return False, "FILTER4_SQUEEZE"

        return True, "OK"

    def _check_risk_rules(self, timestamp: datetime) -> Tuple[bool, str]:
        if self.stopped_for_day:
            return False, "RISK_STOPPED_FOR_DAY"

        if self.daily_profit >= self.initial_balance * 0.10:
            self.stopped_for_day = True
            return False, "RISK_DAILY_PROFIT_TARGET"

        if self.daily_loss >= self.initial_balance * 0.05:
            self.stopped_for_day = True
            return False, "RISK_DAILY_MAX_LOSS"

        if len(self.active_trades) >= 3:
            return False, "RISK_MAX_CONCURRENT"

        if self.halted_until and timestamp < self.halted_until:
            return False, "RISK_HALTED"

        if self.consecutive_losses >= 2:
            self.halted_until = timestamp + timedelta(minutes=60)
            return False, "RISK_CONSECUTIVE_LOSSES"

        asset_losses = self.consecutive_loss_asset.get(self.asset, 0)
        if asset_losses >= 2:
            return False, "RISK_ASSET_CONSECUTIVE_LOSSES"

        last_trade = self.last_trade_time_asset.get(self.asset)
        if last_trade:
            diff_min = (timestamp - last_trade).total_seconds() / 60
            if diff_min < 5:
                return False, "FILTER3_COOLDOWN"

        hour_key = f"{self.asset}_{timestamp.hour}"
        self.hourly_signal_count[hour_key] = \
            self.hourly_signal_count.get(hour_key, 0)
        if self.hourly_signal_count[hour_key] >= 5:
            return False, "FILTER5_HOURLY_LIMIT"

        return True, "OK"

    def evaluate(self) -> Optional[Signal]:
        if len(self.candles) < 52:
            return None

        now = self.candles[-1].timestamp
        prices = self._get_prices()
        highs = self._get_highs()
        lows = self._get_lows()
        current_price = prices[-1]

        ema7 = ema(prices, 7)
        ema14 = ema(prices, 14)
        ema50 = ema(prices, 50)
        bb_mid, bb_upper, bb_lower = bollinger_bands(prices, 20, 2.0)
        rsi_vals = rsi(prices, 7)
        stoch_k, stoch_d = stochastic(highs, lows, prices, 5, 3)

        i = -1
        p_i = -2

        conditions_met = {}
        direction = None

        # CALL evaluation
        cond1_call = current_price > ema50[i] and ema7[i] > ema14[i]
        cond2_call = current_price > bb_mid[i]
        cond3_call = (stoch_k[p_i] <= stoch_d[p_i] and
                      stoch_k[i] > stoch_d[i]) and stoch_k[i] < 40
        cond4_call = 50 < rsi_vals[i] < 70
        prev_color = self._get_candle_color(p_i)
        cond5_call = prev_color == "GREEN" and prices[p_i] > ema7[p_i]

        if cond1_call and cond2_call and cond3_call and cond4_call and cond5_call:
            direction = "CALL"
            conditions_met = {
                "trend_filter": cond1_call,
                "volatility_filter": cond2_call,
                "stochastic_timing": cond3_call,
                "rsi_momentum": cond4_call,
                "candle_confirmation": cond5_call
            }

        # PUT evaluation
        cond1_put = current_price < ema50[i] and ema7[i] < ema14[i]
        cond2_put = current_price < bb_mid[i]
        cond3_put = (stoch_k[p_i] >= stoch_d[p_i] and
                     stoch_k[i] < stoch_d[i]) and stoch_k[i] > 60
        cond4_put = 30 < rsi_vals[i] < 50
        cond5_put = prev_color == "RED" and prices[p_i] < ema7[p_i]

        if cond1_put and cond2_put and cond3_put and cond4_put and cond5_put:
            direction = "PUT"
            conditions_met = {
                "trend_filter": cond1_put,
                "volatility_filter": cond2_put,
                "stochastic_timing": cond3_put,
                "rsi_momentum": cond4_put,
                "candle_confirmation": cond5_put
            }

        if direction is None:
            return None

        filters_passed, filter_reason = self._check_filters(p_i, now)
        if not filters_passed:
            return None

        risk_allowed, risk_reason = self._check_risk_rules(now)
        if not risk_allowed:
            return None

        expiry = self.config["expiry"]

        signal = Signal(
            asset=self.asset,
            direction=direction,
            timestamp=now,
            expiry_seconds=expiry,
            price=current_price,
            conditions_met=conditions_met,
            filters_passed=True
        )
        return signal

    def execute_signal(self, signal: Signal) -> Optional[Trade]:
        stake = self.balance * self.stake_pct
        if stake <= 0:
            return None

        trade = Trade(
            id=self.trade_counter,
            asset=signal.asset,
            direction=signal.direction,
            entry_time=signal.timestamp,
            expiry_time=signal.timestamp + timedelta(seconds=signal.expiry_seconds),
            entry_price=signal.price,
            stake=stake
        )
        self.trade_counter += 1
        self.active_trades[trade.id] = trade

        self.last_trade_time_asset[self.asset] = signal.timestamp
        hour_key = f"{self.asset}_{signal.timestamp.hour}"
        self.hourly_signal_count[hour_key] = \
            self.hourly_signal_count.get(hour_key, 0) + 1

        return trade

# ──────────────────────────────────────────────────────────────────────
# 5.  Backtest Runner
# ──────────────────────────────────────────────────────────────────────

@dataclass
class BacktestResult:
    asset: str
    total_trades: int
    wins: int
    losses: int
    win_rate: float
    signals_per_day: float
    total_profit: float
    max_drawdown: float
    profit_factor: float
    avg_trade_return: float
    sharpe_approx: float
    confidence_lower: float
    confidence_upper: float
    regime: str
    days: float

def run_backtest(asset: str, num_candles: int = 1440, regime: str = "mixed",
                 initial_balance: float = 10000.0, seed_extra: int = 0) -> BacktestResult:
    candles = generate_ohlcv(asset, num_candles + 100, regime=regime)

    rng = random.Random(hash(f"news_{asset}_{num_candles}_{regime}_{seed_extra}") & 0xFFFFFFFF)
    news_events = []
    for _ in range(int(num_candles / 720)):
        idx = rng.randint(200, len(candles) - 1)
        news_events.append(candles[idx].timestamp)

    engine = ApexPrimeUHFEngine(asset, initial_balance)
    engine.news_events = news_events

    signals_generated = 0

    for i, candle in enumerate(candles):
        engine.add_candle(candle)
        if i < 100:
            continue
        signal = engine.evaluate()
        if signal:
            signals_generated += 1
            engine.execute_signal(signal)

    # Settle remaining active trades
    if engine.active_trades:
        max_expiry = max(t.expiry_time for t in engine.active_trades.values())
        last_ts = candles[-1].timestamp
        while last_ts < max_expiry:
            last_ts += timedelta(minutes=1)
            for tid in list(engine.active_trades.keys()):
                trade = engine.active_trades[tid]
                if last_ts >= trade.expiry_time:
                    last_candle = candles[-1]
                    if trade.direction == "CALL":
                        won = last_candle.close > trade.entry_price
                    else:
                        won = last_candle.close < trade.entry_price
                    if won:
                        trade.result = "WIN"
                        trade.payout = trade.stake * 1.80
                        engine.balance += trade.payout
                    else:
                        trade.result = "LOSS"
                        trade.payout = 0
                    trade.exit_price = last_candle.close
                    engine.closed_trades.append(trade)
                    del engine.active_trades[tid]

    closed = engine.closed_trades
    wins = sum(1 for t in closed if t.result == "WIN")
    losses = sum(1 for t in closed if t.result == "LOSS")
    total = wins + losses

    win_rate = wins / total if total > 0 else 0.0
    signals_per_day = signals_generated / (num_candles / 1440.0) if num_candles > 0 else 0

    total_profit = engine.balance - initial_balance

    curve = engine.equity_curve
    max_dd = 0.0
    peak = initial_balance
    for _, eq in curve:
        if eq > peak:
            peak = eq
        dd = (peak - eq) / peak if peak > 0 else 0.0
        max_dd = max(max_dd, dd)

    gross_profit = sum(max(0, t.payout - t.stake) for t in closed)
    gross_loss = sum(t.stake for t in closed if t.result == "LOSS")
    profit_factor = gross_profit / gross_loss if gross_loss > 0 else float('inf')

    avg_ret = statistics.mean([t.payout - t.stake for t in closed]) if closed else 0.0

    daily_returns = []
    current_day_pl = 0.0
    eq_peak_val = 0.0
    if curve:
        last_date = curve[0][0].date()
        for ts, eq_val in curve:
            if ts.date() != last_date:
                daily_returns.append(current_day_pl / initial_balance)
                current_day_pl = 0.0
                last_date = ts.date()
        if daily_returns:
            avg_daily = statistics.mean(daily_returns)
            std_daily = statistics.stdev(daily_returns) if len(daily_returns) > 1 else 0.001
            sharpe = (avg_daily / std_daily) * math.sqrt(252) if std_daily > 0 else 0.0
        else:
            sharpe = 0.0
    else:
        sharpe = 0.0

    if total > 0:
        p = win_rate
        z = 1.96
        se = math.sqrt(p * (1 - p) / total)
        ci_lower = max(0, p - z * se)
        ci_upper = min(1, p + z * se)
    else:
        ci_lower = ci_upper = 0.0

    days = num_candles / 1440.0

    return BacktestResult(
        asset=asset, total_trades=total, wins=wins, losses=losses,
        win_rate=win_rate, signals_per_day=signals_per_day,
        total_profit=total_profit, max_drawdown=max_dd,
        profit_factor=profit_factor, avg_trade_return=avg_ret,
        sharpe_approx=sharpe, confidence_lower=ci_lower,
        confidence_upper=ci_upper, regime=regime, days=days
    )

# ──────────────────────────────────────────────────────────────────────
# 6.  Multi-Asset & Multi-Regime Runner
# ──────────────────────────────────────────────────────────────────────

@dataclass
class SuiteResult:
    results: List[BacktestResult]
    overall_win_rate: float
    overall_signals_per_day: float
    overall_max_drawdown: float
    overall_profit_factor: float
    overall_sharpe: float
    total_trades: int
    assets_tested: int

def run_suite(assets: List[str] = None, num_days: int = 30,
              regimes: List[str] = None,
              initial_balance: float = 10000.0) -> SuiteResult:
    if assets is None:
        assets = list(ASSET_CONFIG.keys())
    if regimes is None:
        regimes = ["mixed", "trending", "ranging", "volatile"]

    all_results = []
    total_trades = 0
    total_wins = 0

    for regime in regimes:
        for asset in assets:
            num_candles = int(num_days * 1440)
            result = run_backtest(asset, num_candles, regime=regime,
                                  initial_balance=initial_balance)
            all_results.append(result)
            total_trades += result.total_trades
            total_wins += result.wins

    overall_win_rate = total_wins / total_trades if total_trades > 0 else 0.0
    overall_signals = statistics.mean([r.signals_per_day for r in all_results]) if all_results else 0.0
    overall_max_dd = max((r.max_drawdown for r in all_results), default=0.0)
    overall_pf = statistics.mean([r.profit_factor for r in all_results
                                 if r.profit_factor != float('inf')]) if all_results else 0.0
    overall_sharpe = statistics.mean([r.sharpe_approx for r in all_results]) if all_results else 0.0

    return SuiteResult(
        results=all_results,
        overall_win_rate=overall_win_rate,
        overall_signals_per_day=overall_signals,
        overall_max_drawdown=overall_max_dd,
        overall_profit_factor=overall_pf,
        overall_sharpe=overall_sharpe,
        total_trades=total_trades,
        assets_tested=len(assets) * len(regimes)
    )

# ──────────────────────────────────────────────────────────────────────
# 7.  Report Generator
# ──────────────────────────────────────────────────────────────────────

def generate_report(suite: SuiteResult, output_path: str = None) -> str:
    now = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")

    lines = []
    lines.append("# Apex Prime UHF -- Backtest Validation Report")
    lines.append(f"**Generated:** {now}")
    lines.append(f"**Strategy Version:** v1.1")
    lines.append("")

    passed = suite.overall_win_rate >= 0.80
    passed_freq = 50 <= suite.overall_signals_per_day <= 150
    passed_dd = suite.overall_max_drawdown <= 0.15

    status = "PASS" if (passed and passed_freq and passed_dd) else "FAIL"
    lines.append(f"## Overall Status: {status}")
    lines.append("")
    lines.append("| Metric | Target | Actual | Status |")
    lines.append("| :--- | :--- | :--- | :--- |")
    wr_icon = "OK" if passed else "FAIL"
    freq_icon = "OK" if passed_freq else "FAIL"
    dd_icon = "OK" if passed_dd else "FAIL"
    lines.append(f"| **Win Rate** | >= 80% | {suite.overall_win_rate*100:.2f}% | {wr_icon} |")
    lines.append(f"| **Signals/Day** | 50-150 | {suite.overall_signals_per_day:.1f} | {freq_icon} |")
    lines.append(f"| **Max Drawdown** | <= 15% | {suite.overall_max_drawdown*100:.2f}% | {dd_icon} |")
    lines.append(f"| **Profit Factor** | > 1.5 | {suite.overall_profit_factor:.2f} | -- |")
    lines.append(f"| **Sharpe (approx)** | > 1.0 | {suite.overall_sharpe:.2f} | -- |")
    lines.append(f"| **Total Trades** | -- | {suite.total_trades} | -- |")
    lines.append(f"| **Assets x Regimes** | -- | {suite.assets_tested} | -- |")
    lines.append("")

    regime_groups = defaultdict(list)
    for r in suite.results:
        regime_groups[r.regime].append(r)

    lines.append("## 2. Performance by Market Regime")
    lines.append("")
    lines.append("| Regime | Trades | Win Rate | Signals/Day | Max DD | Profit Factor |")
    lines.append("| :--- | ---: | ---: | ---: | ---: | ---: |")
    for regime in ["mixed", "trending", "ranging", "volatile"]:
        group = regime_groups.get(regime, [])
        if not group:
            continue
        trades = sum(g.total_trades for g in group)
        wins = sum(g.wins for g in group)
        wr = wins / trades if trades else 0
        spd = statistics.mean([g.signals_per_day for g in group])
        mdd = max(g.max_drawdown for g in group)
        pf = statistics.mean([g.profit_factor for g in group
                             if g.profit_factor != float('inf')])
        lines.append(f"| **{regime.title()}** | {trades} | {wr*100:.2f}% | {spd:.1f} | {mdd*100:.2f}% | {pf:.2f} |")
    lines.append("")

    lines.append("## 3. Performance by Asset (Mixed Regime)")
    lines.append("")
    lines.append("| Asset | Class | Trades | Win Rate | Signals/Day | Max DD |")
    lines.append("| :--- | :--- | ---: | ---: | ---: | ---: |")
    mixed_results = regime_groups.get("mixed", [])
    for result in sorted(mixed_results, key=lambda r: r.win_rate, reverse=True):
        asset_class = ASSET_CONFIG[result.asset]["class"]
        icon = "OK" if result.win_rate >= 0.80 else "WARN"
        lines.append(f"| {icon} {result.asset} | {asset_class} | {result.total_trades} | {result.win_rate*100:.2f}% | {result.signals_per_day:.1f} | {result.max_drawdown*100:.2f}% |")
    lines.append("")

    class_groups = defaultdict(list)
    for r in suite.results:
        ac = ASSET_CONFIG[r.asset]["class"]
        class_groups[ac].append(r)

    lines.append("## 4. Performance by Asset Class")
    lines.append("")
    lines.append("| Class | Avg Win Rate | Avg Signals/Day | Best Asset | Worst Asset |")
    lines.append("| :--- | ---: | ---: | :--- | :--- |")
    for cls in ["Forex", "Crypto", "Indices", "Commodities"]:
        group = class_groups.get(cls, [])
        if not group:
            continue
        avg_wr = statistics.mean([g.win_rate for g in group])
        avg_spd = statistics.mean([g.signals_per_day for g in group])
        best = max(group, key=lambda g: g.win_rate)
        worst = min(group, key=lambda g: g.win_rate)
        lines.append(f"| **{cls}** | {avg_wr*100:.2f}% | {avg_spd:.1f} | {best.asset} ({best.win_rate*100:.2f}%) | {worst.asset} ({worst.win_rate*100:.2f}%) |")
    lines.append("")

    lines.append("## 5. Detailed Metrics")
    lines.append("")
    lines.append("### 5.1 Win Rate Confidence Intervals (95%)")
    lines.append("")
    lines.append("| Asset | Win Rate | CI Lower | CI Upper | Range |")
    lines.append("| :--- | ---: | ---: | ---: | :--- |")
    for result in sorted(mixed_results, key=lambda r: r.win_rate, reverse=True):
        lines.append(f"| {result.asset} | {result.win_rate*100:.2f}% | {result.confidence_lower*100:.2f}% | {result.confidence_upper*100:.2f}% | {result.confidence_upper - result.confidence_lower:.2f}% |")
    lines.append("")

    lines.append("### 5.2 Edge Case Analysis")
    lines.append("")
    worst_results = sorted(suite.results, key=lambda r: r.win_rate)[:3]
    lines.append("**Worst Performing Scenarios:**")
    for r in worst_results:
        lines.append(f"- {r.asset} ({r.regime}): {r.win_rate*100:.2f}% WR, {r.total_trades} trades")
    best_results = sorted(suite.results, key=lambda r: r.win_rate, reverse=True)[:3]
    lines.append("**Best Performing Scenarios:**")
    for r in best_results:
        lines.append(f"- {r.asset} ({r.regime}): {r.win_rate*100:.2f}% WR, {r.total_trades} trades")
    lines.append("")

    lines.append("### 5.3 Risk Assessment")
    lines.append("")
    lines.append(f"- **Max Drawdown Across All Scenarios:** {suite.overall_max_drawdown*100:.2f}%")
    lines.append(f"- **Profit Factor (avg):** {suite.overall_profit_factor:.2f}")
    lines.append(f"- **Sharpe Ratio (approx):** {suite.overall_sharpe:.2f}")
    lines.append(f"- **Total Trades Analyzed:** {suite.total_trades}")

    lines.append("")
    lines.append("### 5.4 Regime Robustness")
    for regime in ["mixed", "trending", "ranging", "volatile"]:
        group = regime_groups.get(regime, [])
        if group:
            avg_wr = statistics.mean([g.win_rate for g in group])
            avg_spd = statistics.mean([g.signals_per_day for g in group])
            lines.append(f"- **{regime.title()}:** Avg WR = {avg_wr*100:.2f}% | Signals/Day = {avg_spd:.1f}")
    lines.append("")

    lines.append("## 6. Target Assessment")
    lines.append("")
    targets = [
        ("Win Rate >= 80%", f"{suite.overall_win_rate*100:.2f}%", passed),
        ("Signals/Day 50-150", f"{suite.overall_signals_per_day:.1f}", passed_freq),
        ("Max Drawdown <= 15%", f"{suite.overall_max_drawdown*100:.2f}%", passed_dd),
    ]
    for target, actual, passed_target in targets:
        icon = "PASS" if passed_target else "FAIL"
        lines.append(f"- [{icon}] **{target}** -> Actual: {actual}")

    lines.append("")
    lines.append("---")
    lines.append("*Report generated by ApexTrade Strategies -- Testing & Validation Engineer*")

    report = "\n".join(lines)

    if output_path:
        with open(output_path, "w") as f:
            f.write(report)

    return report

# ──────────────────────────────────────────────────────────────────────
# 8.  Main Entry Point
# ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 72)
    print("  Apex Prime UHF -- Backtest Validation Suite v1.1")
    print("  Testing & Validation Engineer -- ApexTrade Strategies")
    print("=" * 72)
    print()

    print("[1/4] Running smoke test (1 day, 1 asset)...")
    smoke = run_backtest("EUR/USD", 1440, regime="mixed")
    print(f"  Smoke test: {smoke.total_trades} trades, "
          f"WR={smoke.win_rate*100:.2f}%, DD={smoke.max_drawdown*100:.2f}%")
    print()

    print("[2/4] Running full suite (30 days x 4 regimes x 18 assets)...")
    suite = run_suite(
        assets=list(ASSET_CONFIG.keys()),
        num_days=30,
        regimes=["mixed", "trending", "ranging", "volatile"],
        initial_balance=10000.0
    )
    print(f"  Suite complete: {suite.total_trades} total trades "
          f"across {suite.assets_tested} scenarios")
    print(f"  Overall WR: {suite.overall_win_rate*100:.2f}%")
    print(f"  Overall Signals/Day: {suite.overall_signals_per_day:.1f}")
    print(f"  Overall Max DD: {suite.overall_max_drawdown*100:.2f}%")
    print()

    print("[3/4] Running extended stability test (90 days, 6 major assets)...")
    major_assets = ["EUR/USD", "GBP/USD", "BTC/USD",
                    "S&P500", "XAU/USD", "USD/JPY"]
    extended_results = []
    for asset in major_assets:
        result = run_backtest(asset, int(90 * 1440), regime="mixed")
        extended_results.append(result)
        print(f"  {asset}: {result.total_trades} trades, "
              f"WR={result.win_rate*100:.2f}%, DD={result.max_drawdown*100:.2f}%")

    ext_trades = sum(r.total_trades for r in extended_results)
    ext_wins = sum(r.wins for r in extended_results)
    ext_wr = ext_wins / ext_trades if ext_trades > 0 else 0.0
    ext_dd = max(r.max_drawdown for r in extended_results)
    print(f"  Extended summary: {ext_trades} trades, "
          f"WR={ext_wr*100:.2f}%, DD={ext_dd*100:.2f}%")
    print()

    print("[4/4] Generating validation report...")
    report_path = "/home/team/shared/validation-report.md"
    report = generate_report(suite, output_path=report_path)
    print(f"  Report saved to: {report_path}")
    print()

    print("=" * 72)
    if (suite.overall_win_rate >= 0.80 and
            50 <= suite.overall_signals_per_day <= 150 and
            suite.overall_max_drawdown <= 0.15):
        print("  ALL TARGETS MET -- Strategy validated successfully!")
    else:
        print("  Some targets not met -- review report for details.")
    print("=" * 72)

    json_path = "/home/team/shared/backtest/results.json"
    raw_data = {
        "strategy": "Apex Prime UHF v1.1",
        "overall": {
            "win_rate": suite.overall_win_rate,
            "signals_per_day": suite.overall_signals_per_day,
            "max_drawdown": suite.overall_max_drawdown,
            "profit_factor": suite.overall_profit_factor,
            "sharpe_approx": suite.overall_sharpe,
            "total_trades": suite.total_trades,
            "scenarios": suite.assets_tested
        },
        "per_asset": [
            {
                "asset": r.asset, "regime": r.regime,
                "trades": r.total_trades, "win_rate": r.win_rate,
                "signals_per_day": r.signals_per_day,
                "max_drawdown": r.max_drawdown,
                "profit_factor": r.profit_factor
            }
            for r in suite.results
        ],
        "extended_test": [
            {
                "asset": r.asset, "trades": r.total_trades,
                "win_rate": r.win_rate,
                "signals_per_day": r.signals_per_day,
                "max_drawdown": r.max_drawdown
            }
            for r in extended_results
        ]
    }
    with open(json_path, "w") as f:
        json.dump(raw_data, f, indent=2, default=str)
    print(f"  Raw results saved to: {json_path}")