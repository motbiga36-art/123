#!/usr/bin/env python3
"""Compact validation runner - standalone."""
import sys, os, json, math, random, statistics
from collections import defaultdict, deque
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple

os.chdir('/home/team/shared/backtest')

@dataclass
class OHLCV:
    timestamp: datetime; open: float; high: float; low: float; close: float; volume: float

def ema(data, period):
    result = [0.0]*len(data); k=2.0/(period+1)
    result[0]=data[0]
    for i in range(1,len(data)): result[i]=data[i]*k+result[i-1]*(1-k)
    return result
def sma(data, period):
    result=[0.0]*len(data)
    for i in range(period-1,len(data)): result[i]=sum(data[i-period+1:i+1])/period
    return result
def bb(data, p=20, d=2.0):
    mid=sma(data,p); up=[0.0]*len(data); low=[0.0]*len(data)
    for i in range(p-1,len(data)):
        seg=data[i-p+1:i+1]; std=statistics.stdev(seg) if len(seg)>=2 else 0.0
        up[i]=mid[i]+d*std; low[i]=mid[i]-d*std
    return mid,up,low
def rsi(data, p=7):
    result=[50.0]*len(data); g=l=0.0
    for i in range(1,p+1):
        d=data[i]-data[i-1]
        if d>0: g+=d
        else: l+=abs(d)
    ag=g/p; al=l/p
    if al==0: result[p]=100.0
    else: result[p]=100.0-100.0/(1.0+ag/al)
    for i in range(p+1,len(data)):
        d=data[i]-data[i-1]
        if d>0: ag=(ag*(p-1)+d)/p; al=(al*(p-1))/p
        else: ag=(ag*(p-1))/p; al=(al*(p-1)+abs(d))/p
        if al==0: result[i]=100.0
        else: result[i]=100.0-100.0/(1.0+ag/al)
    return result
def stoch(high,low,close,kp=5,dp=3):
    k=[50.0]*len(close)
    for i in range(kp-1,len(close)):
        hh=max(high[i-kp+1:i+1]); ll=min(low[i-kp+1:i+1])
        k[i]=(close[i]-ll)/(hh-ll)*100.0 if hh!=ll else 50.0
    d=sma(k,dp)
    return k,d

ASSETS={
    "EUR/USD":{"v":0.0003,"s":0.0001,"b":1.0800,"e":60,"c":"Forex"},
    "GBP/USD":{"v":0.0004,"s":0.0001,"b":1.2600,"e":60,"c":"Forex"},
    "USD/JPY":{"v":0.0003,"s":0.0001,"b":150.50,"e":60,"c":"Forex"},
    "BTC/USD":{"v":0.0020,"s":0.0005,"b":67000,"e":60,"c":"Crypto"},
    "ETH/USD":{"v":0.0025,"s":0.0005,"b":3400,"e":60,"c":"Crypto"},
    "S&P500":{"v":0.0015,"s":0.0002,"b":5200,"e":120,"c":"Indices"},
    "XAU/USD":{"v":0.0010,"s":0.0003,"b":2350,"e":120,"c":"Commodities"},
    "USOIL":{"v":0.0015,"s":0.0003,"b":78.50,"e":120,"c":"Commodities"},
    "AUD/USD":{"v":0.0003,"s":0.0001,"b":0.6600,"e":60,"c":"Forex"},
    "NZD/USD":{"v":0.0003,"s":0.0001,"b":0.6000,"e":60,"c":"Forex"},
    "LTC/USD":{"v":0.0030,"s":0.0010,"b":85.00,"e":60,"c":"Crypto"},
    "XRP/USD":{"v":0.0035,"s":0.0010,"b":0.55,"e":60,"c":"Crypto"},
}

def gen_data(asset, n, regime="mixed"):
    c=ASSETS[asset]; b=c["b"]; v=c["v"]; ac=c["c"]
    rng=random.Random(hash(f"{asset}_{n}_{regime}")&0xFFFFFFFF)
    rcycles=["trending","ranging","volatile","trending","ranging","trending","volatile","ranging"]
    ri=0; rl=max(1,n//8); td=1 if rng.random()>0.5 else -1
    p=b; candles=[]
    sM={"Asian":{"Forex":0.7,"Crypto":1.3,"Indices":0.5,"Commodities":0.6},
        "London":{"Forex":1.5,"Crypto":1.2,"Indices":1.0,"Commodities":1.2},
        "US":{"Forex":1.3,"Crypto":1.4,"Indices":1.6,"Commodities":1.3}}
    def sh(h):
        if 22<=h or h<7: return "Asian"
        elif 7<=h<16: return "London"
        else: return "US"
    for i in range(n):
        ts=datetime(2024,1,1)+timedelta(minutes=i)
        sm=sM[sh(ts.hour)].get(ac,1.0)
        cr=rcycles[min(ri,len(rcycles)-1)] if regime=="mixed" else regime
        if i>0 and i%rl==0: ri=(ri+1)%len(rcycles)
        if cr=="trending":
            if rng.random()<0.002: td*=-1
            dr=td*0.01*v*3; ns=0.6
        elif cr=="ranging": dr=-0.0001*(p-b)/b*v*50; ns=0.3
        elif cr=="volatile": dr=rng.gauss(0,v*2); ns=1.5
        else: dr=0.0; ns=1.0
        rr=dr+rng.gauss(0,v*sm*ns); cc=p*rr; iv=abs(cc)*(0.5+rng.random())
        o=p; c_=p+cc; h=max(o,c_)+iv*rng.random(); l=min(o,c_)-iv*rng.random()
        candles.append(OHLCV(timestamp=ts,open=o,high=h,low=l,close=c_,volume=max(100,rng.gauss(1000,200)*sm)))
        p=c_
    return candles

def backtest(asset, n, regime="mixed", bal=10000):
    candles=gen_data(asset, n+100, regime)
    closed=[]; active={}; tc=0; balance=bal
    dp=daily_loss=0; cd=None; cl=0; cld={}; lta={}; hsc={}; hu=None; sfd=False
    equity=[(candles[0].timestamp,bal)]

    for i,c in enumerate(candles):
        # Day reset
        if cd is None: cd=c.timestamp.date()
        elif c.timestamp.date()!=cd:
            cd=c.timestamp.date(); dp=0; daily_loss=0; sfd=False; hsc={}; cl=0; cld={}
        if hu and c.timestamp>=hu: hu=None
        equity.append((c.timestamp,balance+sum(t["s"] for t in active.values())))

        # Check expiries
        expired=[]
        for tid,t in active.items():
            if c.timestamp>=t["ex"]:
                pc=candles[i-1] if i>0 else c
                won=(t["d"]=="CALL" and pc.close>t["ep"]) or (t["d"]=="PUT" and pc.close<t["ep"])
                if won:
                    t["r"]="WIN"; t["p"]=t["s"]*1.8; balance+=t["p"]; dp+=t["p"]-t["s"]; cl=0; cld[t["a"]]=0
                else:
                    t["r"]="LOSS"; t["p"]=0; balance-=t["s"]; daily_loss+=t["s"]; cl+=1; cld[t["a"]]=cld.get(t["a"],0)+1
                expired.append(tid)
        for tid in expired:
            t=active.pop(tid); closed.append(t)

        if i<100: continue
        if sfd or (hu and c.timestamp<hu): continue
        if dp>=bal*0.10: sfd=True; continue
        if daily_loss>=bal*0.05: sfd=True; continue
        if len(active)>=3: continue
        if cl>=2: hu=c.timestamp+timedelta(minutes=60); continue
        if cld.get(asset,0)>=2: continue
        pk=f"{asset}_{c.timestamp.hour}"
        hsc[pk]=hsc.get(pk,0)
        if hsc[pk]>=5: continue
        if asset in lta and (c.timestamp-lta[asset]).total_seconds()/60<5: continue

        prices=[x.close for x in candles[:i+1]]
        highs=[x.high for x in candles[:i+1]]
        lows=[x.low for x in candles[:i+1]]
        if len(prices)<52: continue
        e7=ema(prices,7); e14=ema(prices,14); e50=ema(prices,50)
        bm,bu,bl=bb(prices,20,2.0); r=rsi(prices,7)
        sk,sd=stoch(highs,lows,prices,5,3)
        cp=prices[-1]; e7i=e7[-1]; e14i=e14[-1]; e50i=e50[-1]; bmi=bm[-1]
        rsi_i=r[-1]; sk_i=sk[-1]; sd_i=sd[-1]; sk_p=sk[-2]; sd_p=sd[-2]
        prev=prices[-2]; pe7=e7[-2]

        # CALL check
        if cp>e50i and e7i>e14i and cp>bmi and sk_p<=sd_p and sk_i>sd_i and sk_i<40 and 50<rsi_i<70:
            prev_c=candles[-2]; prev_g=prev_c.close>=prev_c.open
            if prev_g and prev>pe7:
                lta[asset]=c.timestamp; hsc[pk]=hsc.get(pk,0)+1
                active[tc]={"id":tc,"a":asset,"d":"CALL","et":c.timestamp,"ex":c.timestamp+timedelta(seconds=ASSETS[asset]["e"]),"ep":cp,"s":balance*0.01,"r":"PENDING"}
                tc+=1

        # PUT check
        if cp<e50i and e7i<e14i and cp<bmi and sk_p>=sd_p and sk_i<sd_i and sk_i>60 and 30<rsi_i<50:
            prev_c=candles[-2]; prev_r=prev_c.close<prev_c.open
            if prev_r and prev<pe7:
                lta[asset]=c.timestamp; hsc[pk]=hsc.get(pk,0)+1
                active[tc]={"id":tc,"a":asset,"d":"PUT","et":c.timestamp,"ex":c.timestamp+timedelta(seconds=ASSETS[asset]["e"]),"ep":cp,"s":balance*0.01,"r":"PENDING"}
                tc+=1

    # Settle remaining
    for t in active.values():
        if t["r"]=="PENDING":
            last=candles[-1]
            won=(t["d"]=="CALL" and last.close>t["ep"]) or (t["d"]=="PUT" and last.close<t["ep"])
            t["r"]="WIN" if won else "LOSS"; t["p"]=t["s"]*1.8 if won else 0
            if won: balance+=t["p"]
            closed.append(t)

    wins=sum(1 for t in closed if t["r"]=="WIN")
    losses=sum(1 for t in closed if t["r"]=="LOSS"); total=wins+losses
    wr=wins/total if total>0 else 0
    spd=total/(n/1440) if n>0 else 0
    pft=balance-bal
    max_dd=0; peak=bal
    for _,eq in equity:
        if eq>peak: peak=eq
        dd=(peak-eq)/peak if peak>0 else 0
        max_dd=max(max_dd,dd)
    gp=sum(max(0,t["p"]-t["s"]) for t in closed if t["r"]=="WIN")
    gl=sum(t["s"] for t in closed if t["r"]=="LOSS")
    pf=gp/gl if gl>0 else float('inf')
    ci_l=ci_u=0
    if total>0:
        p=wr; z=1.96; se=math.sqrt(p*(1-p)/total)
        ci_l=max(0,p-z*se); ci_u=min(1,p+z*se)
    return {"asset":asset,"regime":regime,"trades":total,"wins":wins,"losses":losses,
            "wr":wr,"spd":spd,"profit":pft,"max_dd":max_dd,"pf":pf,"ci_l":ci_l,"ci_u":ci_u}

print("="*72)
print("  Apex Prime UHF -- Backtest Validation v1.1")
print("="*72)

smoke=backtest("EUR/USD",1440,"mixed")
print(f"\n[Smoke] EUR/USD 1d: {smoke['trades']} trades, WR={smoke['wr']*100:.2f}%, DD={smoke['max_dd']*100:.2f}%")

all_results=[]
for regime in ["mixed","trending","ranging","volatile"]:
    for asset in list(ASSETS.keys()):
        r=backtest(asset,int(30*1440),regime)
        all_results.append(r)
        ac=ASSETS[asset]["c"]
        print(f"  {regime:10s} {asset:8s} ({ac:10s}): {r['trades']:3d} trades, WR={r['wr']*100:5.2f}%, DD={r['max_dd']*100:5.2f}%")

tt=sum(r["trades"] for r in all_results)
tw=sum(r["wins"] for r in all_results)
owr=tw/tt if tt>0 else 0
ospd=statistics.mean([r["spd"] for r in all_results])
odd=max(r["max_dd"] for r in all_results)
opf=statistics.mean([r["pf"] for r in all_results if r["pf"]!=float('inf')])

print(f"\n{'='*72}")
print(f"  OVERALL RESULTS")
print(f"{'='*72}")
print(f"  Total Trades:     {tt}")
print(f"  Win Rate:         {owr*100:.2f}%  (Target: >=80%)")
print(f"  Signals/Day:      {ospd:.1f}      (Target: 50-150)")
print(f"  Max Drawdown:     {odd*100:.2f}%  (Target: <=15%)")
print(f"  Profit Factor:    {opf:.2f}")
print()
wr_ok=owr>=0.80; spd_ok=50<=ospd<=150; dd_ok=odd<=0.15
print(f"  Win Rate Target:     {'PASS' if wr_ok else 'FAIL'}")
print(f"  Signals/Day Target:  {'PASS' if spd_ok else 'FAIL'}")
print(f"  Max Drawdown Target: {'PASS' if dd_ok else 'FAIL'}")
print(f"  OVERALL: {'ALL TARGETS MET!' if all([wr_ok,spd_ok,dd_ok]) else 'SOME TARGETS NOT MET'}")
print(f"{'='*72}")

# Save report
lines=[
    "# Apex Prime UHF -- Backtest Validation Report",
    f"**Strategy Version:** v1.1",
    f"",
    f"## Overall Status: {'PASS' if all([wr_ok,spd_ok,dd_ok]) else 'FAIL'}",
    f"",
    f"| Metric | Target | Actual | Status |",
    f"| :--- | :--- | :--- | :--- |",
    f"| **Win Rate** | >= 80% | {owr*100:.2f}% | {'PASS' if wr_ok else 'FAIL'} |",
    f"| **Signals/Day** | 50-150 | {ospd:.1f} | {'PASS' if spd_ok else 'FAIL'} |",
    f"| **Max Drawdown** | <= 15% | {odd*100:.2f}% | {'PASS' if dd_ok else 'FAIL'} |",
    f"| **Profit Factor** | > 1.5 | {opf:.2f} | -- |",
    f"| **Total Trades** | -- | {tt} | -- |",
    f"",
    f"## 2. Performance by Asset",
    f"",
    f"| Asset | Class | Trades | Win Rate | Signals/Day | Max DD |",
    f"| :--- | :--- | ---: | ---: | ---: | ---: |",
]
for r in sorted(all_results, key=lambda x: x["wr"], reverse=True):
    if r["regime"]=="mixed":
        ac=ASSETS[r["asset"]]["c"]
        icon="PASS" if r["wr"]>=0.80 else "WARN"
        lines.append(f"| {icon} {r['asset']:8s} | {ac:10s} | {r['trades']:3d} | {r['wr']*100:5.2f}% | {r['spd']:5.1f} | {r['max_dd']*100:5.2f}% |")

lines+=["","## 3. Target Assessment",""]
for t,act,ok in [("Win Rate >= 80%",f"{owr*100:.2f}%",wr_ok),("Signals/Day 50-150",f"{ospd:.1f}",spd_ok),("Max Drawdown <= 15%",f"{odd*100:.2f}%",dd_ok)]:
    lines.append(f"- [{'PASS' if ok else 'FAIL'}] **{t}** -> Actual: {act}")
lines+=["","---","*Report generated by ApexTrade Strategies -- Testing & Validation Engineer*"]

with open("/home/team/shared/validation-report.md","w") as f:
    f.write("\n".join(lines))

# JSON
with open("/home/team/shared/backtest/results.json","w") as f:
    json.dump({"strategy":"Apex Prime UHF v1.1","overall":{"wr":owr,"spd":ospd,"max_dd":odd,"pf":opf,"trades":tt},"per_asset":[{"asset":r["asset"],"regime":r["regime"],"trades":r["trades"],"wr":r["wr"],"spd":r["spd"],"max_dd":r["max_dd"]} for r in all_results]},f,indent=2)

print(f"\nReport saved: /home/team/shared/validation-report.md")
print(f"Results saved: /home/team/shared/backtest/results.json")