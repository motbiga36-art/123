#!/usr/bin/env python3
"""Minimal validator — fresh exec, no caching issues."""
import sys, os
os.chdir('/home/team/shared/backtest')
sys.dont_write_bytecode = True
sys.path.insert(0, '.')

# Direct exec from fresh read
with open('run_validation.py') as f:
    code = f.read()
exec(compile(code, 'run_validation.py', 'exec'))