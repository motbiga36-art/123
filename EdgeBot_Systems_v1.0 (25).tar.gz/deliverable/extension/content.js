const ENGINE_URL = "http://127.0.0.1:8765";
console.log("EdgeBot: FINAL v1.0 - human behavior mode");

let candleBuffer = {};
let currentAsset = "";
let favoritesList = [];
let isExecutingTrade = false;
let balanceDetected = false;
let assetStayStart = Date.now();
let assetCycleDone = false;
let tradeEndTime = 0;
let restAfterTrade = false;
let historyLoaded = false;

const SEL = {
    balance: ".balance-value, .user-balance, .balance-info__value, [class*=balance]",
    price: ".current-price, .price",
    assetLabel: ".current-symbol, [class*=symbol]",
    assetTrigger: ".current-symbol, .assets-block__current",
    alistFavorites: ".alist-favorites",
    favoriteLabel: ".alist-favorites .alist__label",
    favoritePayout: ".alist-favorites .alist__payout",
    alistAllLabels: ".alist__item .alist__label",
    assetSearch: "input[placeholder]",
    amountInput: ".block--bet-amount input, .value__val input",
    btnCall: ".btn-call",
    btnPut: ".btn-put",
};

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function qs(s, ctx) { return (ctx || document).querySelector(s); }
function qsa(s, ctx) { return (ctx || document).querySelectorAll(s); }

function rand(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }

function getBalance() {
    let el = qs(SEL.balance);
    if (el) {
        let t = (el.innerText || el.textContent || "").replace(/[^0-9.]/g, "");
        if (t && parseFloat(t) > 0) return t;
    }
    return "0";
}

function getPrice() {
    let el = qs(SEL.price);
    if (el) {
        let p = parseFloat(el.innerText.replace(/[^0-9.]/g, ""));
        if (!isNaN(p) && p > 0) return p;
    }
    return 0;
}

function getAsset() {
    let el = qs(SEL.assetLabel);
    return el ? (el.innerText || "").replace(/[^A-Za-z\/]/g, "") : "unknown";
}

function updateCandles(asset, price) {
    if (!candleBuffer[asset]) candleBuffer[asset] = [];
    const now = Date.now();
    const candleTime = Math.floor(now / 60000) * 60000;
    const buf = candleBuffer[asset];
    if (buf.length === 0 || buf[buf.length - 1].t !== candleTime) {
        buf.push({ t: candleTime, o: price, h: price, l: price, c: price, v: 1 });
        if (buf.length > 1000) buf.shift();
    } else {
        let c = buf[buf.length - 1];
        c.h = Math.max(c.h, price);
        c.l = Math.min(c.l, price);
        c.c = price;
        c.v = (c.v || 0) + 1;
    }
}

function parsePayout(text) {
    let n = parseFloat(text.replace(/[^0-9.]/g, ""));
    return isNaN(n) ? 0 : n;
}

function readFavorites() {
    try {
        let items = qsa(SEL.favoriteLabel);
        let payouts = qsa(SEL.favoritePayout);
        if (items && items.length > 0) {
            let assets = [];
            for (let i = 0; i < items.length; i++) {
                let name = (items[i].innerText || "").replace(/[^A-Za-z\/]/g, "");
                let payout = payouts[i] ? parsePayout(payouts[i].innerText) : 0;
                if (name && name.includes('/')) {
                    assets.push({ name, payout, allowed: payout >= 70 });
                }
            }
            if (assets.length > 0) {
                favoritesList = assets;
                let ok = assets.filter(a => a.allowed).length;
                console.log(`EdgeBot: ${assets.length} favorites (${ok} ok, ${assets.length-ok} <70%)`);
                return true;
            }
        }
    } catch(e) {}
    return false;
}

function getNextTarget() {
    let allowed = favoritesList.filter(a => a.allowed);
    if (allowed.length === 0) return null;
    let idx = 0;
    if (currentAsset) {
        let curIdx = allowed.findIndex(a => a.name === currentAsset);
        if (curIdx >= 0) idx = (curIdx + 1) % allowed.length;
    }
    return allowed[idx];
}

async function switchToAsset(targetName) {
    if (!targetName || targetName === currentAsset || isExecutingTrade) return false;
    console.log(`EdgeBot: Switching to ${targetName}...`);
    let trigger = qs(SEL.assetTrigger);
    if (!trigger) return false;
    trigger.click();
    await sleep(rand(600, 1200));
    let labels = qsa(SEL.alistAllLabels);
    let found = false;
    for (let label of labels) {
        try {
            let text = (label.innerText || "").replace(/[^A-Za-z\/]/g, "");
            if (text.toUpperCase() === targetName.toUpperCase()) {
                label.click();
                await sleep(rand(800, 1500));
                currentAsset = targetName;
                assetStayStart = Date.now();
                assetCycleDone = false;
                console.log(`EdgeBot: Switched to ${targetName}`);
                found = true;
                break;
            }
        } catch(e) {}
    }
    if (!found) {
        let search = qs(SEL.assetSearch);
        if (search) {
            search.value = ""; await sleep(200);
            for (let ch of targetName) { search.value += ch; search.dispatchEvent(new Event('input', { bubbles: true })); await sleep(rand(40, 100)); }
            await sleep(rand(500, 1000));
            labels = qsa(SEL.alistAllLabels);
            for (let label of labels) {
                let text = (label.innerText || "").replace(/[^A-Za-z\/]/g, "");
                if (text.toUpperCase() === targetName.toUpperCase()) {
                    label.click(); await sleep(rand(800, 1500));
                    currentAsset = targetName; assetStayStart = Date.now(); assetCycleDone = false;
                    console.log(`EdgeBot: Switched via search`);
                    found = true; break;
                }
            }
        }
    }
    if (found) {
        let wrap = document.querySelector(".drop-down-modal-wrap");
        if (wrap) { wrap.click(); await sleep(rand(200, 400)); }
    }
    return found;
}

function nativeSetValue(input, value) {
    if (!input) return;
    let setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    setter.call(input, value);
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
}

async function setExpiry(minutes) {
    console.log(`EdgeBot: Setting expiry to ${minutes}min`);
    let tfMap = {1:"M1", 3:"M3", 5:"M5", 30:"M30", 60:"H1", 240:"H4"};
    let timeField = document.querySelector(".block--expiration-inputs .value__val, .block--expiration-inputs input");
    if (!timeField) return false;
    timeField.click();
    await sleep(rand(500, 900));
    // Try presets
    if (tfMap[minutes]) {
        let items = document.querySelectorAll(".dops__timeframes-item");
        for (let item of items) {
            let text = (item.innerText || "").trim().toUpperCase();
            if (text === tfMap[minutes]) { item.click(); await sleep(400); console.log(`EdgeBot: Expiry = ${tfMap[minutes]}`); return true; }
        }
    }
    // +/- buttons
    let rows = document.querySelectorAll(".trading-panel-modal__in .rw");
    if (rows.length >= 2) {
        let minRow = rows[1];
        let currentMin = parseInt(minRow.querySelector("input")?.value || "0");
        let diff = minutes - currentMin;
        console.log(`EdgeBot: ${currentMin}min -> ${minutes}min (${diff} clicks)`);
        if (diff > 0) {
            let plusBtn = minRow.querySelector(".btn-plus");
            if (plusBtn) { for (let i = 0; i < diff; i++) { plusBtn.click(); await sleep(rand(60, 120)); } }
        } else if (diff < 0) {
            let minusBtn = minRow.querySelector(".btn-minus");
            if (minusBtn) { for (let i = 0; i < Math.abs(diff); i++) { minusBtn.click(); await sleep(rand(60, 120)); } }
        }
        await sleep(300);
        let wrap = document.querySelector(".drop-down-modal-wrap");
        if (wrap) wrap.click();
        await sleep(200);
        console.log(`EdgeBot: Expiry set to ${minutes}min`);
        return true;
    }
    let wrap = document.querySelector(".drop-down-modal-wrap");
    if (wrap) wrap.click();
    return false;
}

async function executeTrade(trade) {
    if (isExecutingTrade) return;
    isExecutingTrade = true;
    restAfterTrade = false;
    console.log("EdgeBot: EXECUTING TRADE", trade);
    
    // Set amount
    let inp = qs(SEL.amountInput);
    if (inp && trade.stake) {
        inp.click(); await sleep(rand(200, 500));
        nativeSetValue(inp, trade.stake.toFixed(2));
        console.log(`EdgeBot: Amount = $${trade.stake.toFixed(2)}`);
    }
    
    // Set expiry
    if (trade.expiry) { await setExpiry(trade.expiry); }
    
    // HUMAN DELAY 500-2000ms
    let delay = rand(500, 2000);
    await sleep(delay);
    
    // Click
    let btn = qs(trade.action === "buy" ? SEL.btnCall : SEL.btnPut);
    if (btn) {
        btn.click();
        console.log(`EdgeBot: ${trade.action.toUpperCase()} CLICKED! (${delay}ms)`);
        // Don't switch during trade + rest after
        let waitMs = Math.min((trade.expiry || 1) * 60 * 1000 + 5000, 180000);
        tradeEndTime = Date.now() + waitMs;
        setTimeout(() => {
            isExecutingTrade = false;
            restAfterTrade = true;
            tradeEndTime = Date.now() + rand(120000, 300000); // 2-5 min rest
            console.log(`EdgeBot: Resting 2-5 min on same asset`);
            setTimeout(() => { restAfterTrade = false; console.log("EdgeBot: Can switch assets"); }, rand(120000, 300000));
        }, waitMs);
    } else {
        console.error("EdgeBot: Button not found!");
        isExecutingTrade = false;
    }
}

async function syncWithEngine() {
    const balance = getBalance();
    const asset = getAsset();
    const price = getPrice();
    
    if (price > 0) updateCandles(asset, price);
    if (!balanceDetected && parseFloat(balance) > 0) {
        balanceDetected = true;
        console.log(`EdgeBot: Balance: $${balance}`);
    }
    
    if (asset && asset !== currentAsset && asset !== "unknown") {
        currentAsset = asset;
        assetStayStart = Date.now();
        assetCycleDone = false;
    }
    
    // Try to load history from engine once
    if (!historyLoaded) {
        try {
            let r = await fetch(`${ENGINE_URL}/history`);
            let data = await r.json();
            if (data.candles) {
                for (let sym in data.candles) {
                    candleBuffer[sym] = data.candles[sym];
                }
                console.log(`EdgeBot: Loaded history for ${Object.keys(data.candles).length} assets`);
                historyLoaded = true;
            }
        } catch(e) {}
    }
    
    readFavorites();
    
    // If in trade or resting, just send data
    if (isExecutingTrade || restAfterTrade) {
        try {
            await fetch(`${ENGINE_URL}/data`, {
                method: "POST", headers: {"Content-Type": "application/json"},
                body: JSON.stringify({ balance, asset, timestamp: new Date().toISOString() })
            });
        } catch(e) {}
        return;
    }
    
    // No favorites yet -> just send
    if (favoritesList.length === 0) {
        try {
            let r = await fetch(`${ENGINE_URL}/data`, {
                method: "POST", headers: {"Content-Type": "application/json"},
                body: JSON.stringify({ balance, asset, timestamp: new Date().toISOString() })
            });
            let result = await r.json();
            if (result.action && result.action !== "wait") await executeTrade(result);
        } catch(e) {}
        return;
    }
    
    // Stay on asset 10-25 seconds (human behavior)
    let stayed = Date.now() - (assetStayStart || 0);
    let minStay = rand(10000, 15000);
    let maxStay = rand(20000, 25000);
    
    if (stayed < minStay) {
        try { await fetch(`${ENGINE_URL}/data`, { method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify({ balance, asset, candles: candleBuffer[asset] || [], timestamp: new Date().toISOString() }) }); } catch(e) {}
        return;
    }
    
    // Analyze once
    if (!assetCycleDone) {
        assetCycleDone = true;
        let cCount = candleBuffer[asset]?.length || 0;
        console.log(`EdgeBot: Analyzing ${asset} (${cCount} candles)`);
        try {
            let r = await fetch(`${ENGINE_URL}/data`, {
                method: "POST", headers: {"Content-Type": "application/json"},
                body: JSON.stringify({ balance, asset, candles: candleBuffer[asset] || [], timestamp: new Date().toISOString() })
            });
            let result = await r.json();
            if (result.action && result.action !== "wait") { await executeTrade(result); return; }
        } catch(e) {}
    }
    
    // Switch only after 20-25 seconds
    if (stayed >= maxStay) {
        let target = getNextTarget();
        if (target && target.name !== currentAsset) {
            await switchToAsset(target.name);
        }
    }
}

setTimeout(async () => {
    console.log("EdgeBot: FINAL v1.0 STARTING");
    console.log("EdgeBot: Human mode: 10-25s per asset, 2-5min rest after trade");
    await sleep(2000);
    readFavorites();
    setInterval(syncWithEngine, 3000);
}, 3000);