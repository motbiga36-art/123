@echo off
title EdgeBot Systems v1.0 - FULL MODE
color 0A
echo ============================================
echo   EdgeBot Systems v1.0
echo   Apex Prime UHF v2.1 + Risk Management
echo ============================================
echo.

if not exist "%~dp0engine\venv\" (
    echo [ERROR] Run install.bat first
    pause
    exit /b 1
)

echo Starting FULL ENGINE...
echo Strategy: Apex Prime UHF v2.1 (18 assets)
echo Risk: 1 trade, -50% stop-loss, 3%% Cycle MM
echo History: pre-loaded for instant trading
echo.
echo Address: http://127.0.0.1:8765
echo Press Ctrl+C to stop
echo.
echo IMPORTANT:
echo  1. Chrome with EdgeBot extension must be open
echo  2. Go to https://pocketoption.com (DEMO)
echo  3. Add pairs to FAVORITES
echo  4. Bot loads history from backtest/ and starts immediately
echo.

cd /d "%~dp0engine"
call venv\Scripts\activate.bat
python main.py

pause