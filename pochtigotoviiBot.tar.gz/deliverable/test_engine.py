import sys
import os
import json
import pandas as pd
import numpy as np
import unittest
from datetime import datetime

# Add the engine directory to the path
sys.path.append(os.path.join(os.path.dirname(__file__), 'engine'))

from strategy import Strategy
from risk_manager import RiskManager
from logger import setup_logger, TradeLogger

class TestEngine(unittest.TestCase):
    def setUp(self):
        self.config = {
            "initial_balance": 1000.0,
            "stake_pct": 0.01,
            "loss_multiplier": 1.22,
            "win_multiplier": 0.9,
            "daily_stop_loss": 0.10,
            "max_concurrent": 3
        }
        self.strategy = Strategy()
        self.risk_manager = RiskManager(self.config)

    def test_strategy_analysis(self):
        # Generate 1000 random M5 candles
        np.random.seed(42)
        close_prices = 1.1000 + np.cumsum(np.random.randn(1000) * 0.0001)
        high_prices = close_prices + np.random.rand(1000) * 0.0005
        low_prices = close_prices - np.random.rand(1000) * 0.0005
        open_prices = np.roll(close_prices, 1)
        open_prices[0] = 1.1000

        df = pd.DataFrame({
            'timestamp': range(1000),
            'open': open_prices,
            'high': high_prices,
            'low': low_prices,
            'close': close_prices,
            'volume': np.random.randint(100, 1000, 1000)
        })

        # Run analysis
        action, reason = self.strategy.analyze(df)
        print(f"Strategy analysis result: {action} ({reason})")
        self.assertIn(action, ["buy", "sell", "wait"])

    def test_risk_manager(self):
        # Initial stake should be 1% of 1000 = 10
        self.assertEqual(self.risk_manager.get_stake(), 10.0)

        # Test loss
        self.risk_manager.on_trade_result("loss")
        self.assertEqual(self.risk_manager.get_stake(), 12.2)

        # Test win
        self.risk_manager.on_trade_result("win")
        # 12.2 * 0.9 = 10.98
        self.assertEqual(self.risk_manager.get_stake(), 10.98)

        # Test clamp (should not go below 1% of balance)
        self.risk_manager.balance = 1000.0
        self.risk_manager.current_stake = 5.0
        self.assertEqual(self.risk_manager.get_stake(), 10.0)

        # Test stop-loss
        self.risk_manager.balance = 850.0 # 15% loss
        self.assertTrue(self.risk_manager.is_stop_loss_hit())
        self.assertFalse(self.risk_manager.can_trade())

    def test_logging(self):
        log_dir = "/home/team/shared/logs"
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
        
        logger = setup_logger("TestLogger", os.path.join(log_dir, "test.log"))
        logger.info("Test message")
        self.assertTrue(os.path.exists(os.path.join(log_dir, "test.log")))

        trade_logger = TradeLogger()
        trade_logger.log_trade("EURUSD", "BUY", 10.0, 5, "Test reason", 1000.0)
        # Check if csv exists
        self.assertTrue(os.path.exists("/home/team/shared/logs/trades.csv"))

if __name__ == "__main__":
    unittest.main()
