@echo off
title EdgeBot Systems v1.0
color 0A

echo ============================================
echo   EdgeBot Systems v1.0 - START
echo ============================================
echo.

set "SCRIPT_DIR=%~dp0"

if not exist "%SCRIPT_DIR%engine\venv\" (
    echo [ERROR] Virtual environment not found!
    echo Run install.bat first.
    pause
    exit /b 1
)

echo Starting Python Engine...
echo Address: http://127.0.0.1:8765
echo Press Ctrl+C to stop
echo.
echo IMPORTANT:
echo  1. Chrome with EdgeBot extension must be open
echo  2. Go to https://pocketoption.com
echo  3. Switch to DEMO account
echo.

cd /d "%SCRIPT_DIR%engine"
call venv\Scripts\activate.bat
python main.py

pause