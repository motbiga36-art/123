import logging
import os
import csv
from datetime import datetime

def setup_logger(name, log_file, level=logging.INFO):
    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    
    handler = logging.FileHandler(log_file)
    handler.setFormatter(formatter)
    
    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.addHandler(handler)
    
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    return logger

class TradeLogger:
    def __init__(self, csv_path="/home/team/shared/logs/trades.csv"):
        self.csv_path = csv_path
        self.headers = ["timestamp", "asset", "type", "stake", "expiry", "reason", "result", "balance"]
        self._init_csv()

    def _init_csv(self):
        if not os.path.exists(self.csv_path):
            with open(self.csv_path, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(self.headers)

    def log_trade(self, asset, trade_type, stake, expiry, reason, balance):
        with open(self.csv_path, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                datetime.now().isoformat(),
                asset,
                trade_type,
                stake,
                expiry,
                reason,
                "PENDING",
                balance
            ])

    def update_last_trade(self, result, final_balance):
        # Very simple update logic: read all, update last pending, write back
        # In a real high-frequency system this would be different
        rows = []
        with open(self.csv_path, 'r') as f:
            reader = csv.reader(f)
            rows = list(reader)
        
        if len(rows) > 1:
            for i in range(len(rows)-1, 0, -1):
                if rows[i][6] == "PENDING":
                    rows[i][6] = result
                    rows[i][7] = final_balance
                    break
        
        with open(self.csv_path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerows(rows)
            
    def generate_daily_report(self, report_path="/home/team/shared/reports/"):
        os.makedirs(report_path, exist_ok=True)
        today = datetime.now().strftime("%Y-%m-%d")
        report_file = os.path.join(report_path, f"report_{today}.txt")
        
        rows = []
        with open(self.csv_path, 'r') as f:
            reader = csv.reader(f)
            rows = list(reader)
        
        if len(rows) <= 1:
            return
            
        today_trades = [r for r in rows[1:] if r[0].startswith(today)]
        wins = len([t for t in today_trades if t[6] == "win"])
        losses = len([t for t in today_trades if t[6] == "loss"])
        total = wins + losses
        winrate = (wins / total * 100) if total > 0 else 0
        
        with open(report_file, 'w') as f:
            f.write(f"Daily Report: {today}\n")
            f.write(f"Total Trades: {total}\n")
            f.write(f"Wins: {wins}\n")
            f.write(f"Losses: {losses}\n")
            f.write(f"Winrate: {winrate:.2f}%\n")
            f.write("-" * 20 + "\n")
