import logging
import json

logger = logging.getLogger("TradingEngine.RiskManager")

class RiskManager:
    def __init__(self, config=None):
        if config is None:
            config = {}
        self.start_balance = config.get("initial_balance", 50000.0)
        self.balance = self.start_balance
        self.base_stake_pct = config.get("stake_pct", 0.01)
        self.loss_multiplier = config.get("loss_multiplier", 1.22)
        self.win_multiplier = config.get("win_multiplier", 0.9)
        
        # 3% Cycle MM System
        self.current_stake = self.balance * self.base_stake_pct
        self.daily_stop_loss_pct = config.get("daily_stop_loss", 0.50)  # -50%
        self.max_concurrent_trades = 1  # FIXED: 1 trade at a time
        self.active_trades = 0
        self.daily_cycle_profit = 0.0
        self.day_start_balance = self.balance
        self.consecutive_losses = 0
        self.total_signals_today = 0
        self.max_signals_per_day = 150

    def get_stake(self):
        """Return current stake, clamped to minimum 1% of balance"""
        min_stake = self.balance * self.base_stake_pct
        if self.current_stake < min_stake:
            self.current_stake = min_stake
        return round(self.current_stake, 2)

    def update_balance(self, new_balance):
        self.balance = new_balance

    def on_trade_result(self, result_type):
        """
        result_type: 'win' or 'loss'
        3% Cycle MM System:
        - WIN  → ×0.90
        - LOSS → ×1.22
        - When daily profit >= +3% → reset stake to 1% of balance
        """
        if result_type == "win":
            self.current_stake *= self.win_multiplier
            self.consecutive_losses = 0  # Reset consecutive losses
            logger.info(f"WIN! New stake: {self.current_stake:.2f}")
        elif result_type == "loss":
            self.current_stake *= self.loss_multiplier
            self.consecutive_losses += 1
            logger.info(f"LOSS. New stake: {self.current_stake:.2f} (consecutive: {self.consecutive_losses})")

        # Clamp to minimum 1%
        min_stake = self.balance * self.base_stake_pct
        if self.current_stake < min_stake:
            self.current_stake = min_stake

        # Safety cap: don't risk more than 50% of balance
        max_stake = self.balance * 0.5
        if self.current_stake > max_stake:
            logger.warning(f"Stake {self.current_stake:.2f} exceeds 50% cap. Resetting.")
            self.current_stake = min_stake

        # 3% Cycle Reset: check daily profit
        total_day_profit = self.balance - self.day_start_balance
        cycle_target = self.day_start_balance * 0.03
        if total_day_profit >= cycle_target:
            old_stake = self.current_stake
            self.current_stake = max(self.balance * self.base_stake_pct, 1.0)
            self.daily_cycle_profit = 0.0
            logger.info(f"3% cycle target reached! Stake reset: {old_stake:.2f} -> {self.current_stake:.2f}")

    def can_trade(self):
        # Max 1 concurrent trade
        if self.active_trades >= self.max_concurrent_trades:
            return False
        # Daily stop loss -50%
        if self.is_stop_loss_hit():
            logger.warning("Daily stop-loss (-50%) hit. Trading suspended.")
            return False
        # Max daily signals
        if self.total_signals_today >= self.max_signals_per_day:
            logger.warning(f"Max daily signals ({self.max_signals_per_day}) reached.")
            return False
        return True

    def is_stop_loss_hit(self):
        """Emergency stop at -50% of starting daily balance"""
        drawdown = (self.day_start_balance - self.balance) / self.day_start_balance
        return drawdown >= self.daily_stop_loss_pct

    def increment_trades(self):
        self.active_trades += 1
        self.total_signals_today += 1

    def decrement_trades(self):
        self.active_trades = max(0, self.active_trades - 1)

    def new_trading_day(self):
        """Call at start of each trading day"""
        self.day_start_balance = self.balance
        self.current_stake = max(self.balance * self.base_stake_pct, 1.0)
        self.daily_cycle_profit = 0.0
        self.total_signals_today = 0
        self.consecutive_losses = 0
        logger.info(f"New trading day. Balance: ${self.balance:.2f}, Stake: ${self.current_stake:.2f}")