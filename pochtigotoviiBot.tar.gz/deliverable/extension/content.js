const ENGINE_URL = "http://127.0.0.1:8765";
console.log("EdgeBot: v9 - reads favorites from Pocket Option");

let candleBuffer = {};
let currentAsset = "";
let favoritesList = [];
let assetCycleIndex = 0;
let lastSwitchTime = 0;
let isExecutingTrade = false;

// ── SELECTORS ──
const SELECTORS = {
    balance: ".balance-value, .user-balance, .balance-info__value, .balance, [class*=balance]",
    price: ".current-price, .price, .val.value",
    assetLabel: ".current-symbol, [class*=symbol], [class*=pair]",
    assetTrigger: ".current-symbol, [class*=symbol], .assets-block__current, [class*=asset-select]",
    favoritesList: ".alist-favorites",
    favoriteAsset: ".alist-favorites .alist__label",
    assetSearch: "input[placeholder*=search], input[placeholder*=поиск], .asset-search input",
    assetItems: ".alist__item .alist__label",
    amountInput: ".block--bet-amount input, .value__val input",
};

// ── HELPERS ──
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function getBalance() {
    let el = document.querySelector(SELECTORS.balance);
    if (el) {
        let t = (el.innerText || el.textContent || "").replace(/[^0-9.]/g, "");
        if (t && parseFloat(t) > 0) return t;
    }
    return "0";
}

function getPrice() {
    let el = document.querySelector(SELECTORS.price);
    if (el) {
        let p = parseFloat(el.innerText.replace(/[^0-9.]/g, ""));
        if (!isNaN(p) && p > 0) return p;
    }
    return 0;
}

function getAsset() {
    let el = document.querySelector(SELECTORS.assetLabel);
    return el ? (el.innerText || "").replace(/[^A-Za-z\/]/g, "") : "unknown";
}

function updateCandles(asset, price) {
    if (!candleBuffer[asset]) candleBuffer[asset] = [];
    const now = Date.now();
    const timeframe = 60 * 1000; // M1
    const candleTime = Math.floor(now / timeframe) * timeframe;
    const buf = candleBuffer[asset];

    if (buf.length === 0 || buf[buf.length - 1].t !== candleTime) {
        buf.push({ t: candleTime, o: price, h: price, l: price, c: price, v: 1 });
        if (buf.length > 500) buf.shift();
    } else {
        let c = buf[buf.length - 1];
        c.h = Math.max(c.h, price);
        c.l = Math.min(c.l, price);
        c.c = price;
        c.v = (c.v || 0) + 1;
    }
}

function readFavorites() {
    // Try to read favorites from the DOM
    try {
        let labels = document.querySelectorAll(SELECTORS.favoriteAsset);
        if (labels && labels.length > 0) {
            let assets = [];
            labels.forEach(el => {
                let name = (el.innerText || el.textContent || "").replace(/[^A-Za-z\/]/g, "");
                if (name && name.includes('/')) assets.push(name);
            });
            if (assets.length > 0) {
                favoritesList = assets;
                console.log(`EdgeBot: Favorites loaded: ${favoritesList.join(', ')}`);
                return true;
            }
        }
    } catch(e) {}
    return false;
}

async function openAssetDropdown() {
    let trigger = document.querySelector(SELECTORS.assetTrigger);
    if (trigger) {
        trigger.click();
        await sleep(600);
        return true;
    }
    return false;
}

async function closeAssetDropdown() {
    // Click outside to close
    let wrap = document.querySelector(".drop-down-modal-wrap, .assets-block__col-nav");
    if (wrap) {
        wrap.click();
        await sleep(300);
    }
}

async function switchToAsset(targetAsset) {
    if (!targetAsset || targetAsset === currentAsset || isExecutingTrade) return;
    console.log(`EdgeBot: Switching to ${targetAsset}...`);

    let opened = await openAssetDropdown();
    if (!opened) return;

    // Try to find the asset in the favorites list or all list
    let items = document.querySelectorAll(SELECTORS.assetItems);
    let found = false;
    
    for (let item of items) {
        try {
            let text = (item.innerText || item.textContent || "").replace(/[^A-Za-z\/]/g, "");
            if (text.toUpperCase() === targetAsset.toUpperCase()) {
                item.click();
                await sleep(800);
                currentAsset = targetAsset;
                console.log(`EdgeBot: Switched to ${targetAsset}`);
                found = true;
                break;
            }
        } catch(e) {}
    }

    if (!found) {
        // Try search
        let search = document.querySelector(SELECTORS.assetSearch);
        if (search) {
            search.value = "";
            await sleep(200);
            for (let ch of targetAsset) {
                search.value += ch;
                search.dispatchEvent(new Event('input', { bubbles: true }));
                await sleep(50);
            }
            await sleep(500);
            // Click result
            items = document.querySelectorAll(SELECTORS.assetItems);
            for (let item of items) {
                let text = (item.innerText || "").replace(/[^A-Za-z\/]/g, "");
                if (text.toUpperCase() === targetAsset.toUpperCase()) {
                    item.click();
                    await sleep(800);
                    currentAsset = targetAsset;
                    console.log(`EdgeBot: Switched to ${targetAsset} via search`);
                    found = true;
                    break;
                }
            }
        }
    }

    if (!found) {
        // Close dropdown
        await closeAssetDropdown();
        console.log(`EdgeBot: Could not find ${targetAsset}`);
    }
}

function nativeSetValue(input, value) {
    if (!input) return;
    let nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    nativeSetter.call(input, value.toFixed(2));
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    input.blur();
}

async function executeTrade(trade) {
    if (isExecutingTrade) return;
    isExecutingTrade = true;
    console.log("EdgeBot: EXECUTING TRADE", trade);

    // Set amount
    let inp = document.querySelector(SELECTORS.amountInput);
    if (inp && trade.stake) {
        inp.click();
        await sleep(300);
        nativeSetValue(inp, trade.stake);
    }

    // Click trade button
    await sleep(500);
    let btn = document.querySelector(trade.action === "buy" ? ".btn-call" : ".btn-put");
    if (btn) {
        btn.click();
        console.log("EdgeBot: TRADE EXECUTED!");
        let expiryMs = (trade.expiry || 60) * 1000 + 2000;
        setTimeout(async () => {
            let bal = getBalance();
            await fetch(`${ENGINE_URL}/trade_result`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ type: trade.action, status: "completed", result: "pending", balance: bal })
            });
            isExecutingTrade = false;
        }, expiryMs);
    } else {
        console.error("EdgeBot: Trade button not found");
        isExecutingTrade = false;
    }
}

async function syncWithEngine() {
    const balance = getBalance();
    const asset = getAsset();
    const price = getPrice();

    // Update candles
    if (price > 0) updateCandles(asset, price);

    // Read favorites from DOM (done on every cycle to pick up changes)
    readFavorites();

    // If no favorites, use current asset only
    let targets = favoritesList.length > 0 ? favoritesList : [asset];
    
    // Cycle through assets
    if (assetCycleIndex >= targets.length) assetCycleIndex = 0;
    let targetAsset = targets[assetCycleIndex];

    // Switch if needed
    if (targetAsset !== asset && !isExecutingTrade) {
        await switchToAsset(targetAsset);
        return; // Wait for next cycle to send data
    }

    const payload = {
        balance: balance,
        asset: asset,
        candles: candleBuffer[asset] || [],
        timestamp: new Date().toISOString()
    };

    try {
        const response = await fetch(`${ENGINE_URL}/data`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });
        const result = await response.json();

        if (result.action && result.action !== "wait") {
            if (!isExecutingTrade) {
                executeTrade(result);
            }
        } else if (result.switch_target) {
            await switchToAsset(result.switch_target);
            if (result.switch_target !== asset) {
                assetCycleIndex = (assetCycleIndex + 1) % targets.length;
            }
        } else {
            // No signal, move to next asset
            await sleep(200);
            if (!isExecutingTrade) {
                assetCycleIndex = (assetCycleIndex + 1) % targets.length;
            }
        }
    } catch (e) {}
}

// ── START ──
setTimeout(async () => {
    console.log("EdgeBot: Starting with favorites reading...");
    // First try to load favorites
    await sleep(2000);
    let got = readFavorites();
    if (got) {
        console.log(`EdgeBot: Will trade ${favoritesList.length} assets from favorites`);
    } else {
        console.log("EdgeBot: No favorites found. Add assets to favorites on Pocket Option!");
    }
    setInterval(syncWithEngine, 4000);
}, 3000);