chrome.runtime.onInstalled.addListener(() => {
  console.log("EdgeBot Extension installed");
});
