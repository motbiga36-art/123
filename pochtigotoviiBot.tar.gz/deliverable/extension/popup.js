const ENGINE_URL = "http://127.0.0.1:8765";

let logHistory = [];

function addLog(msg, type="info") {
    const ts = new Date().toLocaleTimeString();
    logHistory.unshift(`[${ts}] ${msg}`);
    if (logHistory.length > 20) logHistory.pop();
    const container = document.getElementById('log-container');
    if (container) {
        container.innerHTML = logHistory.map(m => `<div class="log-entry">${m}</div>`).join('');
    }
}

async function fetchStatus() {
    try {
        const response = await fetch(`${ENGINE_URL}/status`);
        const data = await response.json();
        updateUI(data);
    } catch (error) {
        document.getElementById('engine-status').innerHTML = '<span class="status-dot off"></span> Disconnected';
        addLog('Engine disconnected', 'error');
    }
}

function updateUI(data) {
    // Engine status
    const statusEl = document.getElementById('engine-status');
    if (data.night_mode) {
        statusEl.innerHTML = '<span class="status-dot wait"></span> Night Mode';
    } else if (data.can_trade === false) {
        statusEl.innerHTML = '<span class="status-dot wait"></span> Stopped (limit)';
    } else {
        statusEl.innerHTML = '<span class="status-dot on"></span> Active';
    }

    // Balance
    const bal = Number(data.balance).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});
    document.getElementById('balance').textContent = '$' + bal;
    document.getElementById('stake').textContent = '$' + Number(data.stake).toFixed(2);
    document.getElementById('signals').textContent = data.total_signals || 0;

    // Can trade
    const tradeEl = document.getElementById('can-trade');
    if (data.can_trade) {
        tradeEl.innerHTML = '<span class="status-dot on"></span> Yes';
        tradeEl.className = 'value green';
    } else {
        tradeEl.innerHTML = '<span class="status-dot off"></span> No';
        tradeEl.className = 'value red';
    }
}

async function setBalance() {
    const input = document.getElementById('balance-input');
    const val = input.value.trim().replace(/[^0-9.]/g, '');
    if (!val || parseFloat(val) <= 0) {
        addLog('Enter a valid balance amount', 'error');
        return;
    }
    try {
        const response = await fetch(`${ENGINE_URL}/set_balance`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ balance: parseFloat(val) })
        });
        const result = await response.json();
        if (result.status === "ok") {
            addLog(`Balance set to $${result.balance}`);
            fetchStatus();
        } else {
            addLog(`Error: ${result.message}`, 'error');
        }
    } catch (e) {
        addLog('Engine not available', 'error');
    }
}

// Set balance on Enter key
document.addEventListener('DOMContentLoaded', () => {
    const input = document.getElementById('balance-input');
    const btn = document.getElementById('set-balance-btn');
    const refreshBtn = document.getElementById('refresh-btn');

    if (btn) btn.addEventListener('click', setBalance);
    if (input) {
        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') setBalance();
        });
    }
    if (refreshBtn) {
        refreshBtn.addEventListener('click', fetchStatus);
    }

    addLog('Popup opened, connecting to engine...');
    fetchStatus();
});

// Auto-refresh every 5 seconds
setInterval(fetchStatus, 5000);