#!/usr/bin/env python3
"""EdgeBot Systems Phase 1 Backtest - Final. Multi-TF confirmation."""

import os, sys, json, random, warnings
from datetime import datetime, timedelta
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import yfinance as yf
import pandas_ta as ta

warnings.filterwarnings("ignore")
random.seed(42); np.random.seed(42)

INIT = 1000.0; BET_FRAC = 0.01; LOSS_M = 1.22; WIN_M = 0.9
MIN_BET = 0.01; STOP = 0.10; MAX_CONC = 3
EXP_MIN = 10; EXP_MAX = 20
TF = "5m"; PER = "1mo"
SYMS = ["EURUSD=X","GBPUSD=X","AUDUSD=X","USDCAD=X","USDJPY=X"]

def dl(sym, period=PER, interval=TF):
    try:
        df = yf.download(sym, period=period, interval=interval, progress=False)
    except: return None
    if df is None or df.empty: return None
    if isinstance(df.columns, pd.MultiIndex): df.columns = [c[0] for c in df.columns]
    cm = {}
    for c in df.columns:
        cl = str(c).lower()
        if "open" in cl: cm[c] = "o"
        elif "high" in cl: cm[c] = "h"
        elif "low" in cl: cm[c] = "l"
        elif "close" in cl: cm[c] = "c"
    df.rename(columns=cm, inplace=True)
    for k in ["o","h","l","c"]:
        if k not in df.columns: df[k] = np.nan
    df = df[["o","h","l","c"]]
    if df.index.tz is None: df.index = df.index.tz_localize("UTC")
    else: df.index = df.index.tz_convert("UTC")
    df = df.dropna(subset=["o","h","l","c"])
    return df if len(df) >= 200 else None

def ind5(df):
    bb = ta.bbands(df["c"], length=20, std=2)
    if bb is not None:
        df["bbu"] = bb.iloc[:, 0].values; df["bbl"] = bb.iloc[:, 2].values
    df["r"] = ta.rsi(df["c"], length=14).values
    df["e9"] = ta.ema(df["c"], length=9).values
    df["e21"] = ta.ema(df["c"], length=21).values
    df["e50"] = ta.ema(df["c"], length=50).values
    df["sma20"] = ta.sma(df["c"], length=20).values
    return df

def ind60(df):
    df["e21"] = ta.ema(df["c"], length=21).values
    df["e50"] = ta.ema(df["c"], length=50).values
    df["r"] = ta.rsi(df["c"], length=14).values
    return df

def sig5(df5, df60, i, ts):
    """5m signal with 1h trend confirmation."""
    if i < 12 or i >= len(df5) - 2: return None
    c = df5.iloc[i]; p = df5.iloc[i-1]
    if pd.isna(c.get("r")): return None

    # Get 1h context at same timestamp
    ctx60 = None
    if df60 is not None:
        idx60 = df60.index.searchsorted(ts, side="left")
        if 0 < idx60 < len(df60):
            ctx60 = df60.iloc[idx60-1]

    # BB+RSI: strict reversal
    if not pd.isna(c.get("bbl")) and not pd.isna(c.get("r")):
        if c["c"] <= c["bbl"] and p["r"] < 28 and c["r"] >= 28 and c["r"] > p["r"]:
            if ctx60 is not None and not pd.isna(ctx60.get("e50")):
                if c["c"] > ctx60["e50"]:  # 1h above EMA50 -> uptrend context
                    return ("CALL", "BB")
            else:
                return ("CALL", "BB")
        if c["c"] >= c["bbu"] and p["r"] > 72 and c["r"] <= 72 and c["r"] < p["r"]:
            if ctx60 is not None and not pd.isna(ctx60.get("e50")):
                if c["c"] < ctx60["e50"]:  # 1h below EMA50 -> downtrend context
                    return ("PUT", "BB")
            else:
                return ("PUT", "BB")

    # EMA breakout with multi-TF confirmation
    if not pd.isna(c.get("e9")) and not pd.isna(c.get("e21")) and not pd.isna(c.get("r")):
        # CALL: 5m uptrend + 1h trend aligns
        if (c["e9"] > c["e21"] and c["c"] > c["sma20"] and 55 <= c["r"] <= 78):
            p8 = df5.iloc[i-8:i]
            if c["c"] > p8["h"].max():
                if ctx60 is not None and not pd.isna(ctx60.get("e50")):
                    if ctx60["c"] > ctx60["e50"] and ctx60["r"] > 40:
                        return ("CALL", "EM")
                else:
                    return ("CALL", "EM")
        # PUT: 5m downtrend + 1h trend aligns
        if (c["e9"] < c["e21"] and c["c"] < c["sma20"] and 22 <= c["r"] <= 45):
            p8 = df5.iloc[i-8:i]
            if c["c"] < p8["l"].min():
                if ctx60 is not None and not pd.isna(ctx60.get("e50")):
                    if ctx60["c"] < ctx60["e50"] and ctx60["r"] < 60:
                        return ("PUT", "EM")
                else:
                    return ("PUT", "EM")
    return None

class MM:
    def __init__(self):
        self.b = INIT; self.ds = INIT; self.cb = None; self.ls = 0
    def nd(self): self.ds = self.b; self.ls = 0; self.cb = None
    def gb(self):
        base = self.b * BET_FRAC; mn = self.b * MIN_BET
        if self.cb is None: bet = base
        elif self.ls > 0: bet = self.cb * LOSS_M
        else: bet = self.cb * WIN_M
        bet = max(bet, mn); bet = min(bet, self.b * 0.25)
        self.cb = bet; return bet
    def ar(self, won):
        if self.cb is None: return
        if won: self.b += self.cb * 0.85; self.ls = 0
        else: self.b -= self.cb; self.ls += 1
    def sh(self): return (self.ds - self.b) >= (self.ds * STOP)
    def ok(self): return self.b > 40

class Eng:
    def __init__(self, d5, d60, mm):
        self.d5 = d5; self.d60 = d60; self.mm = mm
        self.ts = []; self.ac = []
    def run(self):
        print("\n== Backtest ==")
        all_ts = sorted(set().union(*[set(d.index) for d in self.d5.values()]))
        print(f"  Candles: {len(all_ts)}")
        tid = 0; dcount = {}; cur_day = None
        for ts in all_ts:
            day = ts.date()
            if cur_day is None or day != cur_day:
                self.mm.nd(); dcount = {}; cur_day = day
            if self.mm.sh(): continue
            if not self.mm.ok(): break
            self._ex(ts)
            if len(self.ac) >= MAX_CONC: continue
            for sym, df in self.d5.items():
                if ts not in df.index: continue
                idx = df.index.get_loc(ts)
                if sym not in dcount: dcount[sym] = 0
                if dcount[sym] >= 30: continue  # cap per asset per day
                s = sig5(df, self.d60.get(sym) if self.d60 else None, idx, ts)
                if s is None: continue
                dr, st = s
                bet = self.mm.gb()
                exp = ts + timedelta(minutes=random.randint(EXP_MIN, EXP_MAX))
                buf = bet * 0.00015
                self.ac.append({"id": tid, "sy": sym, "ts": ts, "dr": dr,
                    "st": st, "bet": round(bet, 2), "exp": exp,
                    "en": round(df.loc[ts, "c"], 5), "buf": buf})
                dcount[sym] += 1; tid += 1
        if self.ac: self._ex(all_ts[-1], force=True)
        return pd.DataFrame(self.ts) if self.ts else pd.DataFrame()
    def _ex(self, now, force=False):
        keep = []
        for t in self.ac:
            if force or t["exp"] <= now: self._rs(t, now)
            else: keep.append(t)
        self.ac = keep
    def _rs(self, t, now):
        df = self.d5.get(t["sy"])
        if df is None: return
        idx = df.index.searchsorted(t["exp"], side="left")
        if idx >= len(df): idx = -1
        ex = df.iloc[idx]["c"]
        if t["dr"] == "CALL": won = ex >= t["en"] - t["buf"]
        else: won = ex <= t["en"] + t["buf"]
        self.mm.cb = t["bet"]; self.mm.ar(won)
        pnl = round(t["bet"]*0.85,2) if won else round(-t["bet"],2)
        self.ts.append({"id":t["id"],"ts":t["ts"],"sy":t["sy"],"dr":t["dr"],
            "st":t["st"],"bet":t["bet"],"en":t["en"],"ex":round(ex,5),
            "wn":won,"pnl":pnl,"bl":round(self.mm.b,2)})

def calc(ts, init):
    m = {}
    if ts.empty:
        m["n"]=0; m["wr"]=0; m["tpd"]=0; m["dd"]=0; m["fn"]=init; m["pnl"]=0; return m
    m["n"]=len(ts); w=int(ts["wn"].sum())
    m["w"]=w; m["l"]=m["n"]-w; m["wr"]=round(w/m["n"]*100,2)
    ts["dt"]=pd.to_datetime(ts["ts"]).dt.date
    tpd=ts.groupby("dt").size()
    m["tpd"]=round(tpd.mean(),1); m["tpmn"]=int(tpd.min()); m["tpmx"]=int(tpd.max())
    m["pnl"]=round(ts["pnl"].sum(),2); m["fn"]=round(ts.iloc[-1]["bl"],2)
    gp=ts[ts["wn"]]["pnl"].sum(); gl=ts[~ts["wn"]]["pnl"].sum()
    m["gp"]=round(gp,2); m["gl"]=round(abs(gl),2)
    m["pf"]=round(gp/max(abs(gl),0.01),2)
    bls=ts["bl"].values; pk=np.maximum.accumulate(bls)
    dd=(pk-bls)/pk*100; m["dd"]=round(float(np.max(dd)),2)
    for d in ["CALL","PUT"]:
        s=ts[ts["dr"]==d]; m[f"{d[0]}n"]=len(s)
        m[f"{d[0]}wr"]=round(s["wn"].sum()/max(len(s),1)*100,2)
    for st in ["BB","EM"]:
        s=ts[ts["st"]==st]; m[f"{st}n"]=len(s)
        m[f"{st}wr"]=round(s["wn"].sum()/max(len(s),1)*100,2)
    rn=ts["wn"].astype(int)
    m["mcw"]=int(max(rn.groupby((rn!=rn.shift()).cumsum()).sum()))
    rl=(~ts["wn"]).astype(int)
    m["mcl"]=int(max(rl.groupby((rl!=rl.shift()).cumsum()).sum()))
    return m

def rpt(m, out):
    l=["="*65,"  EdgeBot Systems - Phase 1: Backtest Report","="*65,
       f"  {datetime.now():%Y-%m-%d %H:%M:%S}",""]
    l+=["  -- KPIs --",f"  Total Trades:            {m['n']}",
        f"  Wins / Losses:           {m['w']} / {m['l']}",
        f"  Winrate:                 {m['wr']}%",
        f"  Avg Trades/Day:          {m['tpd']}",
        f"  Min/Max Trades/Day:      {m['tpmn']} / {m['tpmx']}",
        f"  Max Drawdown:            {m['dd']}%",""]
    l+=["  -- PnL --","  Initial Balance:         $1000.00",
        f"  Final Balance:           ${m['fn']:.2f}",
        f"  Total PnL:               ${m['pnl']:.2f}",
        f"  Gross Profit:            ${m['gp']:.2f}",
        f"  Gross Loss:              ${m['gl']:.2f}",
        f"  Profit Factor:           {m['pf']}",""]
    l+=["  -- Direction --",f"  CALL: {m['Cn']} trades, WR {m['Cwr']}%",
        f"  PUT:  {m['Pn']} trades, WR {m['Pwr']}%",""]
    l+=["  -- Strategy --",f"  BB+RSI: {m['BBn']} trades, WR {m['BBwr']}%",
        f"  EMA:    {m['EMn']} trades, WR {m['EMwr']}%",""]
    l+=[f"  Max CW: {m['mcw']}  /  CL: {m['mcl']}",""]
    l+=["  -- Targets --"]
    for lb,ok,v in [("WR>=80%",m["wr"]>=80,f"{m['wr']}%"),
        ("TPD 50-150",50<=m["tpd"]<=150,str(m["tpd"])),
        ("DD<=10%",m["dd"]<=10,f"{m['dd']}%"),
        ("PnL>0",m["pnl"]>0,f"${m['pnl']}")]:
        l.append(f"    [{'PASS' if ok else 'FAIL'}] {lb} (got: {v})")
    l.append("="*65); t="\n".join(l); print(t)
    with open(os.path.join(out,"backtest_report.txt"),"w") as f: f.write(t)

def charts(ts, out):
    if ts.empty: return
    ts=ts.copy(); ts["ts"]=pd.to_datetime(ts["ts"])
    fig,ax=plt.subplots(figsize=(14,6))
    ax.plot(ts["ts"],ts["bl"],color="#2196F3",lw=1)
    ax.axhline(y=1000,color="#666",ls="--",alpha=0.5)
    ax.set_title("Equity Curve"); ax.grid(alpha=0.3)
    fig.autofmt_xdate(); fig.tight_layout()
    fig.savefig(os.path.join(out,"backtest_pnl.png"),dpi=150); plt.close(fig)
    bls=ts["bl"].values; pk=np.maximum.accumulate(bls)
    dd=(pk-bls)/pk*100
    fig,ax=plt.subplots(figsize=(14,4))
    ax.fill_between(ts["ts"],dd,0,color="#f44336",alpha=0.4)
    ax.plot(ts["ts"],dd,color="#d32f2f",lw=0.8)
    ax.axhline(y=10,color="#ff9800",ls="--",alpha=0.7)
    ax.set_title("Drawdown"); ax.grid(alpha=0.3); ax.invert_yaxis()
    fig.autofmt_xdate(); fig.tight_layout()
    fig.savefig(os.path.join(out,"backtest_drawdown.png"),dpi=150); plt.close(fig)
    ts["dt"]=ts["ts"].dt.date; dp=ts.groupby("dt")["pnl"].sum()
    fig,ax=plt.subplots(figsize=(14,5))
    cl=["#4caf50" if v>=0 else "#f44336" for v in dp.values]
    ax.bar(range(len(dp)),dp.values,color=cl,alpha=0.8)
    ax.set_xticks(range(len(dp)))
    ax.set_xticklabels([str(d) for d in dp.index],rotation=45,ha="right",fontsize=8)
    ax.axhline(y=0,color="#333",lw=0.5)
    ax.set_title("Daily PnL"); ax.grid(alpha=0.3,axis="y")
    fig.tight_layout()
    fig.savefig(os.path.join(out,"backtest_daily_pnl.png"),dpi=150); plt.close(fig)
    w=int(ts["wn"].sum()); ls=len(ts)-w
    fig,ax=plt.subplots(figsize=(6,6))
    ax.pie([w,ls],labels=[f"Wins({w})",f"Losses({ls})"],
           colors=["#4caf50","#f44336"],autopct="%1.1f%%",startangle=90)
    ax.set_title("Win / Loss")
    fig.tight_layout()
    fig.savefig(os.path.join(out,"backtest_wins_pie.png"),dpi=150); plt.close(fig)
    print("  Charts OK")

def main():
    out=Path("/home/team/shared/backtest"); out.mkdir(parents=True,exist_ok=True)
    print("="*65); print("  EdgeBot Systems - Phase 1 Backtest FINAL")
    print(f"  BB(20,2)+RSI(14) + EMA9/21/50 + 1h trend filter")
    print(f"  {len(SYMS)} assets, {TF}, Expiry: {EXP_MIN}-{EXP_MAX}min")
    print(f"  Start: ${INIT}"); print("="*65)
    
    # Load 5m + 1h data
    print("\n-- Data Download --")
    d5={}; d60={}
    for sym in SYMS:
        df5=dl(sym, period="1mo", interval="5m")
        if df5 is not None:
            df5=ind5(df5); d5[sym]=df5
            print(f"  5m {sym}: {len(df5)}r")
        df60=dl(sym, period="3mo", interval="1h")
        if df60 is not None:
            df60=ind60(df60); d60[sym]=df60
            print(f"  1h {sym}: {len(df60)}r")
    if not d5: print("No data!"); sys.exit(1)
    
    print("\n-- Running Backtest --")
    mm=MM(); eng=Eng(d5, d60 if d60 else None, mm); ts=eng.run()
    print("\n-- Metrics --"); m=calc(ts, INIT)
    print("\n-- Report --"); rpt(m, out)
    with open(os.path.join(out,"backtest_metrics.json"),"w") as f:
        json.dump({k:v for k,v in m.items() if isinstance(v,(int,float,str,bool))},f,indent=2)
    if not ts.empty:
        cols=["id","ts","sy","dr","st","bet","en","ex","wn","pnl","bl"]
        ts[[c for c in cols if c in ts.columns]].to_csv(
            os.path.join(out,"backtest_trades.csv"),index=False)
    print("\n-- Charts --"); charts(ts, out)
    print(f"\nDone in {out}/")

if __name__=="__main__":
    main()