import pandas as pd
import numpy as np

class SMARSIStrategy:
    """SMA(100) + RSI(8) — PUT only when overbought in uptrend"""
    
    def check(self, df):
        """
        df: DataFrame с 5-сек свечами [timestamp, open, high, low, close, volume]
        Возвращает: {"action": "sell"/"wait", "reason": "..."}
        """
        if len(df) < 110:  # нужно для SMA(100) + RSI(8)
            return {"action": "wait", "reason": f"Collecting ({len(df)}/120)"}
        
        close = df['close'].astype(float)
        
        # SMA(100)
        sma100 = close.rolling(window=100).mean()
        
        # RSI(8)
        delta = close.diff()
        gain = delta.where(delta > 0, 0.0)
        loss = (-delta).where(delta < 0, 0.0)
        avg_gain = gain.rolling(window=8, min_periods=8).mean()
        avg_loss = loss.rolling(window=8, min_periods=8).mean()
        for i in range(8, len(avg_gain)):
            avg_gain.iloc[i] = (avg_gain.iloc[i-1] * 7 + gain.iloc[i]) / 8
            avg_loss.iloc[i] = (avg_loss.iloc[i-1] * 7 + loss.iloc[i]) / 8
        rs = avg_gain / avg_loss.replace(0, np.nan)
        rsi8 = 100 - (100 / (1 + rs))
        
        curr_close = close.iloc[-1]
        curr_sma = sma100.iloc[-1]
        curr_rsi = rsi8.iloc[-1]
        
        if pd.isna(curr_sma) or pd.isna(curr_rsi):
            return {"action": "wait", "reason": "NaN indicators"}
        
        # Проверка 1: Цена выше SMA(100) — восходящий тренд
        if curr_close <= curr_sma:
            return {"action": "wait", "reason": "Price below SMA(100)"}
        
        # Проверка 2: Цена не касалась SMA(100) последние 24 свечи (2 мин при 5-сек)
        touch_count = 0
        for i in range(1, 25):
            idx = -i - 1
            if idx >= -len(df):
                if abs(close.iloc[idx] - sma100.iloc[idx]) / sma100.iloc[idx] < 0.0005:
                    touch_count += 1
        
        if touch_count > 0:
            return {"action": "wait", "reason": f"SMA touched ({touch_count}x)"}
        
        # Проверка 3: RSI(8) > 80 — перекупленность → сигнал PUT
        if curr_rsi > 80:
            return {"action": "sell", "reason": f"PUT SMA+RSI({curr_rsi:.0f})"}
        
        return {"action": "wait", "reason": f"RSI {curr_rsi:.0f} < 80"}