import uvicorn, random, os, logging, time, json
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd
from strategy_test import SMARSIStrategy

log_dir = os.path.dirname(__file__) + "/logs"
os.makedirs(log_dir, exist_ok=True)

logger = logging.getLogger()
logger.addHandler(logging.FileHandler(log_dir + "/test.log"))
logger.addHandler(logging.StreamHandler())
logger.setLevel(logging.INFO)

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

strategy = SMARSIStrategy()

# MM состояние
prev_bal = 0
current_stake = 10.0
trade_active = False
trade_bal = 0
trade_time = 0
cycle_start_bal = 0
count = 0

EXPIRY_SEC = 70  # ждём 70 сек после сделки

@app.get("/")
async def root():
    return {"status": "TEST", "balance": prev_bal, "stake": round(current_stake, 2), "trades": count}

@app.post("/data")
async def data(request: Request):
    global prev_bal, current_stake, trade_active, trade_bal, trade_time, cycle_start_bal, count
    
    d = await request.json()
    asset = d.get("asset", "?")
    
    try:
        new_bal = float(str(d.get("balance", "0")).replace("$", "").replace(",", ""))
    except:
        new_bal = 0
    
    if new_bal <= 0:
        return {"action": "wait", "stake": 0, "expiry": 1, "no_trade": True}
    
    # Первый запуск
    if prev_bal == 0:
        prev_bal = new_bal
        cycle_start_bal = new_bal
        current_stake = max(new_bal * 0.01, 1.0)
        logger.info(f"[INIT] Balance=${new_bal:.2f} Stake=${current_stake:.2f}")
    
    # Проверяем результат предыдущей сделки
    elapsed = time.time() - trade_time
    if trade_active and elapsed > EXPIRY_SEC:
        diff = new_bal - trade_bal
        if abs(diff) > 0.1:
            if diff > 0:
                current_stake *= 0.90
                logger.info(f"[WIN] ${trade_bal:.2f}->${new_bal:.2f} (${diff:+.2f}) stake=${current_stake:.2f}")
            else:
                current_stake *= 1.22
                logger.info(f"[LOSS] ${trade_bal:.2f}->${new_bal:.2f} (${diff:+.2f}) stake=${current_stake:.2f}")
            
            min_stake = new_bal * 0.01
            if current_stake < min_stake:
                current_stake = min_stake
            if current_stake > new_bal * 0.5:
                current_stake = min_stake
            
            profit_since_cycle = new_bal - cycle_start_bal
            if profit_since_cycle >= cycle_start_bal * 0.03:
                current_stake = max(new_bal * 0.01, 1.0)
                cycle_start_bal = new_bal
                logger.info(f"[+3%] Stake reset to ${current_stake:.2f}")
        
        trade_active = False
        prev_bal = new_bal
    
    if trade_active:
        return {"action": "wait", "stake": 0, "expiry": 1, "no_trade": True}
    
    # Анализируем свечи через стратегию
    candles = d.get("candles", [])
    if len(candles) < 120:
        logger.info(f"[{asset}] Collecting candles: {len(candles)}/120")
        return {"action": "wait", "stake": 0, "expiry": 1, "no_trade": True}
    
    df = pd.DataFrame(candles)
    if 't' in df.columns:
        df = df.rename(columns={'t': 'timestamp'})
    
    signal = strategy.check(df)
    logger.info(f"[{asset}] {signal['reason']}")
    
    if signal["action"] == "sell":
        count += 1
        trade_active = True
        trade_time = time.time()
        trade_bal = new_bal
        stake_to_use = round(current_stake, 2)
        logger.info(f"#{count} {asset} PUT ${stake_to_use}")
        return {"action": "sell", "stake": stake_to_use, "expiry": 1}
    
    return {"action": "wait", "stake": 0, "expiry": 1, "no_trade": True}

if __name__ == "__main__":
    print("=" * 50)
    print("  EDGEBOT — ТЕСТОВЫЙ РЕЖИМ")
    print("  SMA(100) + RSI(8) + MM")
    print("=" * 50)
    uvicorn.run(app, host="127.0.0.1", port=8765)