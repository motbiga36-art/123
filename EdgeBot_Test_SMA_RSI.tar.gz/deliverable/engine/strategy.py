import pandas as pd
import numpy as np
import logging
from datetime import datetime

logger = logging.getLogger("TradingEngine.Strategy")

class ApexPrimeUHF:
    """
    EdgeBot M1 TURBO SCALPER
    - 1-minute candles, 14 pairs, 24/7
    - 150+ trades/day target
    - EMA-3/8 + RSI(5) + ATR(7)
    - Expiry: 1 min | Min candles: 50
    """

    def __init__(self):
        self.name = "EdgeBot M1 Turbo Scalper"

        self.ALL_ASSETS = [
            "AUD/CAD", "AUD/JPY", "CAD/CHF", "CHF/JPY",
            "EUR/CAD", "EUR/GBP", "EUR/JPY",
            "GBP/AUD", "GBP/CAD", "GBP/CHF", "GBP/USD",
            "USD/CAD", "USD/JPY", "EUR/CHF",
        ]

        self.ASSET_CFG = {
            "AUD/CAD":  {"expiry": 1, "rsi_p": 5, "rsi_ob": 80, "rsi_os": 20, "min_atr": 0.0003, "max_h": 15, "min_candles": 50},
            "AUD/JPY":  {"expiry": 1, "rsi_p": 5, "rsi_ob": 80, "rsi_os": 20, "min_atr": 0.0003, "max_h": 15, "min_candles": 50},
            "CAD/CHF":  {"expiry": 1, "rsi_p": 5, "rsi_ob": 80, "rsi_os": 20, "min_atr": 0.0002, "max_h": 15, "min_candles": 50},
            "CHF/JPY":  {"expiry": 1, "rsi_p": 5, "rsi_ob": 80, "rsi_os": 20, "min_atr": 0.0002, "max_h": 15, "min_candles": 50},
            "EUR/CAD":  {"expiry": 1, "rsi_p": 5, "rsi_ob": 80, "rsi_os": 20, "min_atr": 0.0003, "max_h": 15, "min_candles": 50},
            "EUR/GBP":  {"expiry": 1, "rsi_p": 5, "rsi_ob": 80, "rsi_os": 20, "min_atr": 0.0002, "max_h": 15, "min_candles": 50},
            "EUR/JPY":  {"expiry": 1, "rsi_p": 5, "rsi_ob": 80, "rsi_os": 20, "min_atr": 0.0003, "max_h": 15, "min_candles": 50},
            "GBP/AUD":  {"expiry": 1, "rsi_p": 5, "rsi_ob": 80, "rsi_os": 20, "min_atr": 0.0005, "max_h": 15, "min_candles": 50},
            "GBP/CAD":  {"expiry": 1, "rsi_p": 5, "rsi_ob": 80, "rsi_os": 20, "min_atr": 0.0005, "max_h": 15, "min_candles": 50},
            "GBP/CHF":  {"expiry": 1, "rsi_p": 5, "rsi_ob": 80, "rsi_os": 20, "min_atr": 0.0005, "max_h": 15, "min_candles": 50},
            "GBP/USD":  {"expiry": 1, "rsi_p": 5, "rsi_ob": 80, "rsi_os": 20, "min_atr": 0.0003, "max_h": 15, "min_candles": 50},
            "USD/CAD":  {"expiry": 1, "rsi_p": 5, "rsi_ob": 80, "rsi_os": 20, "min_atr": 0.0003, "max_h": 15, "min_candles": 50},
            "USD/JPY":  {"expiry": 1, "rsi_p": 5, "rsi_ob": 80, "rsi_os": 20, "min_atr": 0.0003, "max_h": 15, "min_candles": 50},
            "EUR/CHF":  {"expiry": 1, "rsi_p": 5, "rsi_ob": 80, "rsi_os": 20, "min_atr": 0.0002, "max_h": 15, "min_candles": 50},
        }

    def _ema(self, series, period):
        return series.ewm(span=period, adjust=False).mean()

    def _sma(self, series, period):
        return series.rolling(window=period).mean()

    def _rsi(self, series, period=5):
        delta = series.diff()
        gain = delta.where(delta > 0, 0.0)
        loss = (-delta).where(delta < 0, 0.0)
        avg_gain = gain.rolling(window=period, min_periods=period).mean()
        avg_loss = loss.rolling(window=period, min_periods=period).mean()
        for i in range(period, len(avg_gain)):
            avg_gain.iloc[i] = (avg_gain.iloc[i-1] * (period - 1) + gain.iloc[i]) / period
            avg_loss.iloc[i] = (avg_loss.iloc[i-1] * (period - 1) + loss.iloc[i]) / period
        rs = avg_gain / avg_loss.replace(0, np.nan)
        return 100 - (100 / (1 + rs))

    def _bbands(self, series, period=20, std_dev=2):
        sma = self._sma(series, period)
        std = series.rolling(window=period).std(ddof=0)
        return sma + std_dev * std, sma, sma - std_dev * std

    def _atr(self, high, low, close, period=7):
        hl = high - low
        hc = (high - close.shift()).abs()
        lc = (low - close.shift()).abs()
        tr = pd.concat([hl, hc, lc], axis=1).max(axis=1)
        return tr.rolling(window=period).mean()

    def get_session(self):
        return "24/7"

    def is_asset_allowed(self, asset_id, session):
        return asset_id in self.ASSET_CFG

    def check_signal(self, asset_id, df):
        if asset_id not in self.ASSET_CFG:
            return {"action": "wait", "reason": "Unknown asset"}

        ren = {'o': 'open', 'h': 'high', 'l': 'low', 'c': 'close', 'v': 'volume', 't': 'timestamp'}
        df = df.rename(columns={k: v for k, v in ren.items() if k in df.columns})

        cfg = self.ASSET_CFG[asset_id]
        # ⬅ ОСЛАБЛЕНО: нужно всего 10 свечей (было 50)
        if len(df) < 10:
            return {"action": "wait", "reason": f"Collecting ({len(df)}/10)"}

        close = pd.to_numeric(df['close'], errors='coerce')
        high = pd.to_numeric(df['high'], errors='coerce')
        low = pd.to_numeric(df['low'], errors='coerce')

        ema3 = self._ema(close, 3)
        ema8 = self._ema(close, 8)
        rsi = self._rsi(close, cfg["rsi_p"])
        atr = self._atr(high, low, close, 7)

        c = {'close': close.iloc[-1], 'open': df['open'].iloc[-1],
             'ema3': ema3.iloc[-1], 'ema8': ema8.iloc[-1],
             'rsi': rsi.iloc[-1], 'atr': atr.iloc[-1]}

        if any(pd.isna(v) for v in c.values()):
            return {"action": "wait", "reason": "NaN indicators"}
        
        # ⬅ ОСЛАБЛЕНО: ATR полностью отключён

        # ⬅ ОСЛАБЛЕНО: расширенные диапазоны RSI
        # CALL: EMA-3 > EMA-8, RSI 30-85, close > open
        if (c['ema3'] > c['ema8'] and 30 < c['rsi'] < 85 and c['close'] > c['open']):
            return {"action": "buy", "reason": "TEST-CALL", "expiry": cfg["expiry"]}

        # PUT: EMA-3 < EMA-8, RSI 15-70, close < open
        if (c['ema3'] < c['ema8'] and 15 < c['rsi'] < 70 and c['close'] < c['open']):
            return {"action": "sell", "reason": "TEST-PUT", "expiry": cfg["expiry"]}

        return {"action": "wait", "reason": "No entry"}