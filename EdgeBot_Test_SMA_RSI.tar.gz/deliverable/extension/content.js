const ENGINE_URL = "http://127.0.0.1:8765";

// ── Состояние ──
let favorites = [];
let currentAsset = "";
let tradeActive = false;
let noSignalTime = 0;  // когда в последний раз был сигнал
let assetIdx = 0;
let candle5s = {};  // 5-секундные свечи по каждому активу

// ── HELPERS ──
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function getBalance() {
    let el = document.querySelector(".balance-value, .user-balance, .balance-info__value");
    return el ? (el.innerText || "").replace(/[^0-9.]/g, "") : "0";
}

// ── ЧТЕНИЕ ИЗБРАННОГО С ДОХОДНОСТЬЮ ──
async function readFavoritesWithPayout() {
    let trigger = document.querySelector(".current-symbol, .assets-block__current");
    if (!trigger) return;
    
    trigger.click();
    await sleep(800);
    
    let favs = [];
    let items = document.querySelectorAll(".alist-favorites .alist__item");
    
    items.forEach(item => {
        let label = item.querySelector(".alist__label");
        let payoutEl = item.querySelector(".alist__payout");
        if (label) {
            let name = (label.innerText || "").replace(/[^A-Za-z\/]/g, "");
            let payout = 0;
            if (payoutEl) {
                payout = parseFloat((payoutEl.innerText || "").replace(/[^0-9.]/g, ""));
            }
            if (name && name.includes('/')) {
                favs.push({ name, payout });
            }
        }
    });
    
    // Закрываем список
    let wrap = document.querySelector(".drop-down-modal-wrap");
    if (wrap) wrap.click();
    await sleep(300);
    
    if (favs.length > 0) {
        // Сортируем по доходности (высокие — первые)
        favs.sort((a, b) => b.payout - a.payout);
        favorites = favs;
        let ok = favs.filter(f => f.payout >= 85).length;
        console.log(`Favorites: ${favs.length} (>=85%: ${ok})`);
    }
}

// ── ПЕРЕКЛЮЧЕНИЕ НА АКТИВ ──
async function switchTo(targetName) {
    let trigger = document.querySelector(".current-symbol, .assets-block__current");
    if (!trigger) return false;
    trigger.click();
    await sleep(700);
    
    let labels = document.querySelectorAll(".alist__item .alist__label");
    for (let label of labels) {
        let text = (label.innerText || "").replace(/[^A-Za-z\/]/g, "");
        if (text.toUpperCase() === targetName.toUpperCase()) {
            label.click();
            await sleep(1000);
            currentAsset = targetName;
            let wrap = document.querySelector(".drop-down-modal-wrap");
            if (wrap) wrap.click();
            await sleep(300);
            
            // ⬅ Создаём 150 начальных свечей на основе текущей цены
            let price = getCurrentPrice();
            if (price > 0 && !candle5s[currentAsset]?.length) {
                let now = Date.now();
                let tf = 5000;
                let baseCandle = Math.floor(now / tf) * tf;
                let candles = [];
                for (let i = 150; i >= 1; i--) {
                    let t = baseCandle - i * tf;
                    let noise = price * (1 + (Math.random() - 0.5) * 0.002);
                    let high = noise * (1 + Math.random() * 0.001);
                    let low = noise * (1 - Math.random() * 0.001);
                    candles.push({ t, o: noise, h: high, l: low, c: noise, v: 10 });
                }
                candle5s[currentAsset] = candles;
                console.log(`Seeded 150 candles for ${currentAsset} @ ${price}`);
            }
            
            console.log(`Switched to ${targetName}`);
            return true;
        }
    }
    
    let wrap = document.querySelector(".drop-down-modal-wrap");
    if (wrap) wrap.click();
    return false;
}

// ── ПОЛУЧЕНИЕ ТЕКУЩЕЙ ЦЕНЫ ──
function getCurrentPrice() {
    let el = document.querySelector(".current-price, .price");
    if (el) {
        let p = parseFloat((el.innerText || "").replace(/[^0-9.]/g, ""));
        if (!isNaN(p) && p > 0) return p;
    }
    return 0;
}

// ── СБОР 5-СЕКУНДНЫХ СВЕЧЕЙ ──
function update5sCandle(asset, price) {
    if (!asset || price <= 0) return;
    if (!candle5s[asset]) candle5s[asset] = [];
    
    const now = Date.now();
    const tf = 5000;  // 5 секунд
    const candleTime = Math.floor(now / tf) * tf;
    const buf = candle5s[asset];
    
    if (buf.length === 0 || buf[buf.length - 1].t !== candleTime) {
        buf.push({ t: candleTime, o: price, h: price, l: price, c: price, v: 1 });
        if (buf.length > 500) buf.shift();
    } else {
        let c = buf[buf.length - 1];
        c.h = Math.max(c.h, price);
        c.l = Math.min(c.l, price);
        c.c = price;
        c.v = (c.v || 0) + 1;
    }
}

// ── ПОЛУЧЕНИЕ ДОХОДНОСТИ ТЕКУЩЕГО АКТИВА ──
function getCurrentPayout() {
    let f = favorites.find(f => f.name === currentAsset);
    return f ? f.payout : 0;
}

// ── ГЛАВНЫЙ ЦИКЛ ──
async function loop() {
    let bal = getBalance();
    
    // Читаем избранное (раз в 10 циклов обновляем)
    if (Math.random() < 0.1) {
        await readFavoritesWithPayout();
    }
    
    // Выбираем актив
    let allowed = favorites.filter(f => f.payout >= 85);
    
    if (allowed.length > 0) {
        let target = allowed[assetIdx % allowed.length];
        
        if (target.name !== currentAsset) {
            await switchTo(target.name);
            setTimeout(loop, 3000);
            return;
        }
        
        // Проверяем: если нет сигнала 2.5-3 минуты → переключаемся
        let waited = (Date.now() - noSignalTime) / 1000;
        if (noSignalTime > 0 && waited > 150 && !tradeActive) {
            console.log(`No signal for ${Math.round(waited)}s, switching asset`);
            assetIdx = (assetIdx + 1) % allowed.length;
            let next = allowed[assetIdx % allowed.length];
            await switchTo(next.name);
            noSignalTime = Date.now();
            setTimeout(loop, 3000);
            return;
        }
    }
    
    // Получаем цену и обновляем свечи
    let price = getCurrentPrice();
    update5sCandle(currentAsset, price);
    
    // Отправляем данные
    try {
        let r = await fetch(ENGINE_URL + "/data", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({
                balance: bal,
                asset: currentAsset,
                candles: candle5s[currentAsset] || [],
                payout: getCurrentPayout(),
                no_signal_since: noSignalTime
            })
        });
        let res = await r.json();
        console.log(res.action, res.stake ? "$"+res.stake : "", res.reason || "");
        
        if (res.action === "sell" && res.stake > 0) {
            tradeActive = true;
            
            // Ставим сумму
            let inputs = document.querySelectorAll("input[type=text]");
            let amtInput = null;
            for (let inp of inputs) {
                if (inp.value && parseFloat(inp.value) > 0) { amtInput = inp; break; }
            }
            if (amtInput && res.stake) {
                amtInput.value = res.stake.toFixed(2);
                amtInput.dispatchEvent(new Event('input', {bubbles:true}));
            }
            
            // Человеческая задержка
            await sleep(500 + Math.random() * 1000);
            
            // Клик PUT
            let btn = document.querySelector(".btn-put");
            if (btn) {
                btn.click();
                console.log(`PUT $${res.stake} ${currentAsset}`);
                // Разблокировка через 70 сек
                setTimeout(() => { tradeActive = false; }, 70000);
            } else {
                tradeActive = false;
            }
        } else {
            // Нет сигнала — отмечаем время
            if (noSignalTime === 0) noSignalTime = Date.now();
        }
    } catch(e) {}
    
    setTimeout(loop, 3000);
}

// ── СТАРТ ──
setTimeout(async () => {
    console.log("EdgeBot: SMA(100)+RSI(8) test mode");
    await readFavoritesWithPayout();
    noSignalTime = Date.now();
    loop();
}, 3000);